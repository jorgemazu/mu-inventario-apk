@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Instalar-FarmBoss.ps1"
echo.
echo Si la ventana se cerro sola, revisa C:\keepalive\logs\instalacion.txt
pause
