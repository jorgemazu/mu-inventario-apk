# Instala FarmBoss desde cero en C:\keepalive
# Python 3.12, pillow, numpy, openpyxl, pytesseract y Tesseract OCR.
# No toca farm-settings.json, github.token, iconos, digits, backups ni logs.
$ErrorActionPreference = "Continue"
$root = "C:\keepalive"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$log = Join-Path $root "logs\instalacion.txt"

function Say([string]$m) {
  $line = "{0} {1}" -f (Get-Date -Format "HH:mm:ss"), $m
  Write-Host $line
  try { Add-Content -Path $log -Value $line -Encoding UTF8 } catch {}
}

foreach ($d in @($root, "$root\logs", "$root\backups", "$root\conteo", "$root\conteo\iconos", "$root\digits", "$root\instalador-cache")) {
  if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

Say "Inicio de instalacion"

function Copy-Programa {
  $ps1 = Join-Path $here "programa\FarmBoss.ps1"
  $bat = Join-Path $here "programa\FarmBoss.bat"
  $py = Join-Path $here "programa\conteo.py"
  if (-not (Test-Path $ps1)) { throw "falta programa\FarmBoss.ps1 en el zip" }
  Copy-Item $ps1 (Join-Path $root "FarmBoss.ps1") -Force
  Copy-Item $bat (Join-Path $root "FarmBoss.bat") -Force
  Copy-Item $py (Join-Path $root "conteo.py") -Force
  Copy-Item $py (Join-Path $root "conteo\conteo.py") -Force
  Say "programa copiado a C:\keepalive"
}

function Get-File([string]$url, [string]$dest) {
  if ((Test-Path $dest) -and ((Get-Item $dest).Length -gt 1MB)) { return $true }
  Say "bajando $url"
  & curl.exe -L --fail --retry 3 -o $dest $url
  return ($LASTEXITCODE -eq 0 -and (Test-Path $dest))
}

function Find-Python {
  $cands = @(
    "$env:LocalAppData\Programs\Python\Python312\python.exe",
    "$env:LocalAppData\Python\bin\python.exe",
    "C:\Python312\python.exe"
  )
  foreach ($c in $cands) { if (Test-Path $c) { return $c } }
  return $null
}

Copy-Programa

$py = Find-Python
if (-not $py) {
  $inst = Join-Path $root "instalador-cache\python-3.12.10-amd64.exe"
  $ok = Get-File "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" $inst
  if (-not $ok) { Say "no se pudo bajar Python" }
  else {
    Say "instalando Python 3.12"
    $p = Start-Process -FilePath $inst -ArgumentList @(
      "/quiet","InstallAllUsers=0","PrependPath=1","Include_pip=1",
      "Include_test=0","Include_doc=0","Include_launcher=1","Shortcuts=0"
    ) -Wait -PassThru
    Say ("Python instalador codigo {0}" -f $p.ExitCode)
    $py = Find-Python
  }
}
if (-not $py) { Say "Python no quedo instalado" }
else {
  Say "Python $py"
  & $py -m pip install --disable-pip-version-check pillow numpy openpyxl pytesseract
  $probe = & $py -c "import PIL,numpy; print('OK')" 2>&1 | Out-String
  if ($probe -match "OK") { Say "pillow y numpy OK" } else { Say "fallo la prueba de Python: $probe" }
}

$tess = @(
  "C:\Program Files\Tesseract-OCR\tesseract.exe",
  "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
  "C:\keepalive\Tesseract-OCR\tesseract.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $tess) {
  $tinst = Join-Path $root "instalador-cache\tesseract-setup.exe"
  $ok = Get-File "https://github.com/tesseract-ocr/tesseract/releases/download/5.5.3/tesseract-ocr-w64-setup-5.5.3.20260724.exe" $tinst
  if (-not $ok) { Say "no se pudo bajar Tesseract" }
  else {
    Say "instalando Tesseract"
    $p = Start-Process -FilePath $tinst -ArgumentList "/S /D=C:\keepalive\Tesseract-OCR" -Wait -PassThru
    Say ("Tesseract instalador codigo {0}" -f $p.ExitCode)
  }
} else { Say "Tesseract ya estaba" }

$desktop = [Environment]::GetFolderPath("Desktop")
$w = New-Object -ComObject WScript.Shell
$s = $w.CreateShortcut((Join-Path $desktop "FarmBoss.lnk"))
$s.TargetPath = "C:\keepalive\FarmBoss.bat"
$s.WorkingDirectory = "C:\keepalive"
$s.WindowStyle = 7
$s.Save()
Say "acceso creado en el escritorio"

$faltan = @()
if (-not (Test-Path (Join-Path $root "github.token"))) { $faltan += "Copia github.token desde el servidor que ya funciona, a C:\keepalive\github.token" }
$nIcon = @(Get-ChildItem "$root\conteo\iconos","$root\iconos" -File -ErrorAction SilentlyContinue).Count
if ($nIcon -eq 0) { $faltan += "Copia las carpetas iconos y digits desde el servidor que ya cuenta. Sin eso el conteo no reconoce items." }
if (-not (Test-Path "C:\LDPlayer\LDPlayer9\ldconsole.exe") -and -not (Test-Path "C:\LDPlayer\LDPlayer9\dnconsole.exe")) {
  $faltan += "Instala LDPlayer 9 en C:\LDPlayer\LDPlayer9. Este instalador no lo incluye."
}
if ($faltan.Count -eq 0) { $faltan = @("Listo. Abre FarmBoss, marca las ventanas y guarda.") }
$msg = ($faltan -join "`r`n`r`n")
Say $msg
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Windows.Forms.MessageBox]::Show($msg, "FarmBoss instalado", "OK", "Information")
Start-Process -FilePath "C:\keepalive\FarmBoss.bat"
