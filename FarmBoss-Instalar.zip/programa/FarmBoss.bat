@echo off
cd /d C:\keepalive
start "" powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\keepalive\FarmBoss.ps1"
