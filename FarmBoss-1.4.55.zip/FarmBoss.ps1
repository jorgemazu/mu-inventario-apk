# FarmBoss.ps1
# Version 1.3.59  sin columna Contar / sin .Visible
# Copiar a C:\keepalive\FarmBoss.ps1
# Ejecutar:  C:\keepalive\FarmBoss.bat
# o: powershell -NoProfile -STA -ExecutionPolicy Bypass -File C:\keepalive\FarmBoss.ps1

param([switch]$ConteoOnly,[switch]$FotosOnly,[switch]$MacroOnly,[switch]$ListaMaestra,[switch]$Actualizar,[switch]$AutoStart,[string]$Cuentas="")
$script:Version = "1.4.55"
$script:BootJobs = @{}
$script:Root = if ($PSScriptRoot) { $PSScriptRoot } else { "C:\keepalive" }
try {
  $bd = Join-Path $script:Root "logs"
  if (-not (Test-Path $bd)) { New-Item -ItemType Directory -Path $bd -Force | Out-Null }
  Add-Content (Join-Path $bd "farm-boot.txt") ("{0} start {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $script:Version) -Encoding UTF8
} catch {}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

try {
  if (-not ("WinHideCon" -as [type])) {
    Add-Type -Name WinHideCon -Namespace Native -MemberDefinition @"
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
"@
  }
  # consola visible: si falla el form se ve el error
} catch {}


try {
try {
  if (-not ("WinMin" -as [type])) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinMin {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  public const int SW_MINIMIZE = 6;
}
"@
  }
} catch {}
} catch {}

$script:Ld       = "C:\LDPlayer\LDPlayer9"
$script:Root     = if ($PSScriptRoot) { $PSScriptRoot } else { "C:\keepalive" }
if (-not (Test-Path $script:Root)) { $script:Root = "C:\keepalive" }
$script:CfgPath  = Join-Path $script:Root "farm-settings.json"
$script:LogDir   = Join-Path $script:Root "logs"
$script:BakDir   = Join-Path $script:Root "backups"
$script:Running  = $false
$script:Booting  = @{}
$script:LastPid  = @{}
$script:LastKa   = Get-Date
$script:ScanLeft = 4
$script:LastFotoScan = Get-Date
$script:LastXzDay = ""
$script:LaunchQ  = New-Object System.Collections.Generic.Queue[int]
$script:AutoDidRun = $false
$script:LastLaunch = [datetime]"2000-01-01"
$script:Fails    = @{}
$script:KaBad    = @{}
$script:LastFailReboot = @{}
$script:KaDead = @{}
$script:KaProxyFail = @{}
$script:KaFile    = Join-Path $script:Root "ka-last.txt"
$script:ConteoDir = Join-Path $script:Root "conteo"
$script:GhOwner     = "jorgemazu"
$script:GhRepo      = "farmboss-inventario"
$script:GhTokenFile = Join-Path $script:Root "github.token"
$script:ConteoBusy = $false
$script:PendingActivar = @{}
$script:LastRemotePoll = [datetime]"2000-01-01"
$script:RemoteCmdPath = Join-Path $script:Root "remote.cmd"
$script:ConteoSelPath = Join-Path $script:Root "conteo-sel.txt"
$script:RemoteRun = $false
$script:RemotePort = 8787
$script:RemoteQ = $null
try {
  $script:RemoteQ = New-Object "System.Collections.Concurrent.ConcurrentQueue[object]"
} catch {
  $script:RemoteQ = New-Object System.Collections.Queue
}
$script:ClCuentas = $null
$script:RemoteToken = ""

$script:InvFarm = Join-Path $script:Root "InventarioFarm.ps1"
# InventarioFarm.ps1 no se carga al arrancar (rompia el form)

function Ensure-Python { return (Get-PythonExe) }
function Ensure-PythonDeps { return $null }

function Ensure-Dirs {

  foreach ($d in @($script:Root, $script:LogDir, $script:BakDir, $script:ConteoDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
  }
}

function Get-WeekLog {
  Ensure-Dirs
  $now  = Get-Date
  $cal  = [Globalization.CultureInfo]::InvariantCulture.Calendar
  $week = $cal.GetWeekOfYear($now, [Globalization.CalendarWeekRule]::FirstFourDayWeek, [DayOfWeek]::Monday)
  return Join-Path $script:LogDir ("farm-{0}-W{1:D2}.log" -f $now.Year, $week)
}

function Write-Log([string]$m, [string]$level = "INFO") {
  Ensure-Dirs
  $line = "{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $level, $m
  if ($level -eq "ERROR" -or $level -eq "ERR") {
    Add-Content -Path (Get-WeekLog) -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
  }
  if ($script:TxtLog -and -not $script:TxtLog.IsDisposed) {
    try {
      $script:TxtLog.AppendText($line + [Environment]::NewLine)
      $script:TxtLog.SelectionStart = $script:TxtLog.Text.Length
      $script:TxtLog.ScrollToCaret()
    } catch {}
  }
}

function Sweep-OldLogs {
  Ensure-Dirs
  $lim = (Get-Date).AddDays(-7)
  Get-ChildItem $script:LogDir -File -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.LastWriteTime -lt $lim) {
      try { Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue } catch {}
    }
  }
}

function Write-FailLog([string]$m) {
  Sweep-OldLogs
  Ensure-Dirs
  $f = Join-Path $script:LogDir ("ka-fail-{0}.log" -f (Get-Date -Format "yyyy-MM-dd"))
  $line = "{0} {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $m
  Add-Content -Path $f -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue
  Write-Log $m "ERROR"
}

function Get-Ipv4Text([string]$s) {
  $m = [regex]::Match("$s", '(\d{1,3}\.){3}\d{1,3}')
  if ($m.Success) { return $m.Value }
  return ""
}

function Load-Cfg {
  Ensure-Dirs
  if (Test-Path $script:CfgPath) {
    try { return Get-Content $script:CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
  }
  return [pscustomobject]@{
    ldPath              = $script:Ld
    delayBetweenSec     = 15
    minimizeAfterSec    = 10
    keepaliveSec        = 240
    afterAndroidSec     = 15
    afterSockOpenSec    = 5
    sockTapGapSec       = 1
    afterSockOnSec      = 8
    afterHomeSec        = 2
    afterAngelLaunchSec = 60
    afterAngelTapSec    = 5
    martianToPlaySec    = 2
    autoStart           = @{}
    contar              = @{}
    contarByName        = @{}
    orden               = @{}
    xuanzhiPath         = "C:\Users\jorge\OneDrive\Documentos\XuanZhi9"
    vmsPath             = "C:\LDPlayer\LDPlayer9\vms"
    fotosPath           = ""
    conteoBolsa         = $false
    conteoBaul          = $false
    cuentasConteo       = @{}
    maestroPeer         = ""
    githubPublish       = $true
    githubFotos         = $false
    cuentaNumero        = ""
  }
}

function Save-Cfg {
  Ensure-Dirs
  try { $grid.EndEdit() } catch {}
  $auto = @{}
  $orden = @{}
  $autoByName = @{}
  $contarByName = @{}
  $ordenByName = @{}
  foreach ($row in $grid.Rows) {
    if ($row.IsNewRow) { continue }
    $idx = [string]$row.Cells["idx"].Value
    if (-not $idx) { continue }
    $auto[$idx] = [bool]$row.Cells["auto"].Value
    $nm = [string]$row.Cells["nombre"].Value
    if ($nm) { $autoByName[$nm] = [bool]$row.Cells["auto"].Value }
    $cnt = $false
    try { $cnt = [bool]$row.Cells["contar"].Value } catch { $cnt = $false }
    if ($nm) { $contarByName[$nm] = $cnt }
    $raw = "$($row.Cells["orden"].Value)".Trim()
    $n = 0
    if ($raw -ne "" -and [int]::TryParse($raw, [ref]$n)) {
      $orden[$idx] = $n
      if ($nm) { $ordenByName[$nm] = $n }
    } else { $orden[$idx] = "" }
  }
  $ctas = @{}
  foreach ($row in $grid.Rows) {
    if ($row.IsNewRow) { continue }
    $nm = [string]$row.Cells["nombre"].Value
    if (-not $nm) { continue }
    $on = $false
    try { $on = [bool]$row.Cells["contar"].Value } catch { $on = $false }
    $ctas[$nm] = $on
  }
  if ($ctas.Keys.Count -eq 0) {
    try {
      $oldCfg = Get-Content $script:CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($oldCfg.cuentasConteo) {
        foreach ($p in $oldCfg.cuentasConteo.PSObject.Properties) { $ctas[[string]$p.Name] = [bool](Cfg-Bool $p.Value) }
      }
      if ($oldCfg.contarByName) {
        foreach ($p in $oldCfg.contarByName.PSObject.Properties) { $ctas[[string]$p.Name] = [bool](Cfg-Bool $p.Value) }
      }
    } catch {}
  }
  $doBolsa = $false
  $doBaul = $false
  try { if ($script:ChkBolsa) { $doBolsa = [bool]$script:ChkBolsa.Checked } } catch {}
  try { if ($script:ChkBaul) { $doBaul = [bool]$script:ChkBaul.Checked } } catch {}
  $obj = [ordered]@{
    ldPath              = $script:Ld
    delayBetweenSec     = [int]$nudLaunch.Value
    minimizeAfterSec    = [int]$nudMin.Value
    keepaliveSec        = 240
    afterAndroidSec     = [int]$nudReady.Value
    afterSockOpenSec    = [int]$nudSockOpen.Value
    sockTapGapSec       = [int]$nudSockGap.Value
    afterSockOnSec      = [int]$nudSockOn.Value
    afterHomeSec        = [int]$nudHome.Value
    afterAngelLaunchSec = [int]$nudAngelOpen.Value
    afterAngelTapSec    = [int]$nudAngelTap.Value
    martianToPlaySec    = [int]$nudPlayGap.Value
    autoStart           = $auto
    autoByName          = $autoByName
    contarByName        = $contarByName
    orden               = $orden
    ordenByName         = $ordenByName
    xuanzhiPath         = $txtXz.Text.Trim()
    vmsPath             = $txtVms.Text.Trim()
    fotosPath           = [string]$script:FotosPath
    remotePort          = [int]$script:RemotePort
    cuentasConteo       = $ctas
    conteoBolsa         = $(if ($script:ChkBolsa) { [bool]$script:ChkBolsa.Checked } else { $false })
    conteoBaul          = $(if ($script:ChkBaul) { [bool]$script:ChkBaul.Checked } else { $false })
    maestroPeer         = ""
    githubPublish       = $true
    githubFotos         = $(if ($script:ChkGitFotos) { [bool]$script:ChkGitFotos.Checked } else { $false })
    cuentaNumero        = $(
      $n = ""
      try { if ($script:TxtCuenta) { $n = $script:TxtCuenta.Text.Trim() } } catch {}
      if (-not $n -and (Test-Path $script:CfgPath)) {
        try {
          $oldC = Get-Content $script:CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
          if ($oldC.cuentaNumero) { $n = [string]$oldC.cuentaNumero }
        } catch {}
      }
      $n
    )
  }
  $obj | ConvertTo-Json -Depth 5 | Set-Content $script:CfgPath -Encoding UTF8
}

function Check-XzDaily {
  $today = Get-Date -Format "yyyy-MM-dd"
  if ($script:LastXzDay -eq $today) { return }
  Ensure-Dirs
  $dst = Join-Path $script:BakDir ("XuanZhi9_{0}" -f $today)
  if (Test-Path $dst) {
    $script:LastXzDay = $today
    return
  }
  Start-XzBackup
  $script:LastXzDay = $today
}

function Start-XzBackup([switch]$Force) {
  $src = ""
  try { $src = $txtXz.Text.Trim() } catch { $src = "" }
  if (-not $src) { $src = "C:\Users\jorge\OneDrive\Documentos\XuanZhi9" }
  if (-not (Test-Path $src)) {
    Write-Log "XuanZhi9 no existe: $src" "ERROR"
    return
  }
  Ensure-Dirs
  $day = Get-Date -Format "yyyy-MM-dd"
  $dst = Join-Path $script:BakDir "XuanZhi9_$day"
  if (-not $Force -and (Test-Path $dst)) {
    Write-Log "backup de hoy ya existe: $dst"
    return
  }
  $logFile = Get-WeekLog
  Write-Log "backup XuanZhi9 inicio $src -> $dst"
  Start-Job -ScriptBlock {
    param($src, $dst, $bakRoot, $logFile)
    function L($m,$lvl="INFO") { Add-Content $logFile ("{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $lvl, $m) -Encoding UTF8 }
    try {
      New-Item -ItemType Directory -Path $dst -Force | Out-Null
      & robocopy $src $dst /E /R:1 /W:1 /NFL /NDL /NP /NJH /NJS | Out-Null
      L "backup XuanZhi9 listo $dst"
    } catch {
      L "backup XuanZhi9 error $_" "ERROR"
    }
    Get-ChildItem $bakRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
      if ($_.Name -match '^XuanZhi9_(\d{4}-\d{2}-\d{2})$') {
        try {
          $d = [datetime]::ParseExact($Matches[1], "yyyy-MM-dd", [Globalization.CultureInfo]::InvariantCulture)
          if ($d -lt [datetime]::Today.AddDays(-7)) {
            Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
            L "backup borrado $($_.Name)"
          }
        } catch {}
      }
    }
  } -ArgumentList $src, $dst, $script:BakDir, $logFile | Out-Null
}

function Start-VmsBackup {
  $src = ""
  try { $src = $txtVms.Text.Trim() } catch { $src = "" }
  if (-not $src) { $src = "C:\LDPlayer\LDPlayer9\vms" }
  if (-not (Test-Path $src)) {
    Write-Log "vms no existe: $src" "ERROR"
    return
  }
  Ensure-Dirs
  $stamp = Get-Date -Format "yyyy-MM-dd_HHmm"
  $dst = Join-Path $script:BakDir "vms_$stamp"
  $logFile = Get-WeekLog
  Write-Log "backup VMS inicio $src -> $dst"
  Start-Job -ScriptBlock {
    param($src, $dst, $logFile)
    function L($m,$lvl="INFO") { Add-Content $logFile ("{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $lvl, $m) -Encoding UTF8 }
    try {
      New-Item -ItemType Directory -Path $dst -Force | Out-Null
      & robocopy $src $dst /E /R:1 /W:1 /NFL /NDL /NP /NJH /NJS | Out-Null
      L "backup VMS listo $dst"
    } catch {
      L "backup VMS error $_" "ERROR"
    }
  } -ArgumentList $src, $dst, $logFile | Out-Null
}

function Get-AdbPort([int]$idx) { return (5554 + (2 * $idx)) }

function Get-List2 {
  $exe = Join-Path $script:Ld "ldconsole.exe"
  if (-not (Test-Path $exe)) { return @() }
  $raw = & $exe list2 2>$null
  $out = @()
  foreach ($line in $raw) {
    $p = ("$line").Trim() -split ","
    if ($p.Count -lt 7) { continue }
    $emuPid = $p[5]
    $out += [pscustomobject]@{
      idx     = [int]$p[0]
      name    = $p[1]
      hwnd    = $p[2]
      android = $p[4]
      pid     = $emuPid
      w       = $(if ($p.Count -ge 8) { $p[7] } else { "" })
      h       = $(if ($p.Count -ge 9) { $p[8] } else { "" })
      dpi     = $(if ($p.Count -ge 10) { $p[9] } else { "" })
      alive   = ($emuPid -ne "-1" -and $emuPid -ne "0" -and $emuPid -ne "")
    }
  }
  return $out
}

function Adb-Ld([int]$idx, [string]$cmd) {
  $exe = Join-Path $script:Ld "ldconsole.exe"
  return & $exe adb --index $idx --command "shell $cmd" 2>$null
}

function Adb-Direct([int]$idx, [string]$cmd) {
  $port = Get-AdbPort $idx
  $adb  = Join-Path $script:Ld "adb.exe"
  & $adb connect "127.0.0.1:$port" 2>$null | Out-Null
  return & $adb -s "emulator-$port" shell $cmd 2>$null
}

# Medido el 2026-09-28 en 1280x720.
# La cabeza abre el menu. Pausa y play son el circulo que aparece despues.
# Justo debajo de la cabeza se cierra cualquier ventana que dejo el bot.
function Get-FotoPuntos {
  return @{
    baseW = 1280; baseH = 720
    cabeza = @(16, 468)
    pausa  = @(142, 466)
    cerrar = @(16, 508)
    bolsa  = @(1232, 250)
    play   = @(142, 466)
  }
}

function Get-TapScale([int]$idx) {
  $w = 1280; $h = 720
  try {
    $raw = "$(Adb-Ld $idx 'wm size')"
    $ms = [regex]::Matches($raw, '(\d+)\s*x\s*(\d+)')
    if ($ms.Count -gt 0) {
      $m = $ms[$ms.Count - 1]
      $w = [int]$m.Groups[1].Value
      $h = [int]$m.Groups[2].Value
    }
  } catch {}
  if ($w -lt 100) { $w = 1280 }
  if ($h -lt 100) { $h = 720 }
  return @{ w = $w; h = $h; x = ($w / 1280.0); y = ($h / 720.0) }
}

function Get-PlayerHwnds([int]$idx) {
  $top = [IntPtr]::Zero
  $bind = [IntPtr]::Zero
  $exe = Join-Path $script:Ld "ldconsole.exe"
  if (-not (Test-Path $exe)) { return @{ top = $top; bind = $bind } }
  $raw = & $exe list2 2>$null
  foreach ($line in $raw) {
    $p = ("$line").Trim() -split ","
    if ($p.Count -lt 4 -or $p[0] -ne "$idx") { continue }
    $n = 0L
    if ([int64]::TryParse($p[2], [ref]$n) -and $n -ne 0) { $top = [IntPtr]$n }
    $n = 0L
    if ([int64]::TryParse($p[3], [ref]$n) -and $n -ne 0) { $bind = [IntPtr]$n }
    break
  }
  return @{ top = $top; bind = $bind }
}

function Ensure-WinClick {
  if ("WinClick" -as [type]) { return }
  Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
using System.Threading;
public class WinClick {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr hWnd, out RECT r);
  [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr hWnd, ref POINT p);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern void mouse_event(uint f, uint dx, uint dy, uint d, UIntPtr e);
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
  public struct POINT { public int X; public int Y; }
  public static void ClickClient(IntPtr top, IntPtr bind, int x, int y) {
    if (top == IntPtr.Zero) top = bind;
    if (bind == IntPtr.Zero) bind = top;
    if (IsIconic(top)) ShowWindow(top, 9);
    SetForegroundWindow(top);
    Thread.Sleep(200);
    RECT r;
    GetClientRect(bind, out r);
    POINT p = new POINT();
    p.X = x; p.Y = y;
    ClientToScreen(bind, ref p);
    SetCursorPos(p.X, p.Y);
    Thread.Sleep(40);
    mouse_event(2, 0, 0, 0, UIntPtr.Zero);
    Thread.Sleep(70);
    mouse_event(4, 0, 0, 0, UIntPtr.Zero);
  }
}
"@
}

function Send-FotoTap([int]$idx, [int]$x, [int]$y, $scale) {
  Ensure-WinClick
  $ax = [int][Math]::Round($x * [double]$scale.x)
  $ay = [int][Math]::Round($y * [double]$scale.y)
  $tx = $ax
  $ty = $ay
  $hs = Get-PlayerHwnds $idx
  $hwnd = $hs.bind
  if ($hwnd -eq [IntPtr]::Zero) { $hwnd = $hs.top }
  if ($hwnd -eq [IntPtr]::Zero) {
    Write-Host "  sin ventana del juego" -ForegroundColor Red
    Write-Log ("foto tap idx {0}: sin hwnd" -f $idx) "WARN"
    return @($tx, $ty)
  }
  $r = New-Object WinClick+RECT
  [void][WinClick]::GetClientRect($hwnd, [ref]$r)
  $cw = $r.Right - $r.Left
  $ch = $r.Bottom - $r.Top
  if ($cw -gt 50 -and $ch -gt 50 -and $scale.w -gt 0 -and $scale.h -gt 0) {
    $tx = [int][Math]::Round($ax * $cw / [double]$scale.w)
    $ty = [int][Math]::Round($ay * $ch / [double]$scale.h)
  }
  try {
    $con = [Native.WinHideCon]::GetConsoleWindow()
    if ($con -ne [IntPtr]::Zero) { [void][WinMin]::ShowWindow($con, 6) }
  } catch {}
  [WinClick]::ClickClient($hs.top, $hwnd, $tx, $ty)
  Write-Host ("  clic {0},{1}" -f $tx, $ty)
  return @($tx, $ty)
}

function Hide-FotoWindow([int]$idx) {
  $hs = Get-PlayerHwnds $idx
  $top = $hs.top
  if ($top -eq [IntPtr]::Zero) { $top = $hs.bind }
  if ($top -eq [IntPtr]::Zero) { return }
  [void][WinClick]::ShowWindow($top, 6)
}

function Prepare-FotoWindow([int]$idx) {
  Ensure-WinClick
  $hs = Get-PlayerHwnds $idx
  $top = $hs.top
  if ($top -eq [IntPtr]::Zero) { $top = $hs.bind }
  if ($top -eq [IntPtr]::Zero) { return }
  [void][WinClick]::ShowWindow($top, 9)
  [void][WinClick]::SetForegroundWindow($top)
  Start-Sleep -Milliseconds 250
  [void][WinClick]::ShowWindow($top, 3)
  Start-Sleep -Milliseconds 2000
  [void][WinClick]::ShowWindow($top, 9)
  Start-Sleep -Milliseconds 1500
}

function Save-AdbShot([int]$idx, [string]$dest) {
  $port = Get-AdbPort $idx
  $adb = Join-Path $script:Ld "adb.exe"
  $remote = "/sdcard/farmboss-shot.png"
  Adb-Ld $idx "screencap -p $remote" | Out-Null
  & $adb connect "127.0.0.1:$port" 2>$null | Out-Null
  foreach ($serial in @("emulator-$port", "127.0.0.1:$port")) {
    if (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest -Force -ErrorAction SilentlyContinue }
    & $adb -s $serial pull $remote $dest 2>$null | Out-Null
    if ((Test-Path -LiteralPath $dest) -and ((Get-Item -LiteralPath $dest).Length -gt 10000)) {
      Adb-Ld $idx "rm -f $remote" | Out-Null
      return $true
    }
  }
  Adb-Ld $idx "rm -f $remote" | Out-Null
  return $false
}

function Get-FotoDestDir([int]$idx) {
  $dir = $null
  try { $dir = Get-InstanceBoundShotDir $idx } catch { $dir = $null }
  if ($dir) { return $dir }
  $raw = ""
  try { $raw = Get-InstancePictureRaw $idx } catch { $raw = "" }
  if (-not $raw) { return $null }
  $dir = Join-Path ($raw.Trim().TrimEnd('\','/')) "Screenshots"
  New-Item -ItemType Directory -Force -Path $dir | Out-Null
  return $dir
}

function Invoke-FotoUna([string]$name) {
  $list = @(Get-List2)
  $it = $list | Where-Object { $_.name -eq $name } | Select-Object -First 1
  if (-not $it -or -not $it.alive) {
    Write-Host ("{0} cerrada, se reintenta" -f $name) -ForegroundColor Yellow
    Write-Log ("foto {0}: ventana cerrada" -f $name) "WARN"
    return $false
  }
  $pts = Get-FotoPuntos
  $idx = [int]$it.idx
  Write-Host ("foto {0}" -f $name) -ForegroundColor Cyan
  Write-Log ("foto {0} idx {1}" -f $name, $idx)
  $scale = Get-TapScale $idx
  $paused = $false
  $shot = $false
  try {
    Prepare-FotoWindow $idx
    Write-Log ("foto {0} ventana horizontal" -f $name)
    $th = Send-FotoTap $idx $pts.cabeza[0] $pts.cabeza[1] $scale
    $paused = $true
    Write-Log ("foto {0} cabeza {1},{2}" -f $name, $th[0], $th[1])
    Start-Sleep -Milliseconds 1200
    $tp = Send-FotoTap $idx $pts.pausa[0] $pts.pausa[1] $scale
    Write-Log ("foto {0} pausa {1},{2}" -f $name, $tp[0], $tp[1])
    Start-Sleep -Milliseconds 800
    $tc = Send-FotoTap $idx $pts.cerrar[0] $pts.cerrar[1] $scale
    Write-Log ("foto {0} cerrar {1},{2}" -f $name, $tc[0], $tc[1])
    Start-Sleep -Milliseconds 900
    $tb = Send-FotoTap $idx $pts.bolsa[0] $pts.bolsa[1] $scale
    Write-Log ("foto {0} bolsa {1},{2}" -f $name, $tb[0], $tb[1])
    Start-Sleep -Milliseconds 1500
    $dir = Get-FotoDestDir $idx
    if (-not $dir) {
      Write-Host "  sin carpeta de fotos" -ForegroundColor Red
      Write-Log ("foto {0}: sin carpeta" -f $name) "WARN"
    } else {
      $fn = "Screenshot_{0}.png" -f (Get-Date -Format "yyyyMMdd-HHmmss")
      $dest = Join-Path $dir $fn
      if (Save-AdbShot $idx $dest) {
        $shot = $true
        Write-Host ("  {0}" -f $dest)
        Write-Log ("foto {0} guardada {1}" -f $name, $dest)
      } else {
        Write-Host "  no salio la foto" -ForegroundColor Red
        Write-Log ("foto {0}: screencap vacio" -f $name) "WARN"
      }
    }
  } finally {
    if ($paused) {
      Start-Sleep -Milliseconds 400
      $tc2 = Send-FotoTap $idx $pts.cerrar[0] $pts.cerrar[1] $scale
      Write-Log ("foto {0} cerrar bolsa {1},{2}" -f $name, $tc2[0], $tc2[1])
      Start-Sleep -Milliseconds 500
      $th2 = Send-FotoTap $idx $pts.cabeza[0] $pts.cabeza[1] $scale
      Write-Log ("foto {0} cabeza {1},{2}" -f $name, $th2[0], $th2[1])
      Start-Sleep -Milliseconds 700
      $ty = Send-FotoTap $idx $pts.play[0] $pts.play[1] $scale
      Write-Log ("foto {0} play {1},{2}" -f $name, $ty[0], $ty[1])
      Start-Sleep -Milliseconds 3000
      Hide-FotoWindow $idx
      Write-Log ("foto {0} minimizada" -f $name)
    }
  }
  return $shot
}

function Invoke-FotosAuto {
  $sel = @(Get-CuentasSeleccionadas)
  if ($sel.Count -eq 0) { throw "marca al menos una cuenta" }
  $ok = New-Object System.Collections.Generic.List[string]
  $fallo = New-Object System.Collections.Generic.List[string]
  foreach ($name in $sel) {
    if (Invoke-FotoUna $name) { [void]$ok.Add($name) } else { [void]$fallo.Add($name) }
    Start-Sleep -Milliseconds 800
  }
  return @{ ok = @($ok); fallo = @($fallo) }
}

function Start-ConteoProceso([string]$lista) {
  if (-not $lista) { return }
  $me = $PSCommandPath
  if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
  Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ConteoOnly", "-Cuentas", $lista
  )
}

function Start-MacroProceso([string]$nombre) {
  if (-not $nombre) { return }
  $me = $PSCommandPath
  if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
  Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-MacroOnly", "-Cuentas", $nombre
  )
}

function Start-FotosProceso {
  $me = $PSCommandPath
  if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
  Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-FotosOnly"
  )
}

function Start-Multiplayer {
  $cands = @(
    "C:\LDPlayer\ldmutiplayer\dnmultiplayerex.exe",
    "C:\LDPlayer\ldmultiplayer\dnmultiplayerex.exe"
  )
  $alive = Get-Process -Name "dnmultiplayerex" -ErrorAction SilentlyContinue
  if ($alive) {
    Write-Log "LDMultiplayer ya estaba abierto"
    return
  }
  foreach ($p in $cands) {
    if (Test-Path $p) {
      Start-Process $p | Out-Null
      Write-Log "LDMultiplayer iniciado: $p"
      return
    }
  }
  Write-Log "No se encontro C:\\LDPlayer\\ldmutiplayer\\dnmultiplayerex.exe" "ERROR"
}

function Minimize-Idx([int]$idx, [string]$hwndStr) {
  $ok = $false
  if ($hwndStr -and $hwndStr -ne "0") {
    try {
      $h = [IntPtr][int64]$hwndStr
      $ok = [WinMin]::ShowWindow($h, [WinMin]::SW_MINIMIZE)
    } catch {}
  }
  if (-not $ok) {
    $exe = Join-Path $script:Ld "ldconsole.exe"
    try { & $exe minimize --index $idx 2>$null | Out-Null } catch {}
  }
  Write-Log "idx $idx minimizada"
}

function Wait-Android([int]$idx) {
  Write-Log "idx $idx esperando Android"
  for ($i = 0; $i -lt 60; $i++) {
    $o = Adb-Ld $idx "getprop sys.boot_completed"
    if ("$o" -match "1") {
      Start-Sleep 15
      return $true
    }
    Start-Sleep 5
  }
  Write-Log "idx $idx timeout Android" "ERROR"
  return $false
}

function Invoke-Boot([int]$idx, [string]$hwndStr) {
  $key = [string]$idx
  if ($script:Booting.ContainsKey($key)) { return }
  $script:Booting[$key] = $true
  try {
    Write-Log "idx $idx BOOT inicio"
    if (-not (Wait-Android $idx)) { return }

    Write-Log "idx $idx SocksDroid"
    Adb-Ld $idx "monkey -p net.typeblog.socks -c android.intent.category.LAUNCHER 1" | Out-Null
    Start-Sleep 5
    Adb-Ld $idx "input tap 360 1042" | Out-Null
    Start-Sleep -Milliseconds 500
    Adb-Ld $idx "input tap 592 104" | Out-Null
    Start-Sleep 8

    Adb-Ld $idx "input keyevent 3" | Out-Null
    Start-Sleep 2

    $plist = "$(Adb-Ld $idx "pm list packages")"
    $bot = $null
    if ($plist -match "package:com\.qqq\.weixind") { $bot = "com.qqq.weixind" }
    elseif ($plist -match "package:com\.mubplayzone") { $bot = "com.mubplayzone" }
    if (-not $bot) { Write-Log "idx $idx sin Angel S ni BotplayZone" "ERROR"; return }
    Write-Log "idx $idx abre $bot"
    $ldc = Join-Path $script:Ld "ldconsole.exe"
    if (Test-Path $ldc) { & $ldc runapp --index $idx --packagename $bot 2>$null | Out-Null }
    Adb-Ld $idx "monkey -p $bot -c android.intent.category.LAUNCHER 1" | Out-Null
    Start-Sleep 40
    Adb-Ld $idx "input tap 360 1042" | Out-Null
    Start-Sleep 5

    Write-Log "idx $idx PLAY"
    $port = Get-AdbPort $idx
    $adb  = Join-Path $script:Ld "adb.exe"
    & $adb connect "127.0.0.1:$port" 2>$null | Out-Null
    & $adb -s "emulator-$port" shell "input tap 700 420; sleep 2; input tap 250 440" 2>$null | Out-Null
    Write-Log "idx $idx BOOT ok"

    $waitMin = [int]$nudMin.Value
    Write-Log "idx $idx espera $waitMin s para minimizar"
    Start-Sleep $waitMin
    $fresh = Get-List2 | Where-Object { $_.idx -eq $idx } | Select-Object -First 1
    $h = $hwndStr
    if ($fresh) { $h = $fresh.hwnd }
    Minimize-Idx $idx $h
  } catch {
    Write-Log "idx $idx BOOT error: $_" "ERROR"
  } finally {
    $script:Booting.Remove($key)
  }
}

function Start-BootJob([int]$idx, [string]$hwndStr) {
  $key = [string]$idx
  if ($script:Booting.ContainsKey($key)) { return }
  $script:Booting[$key] = $true
  Write-Log "idx $idx en cola de boot"
  [System.Threading.ThreadPool]::QueueUserWorkItem({
    param($state)
    $i = $state[0]; $h = $state[1]
    $script:Booting.Remove([string]$i)
    Invoke-Boot $i $h
  }.GetNewClosure(), @($idx, $hwndStr)) | Out-Null
}

# QueueUserWorkItem + script scope is flaky in PS. Use Start-Job with full logic instead.
function Start-BootJob2([int]$idx, [string]$hwndStr) {
  $key = [string]$idx
  if ($script:Booting.ContainsKey($key)) {
    $when = $script:Booting[$key]
    if ($when -is [datetime] -and ((Get-Date) - $when).TotalSeconds -lt 120) { return }
  }
  $script:Booting[$key] = Get-Date
  $t = @{
    afterAndroid     = [int]$nudReady.Value
    afterSockOpen    = [int]$nudSockOpen.Value
    sockTapGapSec    = [int]$nudSockGap.Value
    afterSockOn      = [int]$nudSockOn.Value
    afterHome        = [int]$nudHome.Value
    afterAngelLaunch = [int]$nudAngelOpen.Value
    afterAngelTap    = [int]$nudAngelTap.Value
    martianPlay      = [int]$nudPlayGap.Value
    minSec           = [int]$nudMin.Value
  }
  $ld = $script:Ld
  $logFile = Get-WeekLog
  Write-Log "idx $idx boot en segundo plano"
  $job = Start-Job -ScriptBlock {
    param($idx, $hwndStr, $ld, $t, $logFile)
    function L($m,$lvl="INFO") { Add-Content $logFile ("{0} [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $lvl, $m) -Encoding UTF8 }
    $port = 5554 + (2 * $idx)
    $ldc  = Join-Path $ld "ldconsole.exe"
    $adb  = Join-Path $ld "adb.exe"
    function AdbLd($cmd) { & $ldc adb --index $idx --command "shell $cmd" 2>$null }
    L "idx $idx BOOT inicio"
    $ok = $false
    for ($i=0; $i -lt 60; $i++) {
      $o = AdbLd "getprop sys.boot_completed"
      if ("$o" -match "1") { Start-Sleep $t.afterAndroid; $ok = $true; break }
      Start-Sleep 5
    }
    if (-not $ok) { L "idx $idx timeout Android" "ERROR"; return }
    L "idx $idx SocksDroid"
    AdbLd "monkey -p net.typeblog.socks -c android.intent.category.LAUNCHER 1" | Out-Null
    Start-Sleep $t.afterSockOpen
    AdbLd "input tap 360 1042" | Out-Null
    Start-Sleep $t.sockTapGapSec
    AdbLd "input tap 592 104" | Out-Null
    Start-Sleep $t.afterSockOn
    AdbLd "input keyevent 3" | Out-Null
    Start-Sleep $t.afterHome
    $plist = [string](AdbLd "pm list packages")
    $bot = $null
    if ($plist -match "package:com\.qqq\.weixind") { $bot = "com.qqq.weixind" }
    elseif ($plist -match "package:com\.mubplayzone") { $bot = "com.mubplayzone" }
    if (-not $bot) { L "idx $idx sin Angel S ni BotplayZone" "ERROR"; return }
    L "idx $idx abre $bot"
    & $ldc runapp --index $idx --packagename $bot 2>$null | Out-Null
    AdbLd "monkey -p $bot -c android.intent.category.LAUNCHER 1" | Out-Null
    Start-Sleep $t.afterAngelLaunch
    AdbLd "input tap 360 1042" | Out-Null
    Start-Sleep $t.afterAngelTap
    L "idx $idx PLAY"
    & $adb connect "127.0.0.1:$port" 2>$null | Out-Null
    $gap = [int]$t.martianPlay
    & $adb -s "emulator-$port" shell "input tap 700 420; sleep $gap; input tap 250 440" 2>$null | Out-Null
    L "idx $idx BOOT ok"
    L "idx $idx espera $($t.minSec) s para minimizar"
    Start-Sleep $t.minSec
    $hw = $hwndStr
    try {
      $raw = & $ldc list2 2>$null
      foreach ($line in $raw) {
        $p = ("$line").Trim() -split ","
        if ($p.Count -ge 3 -and $p[0] -eq "$idx") { $hw = $p[2]; break }
      }
    } catch {}
    $minOk = $false
    if ($hw -and $hw -ne "0") {
      Add-Type @"
using System;
using System.Runtime.InteropServices;
public class WinMinJ {
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@
      try { $minOk = [WinMinJ]::ShowWindow([IntPtr][int64]$hw, 6) } catch {}
    }
    if (-not $minOk) { try { & $ldc minimize --index $idx 2>$null | Out-Null } catch {} }
    L "idx $idx minimizada"
  } -ArgumentList $idx, $hwndStr, $ld, $t, $logFile
  $script:BootJobs[$key] = $job
}

function Get-BootTimeoutSec {
  try {
    $s = 90
    $s += [int]$nudReady.Value
    $s += [int]$nudSockOpen.Value
    $s += [int]$nudSockGap.Value
    $s += [int]$nudSockOn.Value
    $s += [int]$nudHome.Value
    $s += [int]$nudAngelOpen.Value
    $s += [int]$nudAngelTap.Value
    $s += [int]$nudPlayGap.Value
    $s += [int]$nudMin.Value
    if ($s -lt 180) { $s = 180 }
    if ($s -gt 900) { $s = 900 }
    return $s
  } catch { return 300 }
}

function Sweep-BootJobs {
  $limit = Get-BootTimeoutSec
  $keys = @($script:Booting.Keys)
  foreach ($k in $keys) {
    $job = $null
    if ($script:BootJobs.ContainsKey($k)) { $job = $script:BootJobs[$k] }
    $done = $false
    $why = ""
    if ($job) {
      $st = [string]$job.State
      if ($st -eq "Completed" -or $st -eq "Failed" -or $st -eq "Stopped") {
        $done = $true
        $why = $st.ToLower()
        try { Receive-Job $job -ErrorAction SilentlyContinue | Out-Null } catch {}
        try { Remove-Job $job -Force -ErrorAction SilentlyContinue } catch {}
        $script:BootJobs.Remove($k)
      }
    }
    $when = $script:Booting[$k]
    if (-not $done -and $when -is [datetime] -and ((Get-Date) - $when).TotalSeconds -ge $limit) {
      $done = $true
      $why = "timeout ${limit}s"
      if ($job) {
        try { Stop-Job $job -Force -ErrorAction SilentlyContinue } catch {}
        try { Remove-Job $job -Force -ErrorAction SilentlyContinue } catch {}
        $script:BootJobs.Remove($k)
      }
    }
    if ($done) {
      $script:Booting.Remove($k)
      Write-Log ("idx {0} boot listo ({1}) -> VIVA" -f $k, $why)
    }
  }
}

function Cfg-Auto([string]$idx) {
  $idx = [string]$idx
  $nm = ""
  try {
    foreach ($row in @($grid.Rows)) {
      if ($row.IsNewRow) { continue }
      if ([string]$row.Cells["idx"].Value -eq $idx) {
        $nm = "$($row.Cells["name"].Value)".Trim()
        return [bool]$row.Cells["auto"].Value
      }
    }
  } catch {}
  $cfg = Load-Cfg
  if ($nm -and $cfg.autoStartByName) {
    try {
      foreach ($p in $cfg.autoStartByName.PSObject.Properties) {
        if ([string]$p.Name -eq $nm) { return [bool]$p.Value }
      }
    } catch {}
  }
  try {
    if ($cfg.autoStart) {
      foreach ($p in $cfg.autoStart.PSObject.Properties) {
        if ([string]$p.Name -eq $idx) { return [bool]$p.Value }
      }
    }
  } catch {}
  return $false
}

function Cfg-AutoByName([string]$name) {
  $cfg = Load-Cfg
  try {
    $bag = $null
    if ($cfg.autoByName) { $bag = $cfg.autoByName }
    elseif ($cfg.autoStartByName) { $bag = $cfg.autoStartByName }
    if ($bag) {
      foreach ($p in $bag.PSObject.Properties) {
        if ([string]$p.Name -eq $name) { return [bool]$p.Value }
      }
    }
  } catch {}
  return $false
}

function Cfg-OrdenByName([string]$name) {
  $cfg = Load-Cfg
  try {
    if ($cfg.ordenByName) {
      foreach ($p in $cfg.ordenByName.PSObject.Properties) {
        if ([string]$p.Name -eq $name) {
          if ($null -eq $p.Value -or "$($p.Value)".Trim() -eq "") { return "" }
          return [string]$p.Value
        }
      }
    }
  } catch {}
  return ""
}

function Cfg-Orden([string]$idx) {
  $cfg = Load-Cfg
  try {
    $v = $cfg.orden.$idx
    if ($null -eq $v -or "$v".Trim() -eq "") { return "" }
    $n = 0
    if ([int]::TryParse("$v", [ref]$n)) { return $n }
    return ""
  } catch { return "" }
}


function Cfg-ContarByName([string]$name) {
  if (-not $name) { return $false }
  try {
    $cfg = Load-Cfg
    foreach ($key in @("contarByName","cuentasConteo")) {
      $obj = $null
      try { $obj = $cfg.$key } catch { $obj = $null }
      if (-not $obj) { continue }
      foreach ($p in $obj.PSObject.Properties) {
        $pn = [string]$p.Name
        if (-not $pn) { continue }
        if ($pn -eq $name -or $pn.ToLower() -eq $name.ToLower() -or $name.ToLower().Contains($pn.ToLower()) -or $pn.ToLower().Contains($name.ToLower())) {
          if (Cfg-Bool $p.Value) { return $true }
        }
      }
    }
  } catch {}
  return $false
}

function Name-Matches([string]$name, $sels) {
  if (-not $sels -or $sels.Count -eq 0) { return $false }
  $a = ("$name").ToLowerInvariant()
  foreach ($s in @($sels)) {
    $b = ("$s").Trim().ToLowerInvariant()
    if (-not $b) { continue }
    if ($a -eq $b -or $a.Contains($b) -or $b.Contains($a)) { return $true }
  }
  return $false
}

function Get-SelectedConteoNames {
  $names = @()
  try {
    foreach ($row in @($grid.Rows)) {
      if ($row.IsNewRow) { continue }
      $on = $false
      try { $on = [bool]$row.Cells["contar"].Value } catch { $on = $false }
      if ($on) {
        $nm = [string]$row.Cells["nombre"].Value
        if ($nm) { $names += $nm }
      }
    }
  } catch {}
  if (Test-Path $script:ConteoSelPath) {
    try {
      foreach ($line in @(Get-Content $script:ConteoSelPath -Encoding UTF8)) {
        $t = "$line".Trim()
        if ($t -and $t -notmatch "^#") { $names += $t }
      }
    } catch {}
  }
  return @($names | Select-Object -Unique)
}

function Save-ConteoSel($names) {
  Ensure-Dirs
  $lines = @($names | Where-Object { $_ })
  $utf8 = New-Object System.Text.UTF8Encoding $true
  [IO.File]::WriteAllLines($script:ConteoSelPath, $lines, $utf8)
}

function Invoke-ActivarByNames($names) {
  if (-not $names -or $names.Count -eq 0) {
    Write-Log "activar: ninguna cuenta marcada" "WARN"
    return 0
  }
  $list = @(Get-List2)
  $n = 0
  $exe = Join-Path $script:Ld "ldconsole.exe"
  foreach ($it in $list) {
    if (-not (Name-Matches $it.name $names)) { continue }
    $n++
    if (-not $it.alive) {
      Write-Log ("activar launch idx {0} {1}" -f $it.idx, $it.name)
      try { & $exe launch --index $it.idx 2>$null | Out-Null } catch {}
      $script:PendingActivar[[string]$it.idx] = $true
    } else {
      Write-Log ("activar boot idx {0} {1}" -f $it.idx, $it.name)
      Start-BootJob2 $it.idx $it.hwnd
    }
  }
  if ($n -eq 0) { Write-Log ("activar: no hay instancia que coincida ({0})" -f ($names -join ",")) "WARN" }
  return $n
}

function Sweep-PendingActivar {
  if (-not $script:PendingActivar -or $script:PendingActivar.Count -eq 0) { return }
  $list = @(Get-List2)
  $done = @()
  foreach ($k in @($script:PendingActivar.Keys)) {
    $it = $list | Where-Object { [string]$_.idx -eq [string]$k } | Select-Object -First 1
    if ($it -and $it.alive) {
      Write-Log ("activar pendiente idx {0} ya viva - boot" -f $it.idx)
      Start-BootJob2 $it.idx $it.hwnd
      $done += $k
    }
  }
  foreach ($k in $done) { $script:PendingActivar.Remove($k) }
}

function Apply-RemoteCmd([string]$txt) {
  $raw = ("$txt").Replace("`r","").Trim()
  if (-not $raw) { return }
  if ($raw -match "^(OK|DONE|PROCESADO)") { return }
  Write-Log ("remote cmd: {0}" -f $raw)
  foreach ($line in ($raw -split "`n")) {
    $l = $line.Trim()
    if (-not $l -or $l.StartsWith("#")) { continue }
    if ($l -match "^(?i)ACTIVAR(\s+(.+))?$") {
      $rest = $Matches[2]
      $names = @()
      if ($rest -and $rest.Trim() -ne "*") {
        $names = @($rest.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
      } else {
        $names = @(Get-SelectedConteoNames)
        if ($names.Count -eq 0) { $names = @(Get-List2 | ForEach-Object { $_.name }) }
      }
      [void](Invoke-ActivarByNames $names)
    } elseif ($l -match "^(?i)CONTAR(\s+(.+))?$") {
      $rest = $Matches[2]
      $names = @()
      if ($rest) { $names = @($rest.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
      else { $names = @(Get-SelectedConteoNames) }
      if ($names.Count -gt 0) { Save-ConteoSel $names }
      $me = $PSCommandPath
      if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
      Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
        "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ConteoOnly"
      )
    }
  }
}

function Poll-RemoteCmd {
  if (((Get-Date) - $script:LastRemotePoll).TotalSeconds -lt 20) { return }
  $script:LastRemotePoll = Get-Date
  if (Test-Path $script:RemoteCmdPath) {
    try {
      $txt = Get-Content $script:RemoteCmdPath -Raw -Encoding UTF8
      if ($txt -and $txt.Trim() -and ($txt -notmatch "^(OK|DONE|PROCESADO)")) {
        Apply-RemoteCmd $txt
        Set-Content $script:RemoteCmdPath "OK $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -Encoding UTF8
      }
    } catch { Write-Log "remote.cmd local: $_" "WARN" }
  }
  $tok = $null
  try { $tok = Get-GitHubToken } catch { $tok = $null }
  if (-not $tok) { return }
  $api = "https://api.github.com/repos/$($script:GhOwner)/$($script:GhRepo)/contents/remote.cmd"
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
  $hdr = @{ Authorization = "Bearer $tok"; Accept = "application/vnd.github+json"; "User-Agent" = "FarmBoss" }
  try {
    $cur = Invoke-RestMethod -Uri $api -Headers $hdr -Method Get
    $bytes = [Convert]::FromBase64String(("$($cur.content)" -replace "\s",""))
    $txt = [Text.Encoding]::UTF8.GetString($bytes)
    if (-not $txt.Trim() -or $txt -match "^(OK|DONE|PROCESADO)") { return }
    Apply-RemoteCmd $txt
    $ok = "OK $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
    $b64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($ok))
    $body = @{ message = "remote ok"; content = $b64; sha = [string]$cur.sha } | ConvertTo-Json -Compress
    [void](Invoke-RestMethod -Uri $api -Headers $hdr -Method Put -Body $body -ContentType "application/json")
  } catch {}
}


function Get-SortOrden($k, $ordenMap) {
  $raw = $null
  if ($ordenMap -and $ordenMap.ContainsKey($k)) { $raw = $ordenMap[$k] }
  else { $raw = Cfg-Orden $k }
  $n = 0
  if ("$raw".Trim() -ne "" -and [int]::TryParse("$raw", [ref]$n)) { return $n }
  return 9999
}

function Fail-Count([string]$k) {
  if ($script:Fails.ContainsKey($k)) { return [int]$script:Fails[$k] }
  return 0
}

function Row-Estado($it, [string]$k) {
  if (-not $it.alive) { return "cerrada" }
  if ($script:Booting.ContainsKey($k)) { return "BOOT" }
  if ($script:KaBad.ContainsKey($k) -and $script:KaBad[$k]) { return "Fallo" }
  return "VIVA"
}

function Apply-KaResults {
  if (-not (Test-Path $script:KaFile)) { return }
  $exe = Join-Path $script:Ld "ldconsole.exe"
  $names = @{}
  try {
    foreach ($it in @(Get-List2)) { $names[[string]$it.idx] = $it.name }
  } catch {}
  $hostip = ""
  try {
    foreach ($line in @(Get-Content $script:KaFile -ErrorAction SilentlyContinue)) {
      $p = ("$line").Trim() -split "\s+"
      if ($p.Count -lt 2) { continue }
      if ($p[0] -eq "HOST") { $hostip = Get-Ipv4Text $p[1]; continue }
      $k = [string]$p[0]
      if ($script:KaDead.ContainsKey($k) -and $script:KaDead[$k]) { continue }
      $instip = Get-Ipv4Text $p[1]
      $nm = $k
      if ($names.ContainsKey($k)) { $nm = $names[$k] }

      if (-not $instip) {
        if (-not $script:Fails.ContainsKey($k)) { $script:Fails[$k] = 0 }
        $script:Fails[$k] = [int]$script:Fails[$k] + 1
        $script:KaBad[$k] = $true
        $n = [int]$script:Fails[$k]
        Write-FailLog ("FAIL {0} idx {1} las 2 URLs fallo {2}/2" -f $nm, $k, $n)
        if ($n -ge 2) {
          Write-FailLog ("REBOOT {0} idx {1} URLS" -f $nm, $k)
          try { & $exe reboot --index $k 2>$null | Out-Null } catch {}
          $script:Fails[$k] = 0
          $script:LastPid[$k] = "-1"
        }
        continue
      }

      if ($hostip -and ($instip -eq $hostip)) {
        $script:KaBad[$k] = $true
        if ($script:KaProxyFail.ContainsKey($k) -and $script:KaProxyFail[$k]) {
          Write-FailLog ("QUIT {0} idx {1} proxy no salio 2 veces {2}" -f $nm, $k, $instip)
          try { & $exe quit --index $k 2>$null | Out-Null } catch {}
          $script:KaDead[$k] = $true
          $script:Fails[$k] = 2
          $script:LastPid[$k] = "-1"
          $script:Booting.Remove($k)
        } else {
          $script:KaProxyFail[$k] = $true
          $script:Fails[$k] = 1
          Write-FailLog ("REBOOT {0} idx {1} MISMA-IP {2}" -f $nm, $k, $instip)
          try { & $exe reboot --index $k 2>$null | Out-Null } catch {}
          $script:LastPid[$k] = "-1"
        }
      } else {
        $script:Fails[$k] = 0
        $script:KaBad[$k] = $false
      }
    }
  } catch {}
  Remove-Item $script:KaFile -Force -ErrorAction SilentlyContinue
}

function Fill-Grid([switch]$ReloadAuto) {
  Apply-KaResults
  $selIdx = $null
  $scroll = 0
  if ($grid.CurrentRow) { $selIdx = [string]$grid.CurrentRow.Cells["idx"].Value }
  try { $scroll = $grid.FirstDisplayedScrollingRowIndex } catch { $scroll = 0 }

  $list = @(Get-List2)
  $byIdx = @{}
  foreach ($it in $list) { $byIdx[[string]$it.idx] = $it }

  $seen = @{}
  foreach ($row in @($grid.Rows)) {
    if ($row.IsNewRow) { continue }
    $k = [string]$row.Cells["idx"].Value
    if (-not $byIdx.ContainsKey($k)) { $grid.Rows.Remove($row); continue }
    $it = $byIdx[$k]
    $st = Row-Estado $it $k
    $fc = Fail-Count $k
    if ([string]$row.Cells["nombre"].Value -ne $it.name) { $row.Cells["nombre"].Value = $it.name }
    if ([string]$row.Cells["estado"].Value -ne $st) { $row.Cells["estado"].Value = $st }
    if ("$($row.Cells["fallos"].Value)" -ne "$fc") { $row.Cells["fallos"].Value = $fc }
    if ([string]$row.Cells["pid"].Value -ne [string]$it.pid) { $row.Cells["pid"].Value = $it.pid }
    if ($ReloadAuto) {
      $byName = Cfg-AutoByName $it.name
      $row.Cells["auto"].Value = if ($byName) { $true } else { [bool](Cfg-Auto $k) }
      $ordn = Cfg-OrdenByName $it.name
      $row.Cells["orden"].Value = if ($ordn -ne "") { $ordn } else { (Cfg-Orden $k) }
      try { $row.Cells["contar"].Value = [bool](Cfg-ContarByName $it.name) } catch {}
    } else {
      try {
        if ($null -eq $row.Cells["contar"].Value) { $row.Cells["contar"].Value = [bool](Cfg-ContarByName $it.name) }
      } catch {}
    }
    $seen[$k] = $true
  }

  foreach ($it in $list) {
    $k = [string]$it.idx
    if ($seen.ContainsKey($k)) { continue }
    $st = Row-Estado $it $k
    [void]$grid.Rows.Add($it.idx, $it.name, $st, (Fail-Count $k), $it.pid, [bool](Cfg-Auto $k), [bool](Cfg-ContarByName $it.name), (Cfg-Orden $k))
  }

  $autoMap = @{}
  $contarMap = @{}
  $ordenMap = @{}
  $nowOrder = @()
  foreach ($row in $grid.Rows) {
    if ($row.IsNewRow) { continue }
    $k = [string]$row.Cells["idx"].Value
    $autoMap[$k] = [bool]$row.Cells["auto"].Value
    try { $contarMap[$k] = [bool]$row.Cells["contar"].Value } catch { $contarMap[$k] = [bool](Cfg-ContarByName ([string]$row.Cells["nombre"].Value)) }
    $ordenMap[$k] = $row.Cells["orden"].Value
    $nowOrder += $k
  }
  if ($grid.IsCurrentCellInEditMode) { return }

  $want = @()
  $want += @($list | Where-Object { $_.alive } | Sort-Object @{ Expression = { Get-SortOrden ([string]$_.idx) $ordenMap } }, idx | ForEach-Object { [string]$_.idx })
  $want += @($list | Where-Object { -not $_.alive } | Sort-Object @{ Expression = { Get-SortOrden ([string]$_.idx) $ordenMap } }, idx | ForEach-Object { [string]$_.idx })
  $needSort = ($nowOrder -join ",") -ne ($want -join ",")
  if ($needSort) {
    $grid.SuspendLayout()
    $grid.Rows.Clear()
    foreach ($k in $want) {
      if (-not $byIdx.ContainsKey($k)) { continue }
      $it = $byIdx[$k]
      $st = Row-Estado $it $k
      $auto = $false
      if ($autoMap.ContainsKey($k)) { $auto = $autoMap[$k] }
      else { $auto = [bool](Cfg-Auto $k) }
      $ord = if ($ordenMap.ContainsKey($k)) { $ordenMap[$k] } else { Cfg-Orden $k }
            $cnt = $false
      if ($contarMap.ContainsKey($k)) { $cnt = $contarMap[$k] } else { $cnt = [bool](Cfg-ContarByName $it.name) }
      [void]$grid.Rows.Add($it.idx, $it.name, $st, (Fail-Count $k), $it.pid, $auto, $cnt, $ord)
    }
    $grid.ResumeLayout()
  }

  if ($selIdx) {
    foreach ($row in $grid.Rows) {
      if ([string]$row.Cells["idx"].Value -eq $selIdx) {
        try { $grid.CurrentCell = $row.Cells["idx"] } catch {}
        break
      }
    }
  }
  if ($scroll -ge 0 -and $scroll -lt $grid.Rows.Count) {
    try { $grid.FirstDisplayedScrollingRowIndex = $scroll } catch {}
  }
  try { Fill-MacroCombo } catch {}
}

function Invoke-Keepalive {
  $adb = Join-Path $script:Ld "adb.exe"
  foreach ($it in Get-List2) {
    if (-not $it.alive) { continue }
    $port = Get-AdbPort $it.idx
    & $adb connect "127.0.0.1:$port" 2>$null | Out-Null
    $ip = (& $adb -s "emulator-$port" shell "curl -s -m 12 https://ipv4.webshare.io" 2>$null | Out-String).Trim()
    if (-not $ip) {
      $ip = (& $adb -s "emulator-$port" shell "wget -qO- -T 12 https://ipv4.webshare.io" 2>$null | Out-String).Trim()
    }
    if ($ip) { Write-Log ("idx {0} ({1}) KA {2}" -f $it.idx, $it.name, $ip) }
    else { Write-Log ("idx {0} ({1}) KA FAIL" -f $it.idx, $it.name) "ERROR" }
  }
}

function Queue-AutoStartsOnce {
  if ($script:AutoDidRun) {
    Write-Log "Auto-inicio ya corrio en esta sesion - no relanzo"
    return
  }
  $script:AutoDidRun = $true
  $script:LaunchQ = New-Object System.Collections.Generic.Queue[int]
  $pending = @()
  foreach ($it in Get-List2) {
    $k = [string]$it.idx
    $auto = Cfg-Auto $k
    if ($it.alive) {
      $script:LastPid[$k] = $it.pid
      Write-Log ("idx {0} ({1}) ya viva - no la toco (auto={2})" -f $it.idx, $it.name, $auto)
    } else {
      $script:LastPid[$k] = "-1"
      if ($script:KaDead.ContainsKey($k) -and $script:KaDead[$k]) {
        Write-Log ("idx {0} ({1}) DEAD proxy - no cola" -f $it.idx, $it.name) "ERROR"
      } elseif ($auto) {
        $pending += [pscustomobject]@{ idx = $it.idx; name = $it.name; ord = (Get-SortOrden $k $null) }
      } else {
        Write-Log ("idx {0} ({1}) auto=NO - no parte" -f $it.idx, $it.name)
      }
    }
  }
  foreach ($p in ($pending | Sort-Object ord, idx)) {
    $script:LaunchQ.Enqueue([int]$p.idx)
    Write-Log ("idx {0} ({1}) en cola AUTO orden {2}" -f $p.idx, $p.name, $p.ord)
  }
  if ($pending.Count -eq 0) { Write-Log "cola auto vacia: ninguna ventana marcada" }
}

function Tick-Engine {
  if (-not $script:Running) { return }
  $list = @(Get-List2)
  $delay = [int]$nudLaunch.Value

  foreach ($it in $list) {
    $k = [string]$it.idx
    $prev = $script:LastPid[$k]

    if (-not $it.alive) {
      $script:LastPid[$k] = "-1"
      $script:Booting.Remove($k)
      continue
    }

    # viva
    $pidChanged = ($null -eq $prev) -or ($prev -eq "-1") -or ($prev -ne $it.pid)
    # primera foto al arrancar el motor: si ya estaba viva, no booteamos
    if ($null -eq $prev) {
      $script:LastPid[$k] = $it.pid
      continue
    }
    if ($pidChanged -and -not $script:Booting.ContainsKey($k)) {
      $script:LastPid[$k] = $it.pid
      if ($script:KaDead.ContainsKey($k) -and $script:KaDead[$k]) {
        Write-Log ("idx {0} ({1}) DEAD proxy - no boot" -f $it.idx, $it.name) "ERROR"
      } else {
        Write-Log ("idx {0} ({1}) cerrada->viva boot pid={2}" -f $it.idx, $it.name, $it.pid)
        Start-BootJob2 $it.idx $it.hwnd
      }
    } else {
      $script:LastPid[$k] = $it.pid
    }
  }

  # lanzar auto-start de a una
  if ($script:LaunchQ.Count -gt 0) {
    $elapsed = (Get-Date) - $script:LastLaunch
    if ($elapsed.TotalSeconds -ge $delay) {
      $n = $script:LaunchQ.Dequeue()
      $still = $list | Where-Object { $_.idx -eq $n } | Select-Object -First 1
      $nk = [string]$n
      if ($script:KaDead.ContainsKey($nk) -and $script:KaDead[$nk]) { continue }
      if ($still -and -not $still.alive) {
        Write-Log "idx $n launch auto"
        $exe = Join-Path $script:Ld "ldconsole.exe"
        & $exe launch --index $n 2>$null | Out-Null
        $script:LastLaunch = Get-Date
      }
    }
  }

  if (((Get-Date) - $script:LastKa).TotalSeconds -ge 300) {
    $script:LastKa = Get-Date
    Sweep-OldLogs
    Start-Job -ScriptBlock {
      param($ld, $outFile)
      $ldc = Join-Path $ld "ldconsole.exe"
      function GrabIp([string]$raw) {
        $m = [regex]::Match("$raw", '(\d{1,3}\.){3}\d{1,3}')
        if ($m.Success) { return $m.Value }
        return ""
      }
      $rows = @()
      $hostRaw = (& curl.exe -s -m 10 https://api.ipify.org 2>$null | Out-String)
      $hostip = GrabIp $hostRaw
      if ($hostip) { $rows += "HOST $hostip" } else { $rows += "HOST NONE" }
      foreach ($line in (& $ldc list2 2>$null)) {
        $p = ("$line").Trim() -split ","
        if ($p.Count -lt 7) { continue }
        if ($p[5] -eq "-1") { continue }
        $idx = [int]$p[0]
        $r1 = & $ldc adb --index $idx --command "shell curl -s -m 20 https://ipv4.webshare.io" 2>$null | Out-String
        $ip = GrabIp $r1
        if (-not $ip) {
          $r2 = & $ldc adb --index $idx --command "shell curl -s -m 20 https://api.ipify.org" 2>$null | Out-String
          $ip = GrabIp $r2
        }
        if ($ip) { $rows += "$idx $ip" } else { $rows += "$idx NONE" }
      }
      if ($rows.Count -gt 0) { $rows | Set-Content $outFile -Encoding ASCII }
    } -ArgumentList $script:Ld, $script:KaFile | Out-Null
  }
}

function Safe-FolderName([string]$s) {
  $t = "$s" -replace '[\\/:*?"<>|]', "_"
  $t = $t.Trim()
  if (-not $t) { $t = "sin_nombre" }
  return $t
}

function Get-FotosRoot {
  $p = ""
  try { $p = [string]$script:FotosPath } catch { $p = "" }
  $p = "$p".Trim()
  if (-not $p) {
    try { $p = $txtXz.Text.Trim() } catch { $p = "" }
  }
  return $p
}

function Find-InstanceShotDir([string]$root, [string]$name) {
  $safe = Safe-FolderName $name
  $cands = @(
    (Join-Path $root (Join-Path $name "Pictures\Screenshots")),
    (Join-Path $root (Join-Path $safe "Pictures\Screenshots")),
    (Join-Path $root (Join-Path $name "Pictures")),
    (Join-Path $root (Join-Path $safe "Pictures"))
  )
  foreach ($c in $cands) {
    if (Test-Path $c) { return $c }
  }
  if (-not (Test-Path $root)) { return $null }
  $hit = Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | Where-Object {
    $_.Name -eq $name -or $_.Name -eq $safe -or $_.Name -like "*$name*"
  } | Select-Object -First 1
  if ($hit) {
    $ss = Join-Path $hit.FullName "Pictures\Screenshots"
    if (Test-Path $ss) { return $ss }
    $pic = Join-Path $hit.FullName "Pictures"
    if (Test-Path $pic) { return $pic }
    return $hit.FullName
  }
  return $null
}

function Get-WinOcr([string]$img) {
  try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime -ErrorAction SilentlyContinue
    $null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
    $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
      $_.Name -eq "AsTask" -and $_.GetParameters().Count -eq 1
    } | Select-Object -First 1
    function Await-Win($op, $t) {
      $m = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq "AsTask" -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1
      } | Select-Object -First 1
      $net = $m.MakeGenericMethod($t).Invoke($null, @($op))
      $net.Wait() | Out-Null
      return $net.Result
    }
    $lang = [Windows.Media.Ocr.OcrEngine]::IsLanguageSupported([Windows.Globalization.Language]::new("es-ES"))
    $eng = $null
    if ($lang) { $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new("es-ES")) }
    if (-not $eng) { $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
    if (-not $eng) { return "" }
    $file = Await-Win ([Windows.Storage.StorageFile]::GetFileFromPathAsync($img)) ([Windows.Storage.StorageFile])
    $stream = Await-Win ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $dec = Await-Win ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bmp = Await-Win ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $res = Await-Win ($eng.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
    return ("$($res.Text)" -replace "[\r\n]+", " ").Trim()
  } catch { return "" }
}


function Parse-ShotStamp([string]$name) {
  $n = [IO.Path]::GetFileNameWithoutExtension($name)
  if ($n -match '(?i)screenshot[_-]?(\d{4})(\d{2})(\d{2})[_-]?(\d{2})(\d{2})(\d{2})') {
    try {
      return [datetime]::ParseExact(($Matches[1]+$Matches[2]+$Matches[3]+$Matches[4]+$Matches[5]+$Matches[6]), "yyyyMMddHHmmss", $null)
    } catch { return $null }
  }
  if ($n -match '(?i)screenshot[_-]?(\d{4})(\d{2})(\d{2})') {
    try { return [datetime]::ParseExact(($Matches[1]+$Matches[2]+$Matches[3]), "yyyyMMdd", $null) } catch { return $null }
  }
  return $null
}

function Get-FolderShotStamp([string]$dir) {
  if (-not $dir -or -not (Test-Path $dir)) { return $null }
  $best = $null
  Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' } | ForEach-Object {
    $dt = Parse-ShotStamp $_.Name
    if (-not $dt) { $dt = $_.LastWriteTime }
    if (-not $best -or $dt -gt $best) { $best = $dt }
  }
  return $best
}

function Parse-ShotTime([string]$file) {
  $n = [IO.Path]::GetFileNameWithoutExtension($file)
  if ($n -match '(?i)screenshot[_-]?(\d{8})[_-](\d{6})') {
    try {
      return [datetime]::ParseExact(($Matches[1] + $Matches[2]), "yyyyMMddHHmmss", [Globalization.CultureInfo]::InvariantCulture)
    } catch {}
  }
  if ($n -match '(?i)(\d{8})[_-](\d{6})') {
    try {
      return [datetime]::ParseExact(($Matches[1] + $Matches[2]), "yyyyMMddHHmmss", [Globalization.CultureInfo]::InvariantCulture)
    } catch {}
  }
  return $null
}

function Get-ShotTime($item) { return (Get-FileShotTime $item) }
function Get-FileShotTime($item) {
  $t = Parse-ShotTime $item.Name
  if ($t) { return $t }
  return $item.LastWriteTime
}

function Get-ShotTime($path) {
  if (-not $path) { return [datetime]::MinValue }
  try {
    if ($path -is [IO.FileInfo]) { return Get-FileShotTime $path }
    if (Test-Path -LiteralPath $path) { return Get-FileShotTime (Get-Item -LiteralPath $path) }
  } catch {}
  return [datetime]::MinValue
}


function Guess-ShotType([string]$file) {
  $n = $file.ToLower()
  if ($n -match "bodega|baul|warehouse|cangku|cangk") { return "bodega" }
  if ($n -match "bolsa|bag|mochila|beibao") { return "mochila" }
  if ($n -match "equipo|equip|zhuangbei") { return "equipo" }
  return "foto"
}

# Layout fijo landscape 1280x720: mundo | baul baul | bolsa bolsa
function Get-DualPanelBox([int]$w, [int]$h, [string]$side) {
  if ($w -ge $h) {
    if ($side -eq "baul")  { return ,@(0.34, 0.14, 0.70, 0.88) }
    return ,@(0.70, 0.12, 0.985, 0.88)
  }
  if ($side -eq "baul") { return ,@(0.04, 0.08, 0.96, 0.50) }
  return ,@(0.04, 0.50, 0.96, 0.92)
}

function Get-CropHash([string]$path, [string]$side) {
  $bmp = $null; $fs = $null; $crop = $null; $tiny = $null; $g = $null
  try {
    $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    $src = New-Object System.Drawing.Bitmap $fs
    $bmp = New-Object System.Drawing.Bitmap $src
    $src.Dispose()
    $fs.Close(); $fs = $null
    $box = Get-DualPanelBox $bmp.Width $bmp.Height $side
    $x = [Math]::Max(0, [int]($box[0] * $bmp.Width))
    $y = [Math]::Max(0, [int]($box[1] * $bmp.Height))
    $x2 = [Math]::Min($bmp.Width, [int]($box[2] * $bmp.Width))
    $y2 = [Math]::Min($bmp.Height, [int]($box[3] * $bmp.Height))
    if (($x2 - $x) -lt 16 -or ($y2 - $y) -lt 16) { return $null }
    $rect = New-Object System.Drawing.Rectangle $x, $y, ($x2 - $x), ($y2 - $y)
    $crop = $bmp.Clone($rect, $bmp.PixelFormat)
    $tiny = New-Object System.Drawing.Bitmap 16, 16
    $g = [System.Drawing.Graphics]::FromImage($tiny)
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
    $g.DrawImage($crop, 0, 0, 16, 16)
    $bits = New-Object System.Text.StringBuilder
    $sum = 0
    $vals = New-Object int[] 256
    $i = 0
    for ($yy = 0; $yy -lt 16; $yy++) {
      for ($xx = 0; $xx -lt 16; $xx++) {
        $c = $tiny.GetPixel($xx, $yy)
        $v = [int]((0.3 * $c.R) + (0.59 * $c.G) + (0.11 * $c.B))
        $vals[$i] = $v; $sum += $v; $i++
      }
    }
    $avg = $sum / 256.0
    for ($i = 0; $i -lt 256; $i++) {
      [void]$bits.Append($(if ($vals[$i] -ge $avg) { "1" } else { "0" }))
    }
    return $bits.ToString()
  } catch { return $null }
  finally {
    if ($g) { $g.Dispose() }
    if ($tiny) { $tiny.Dispose() }
    if ($crop) { $crop.Dispose() }
    if ($bmp) { $bmp.Dispose() }
    if ($fs) { try { $fs.Close() } catch {} }
  }
}

function Test-HashNear([string]$a, [string]$b, [int]$maxDiff = 18) {
  if (-not $a -or -not $b) { return $false }
  if ($a.Length -ne $b.Length) { return $false }
  $d = 0
  for ($i = 0; $i -lt $a.Length; $i++) {
    if ($a[$i] -ne $b[$i]) { $d++; if ($d -gt $maxDiff) { return $false } }
  }
  return $true
}

function Test-SeenHash($list, [string]$h) {
  if (-not $h) { return $false }
  foreach ($old in @($list)) {
    if (Test-HashNear $old $h) { return $true }
  }
  return $false
}

function Only-Digits([string]$s) {
  if (-not $s) { return "" }
  return (($s -replace '[^0-9]', '').Trim())
}

function Read-Currencies([string]$path) {
  $res = [ordered]@{ Oro = ""; Diamantes = ""; MUC = ""; BoundMUC = "" }
  if (-not (Test-Path $path)) { return $res }
  $bmp = $null
  $fs = $null
  try {
    $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    $src = New-Object System.Drawing.Bitmap $fs
    $bmp = New-Object System.Drawing.Bitmap $src
    $src.Dispose()
    $fs.Close(); $fs = $null
    $w = $bmp.Width; $h = $bmp.Height
    if ($w -lt 800 -or $h -lt 400) { return $res }
    # Panel equipar 1280x720: 2x2 abajo al centro
    # $ zen | gema roja
    # lingote | M
    $boxes = [ordered]@{
      Oro       = @(0.390, 0.828, 0.508, 0.895)
      Diamantes = @(0.535, 0.828, 0.658, 0.895)
      BoundMUC  = @(0.390, 0.898, 0.508, 0.968)
      MUC       = @(0.535, 0.898, 0.658, 0.968)
    }
    $tmpd = Join-Path $env:TEMP "farmboss-ocr"
    if (-not (Test-Path $tmpd)) { New-Item -ItemType Directory -Path $tmpd -Force | Out-Null }
    foreach ($k in @("Oro","Diamantes","MUC","BoundMUC")) {
      $a = $boxes[$k]
      $x1 = [Math]::Max(0, [int]($a[0] * $w))
      $y1 = [Math]::Max(0, [int]($a[1] * $h))
      $x2 = [Math]::Min($w, [int]($a[2] * $w))
      $y2 = [Math]::Min($h, [int]($a[3] * $h))
      if (($x2 - $x1) -lt 8 -or ($y2 - $y1) -lt 8) { continue }
      $rect = New-Object System.Drawing.Rectangle $x1, $y1, ($x2 - $x1), ($y2 - $y1)
      $crop = $bmp.Clone($rect, $bmp.PixelFormat)
      $big = New-Object System.Drawing.Bitmap (($x2-$x1)*4), (($y2-$y1)*4)
      $g = [System.Drawing.Graphics]::FromImage($big)
      $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
      $g.DrawImage($crop, 0, 0, $big.Width, $big.Height)
      $tmp = Join-Path $tmpd ("{0}.png" -f $k)
      $big.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png)
      $g.Dispose(); $big.Dispose(); $crop.Dispose()
      $res[$k] = Only-Digits (Get-WinOcr $tmp)
    }
  } catch {
    Write-Log "ocr moneda fallo $path : $_" "WARN"
  } finally {
    if ($bmp) { $bmp.Dispose() }
    if ($fs) { try { $fs.Close() } catch {} }
  }
  return $res
}

function Get-LastConteoTime {
  $f = Join-Path $script:ConteoDir "last_conteo.txt"
  if (Test-Path $f) {
    try { return [datetime]::Parse((Get-Content $f -Raw).Trim()) } catch {}
  }
  return $null
}

function Set-LastConteoTime([datetime]$t) {
  Ensure-Dirs
  $f = Join-Path $script:ConteoDir "last_conteo.txt"
  Set-Content -Path $f -Value $t.ToString("o") -Encoding ASCII
}

function Remove-OldShots([string]$root) {
  if (-not $root -or -not (Test-Path $root)) { return 0 }
  $limit = (Get-Date).AddDays(-7)
  $n = 0
  Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $shot = Join-Path $_.FullName "Pictures\Screenshots"
    if (-not (Test-Path $shot)) { return }
    Get-ChildItem $shot -File -ErrorAction SilentlyContinue | Where-Object {
      $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' -and $_.LastWriteTime -lt $limit
    } | ForEach-Object {
      try { Remove-Item $_.FullName -Force -ErrorAction Stop; $n++ } catch {}
    }
  }
  return $n
}

function Get-NewShotCount([string]$root, [datetime]$since) {
  if (-not $root -or -not (Test-Path $root)) { return 0 }
  $n = 0
  Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $shot = Join-Path $_.FullName "Pictures\Screenshots"
    if (-not (Test-Path $shot)) { return }
    $n += @(Get-ChildItem $shot -File -ErrorAction SilentlyContinue | Where-Object {
      $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' -and (Get-FileShotTime $_) -gt $since
    }).Count
  }
  return $n
}

function Tick-Conteo {
  $root = Get-FotosRoot
  if (-not $root) { return }
  $borradas = Remove-OldShots $root
  if ($borradas -gt 0) { Write-Log ("fotos >7 dias borradas: {0}" -f $borradas) }
  $last = Get-LastConteoTime
  if (-not $last) { $last = (Get-Date).AddMinutes(-10) }
  $nuevas = Get-NewShotCount $root $last
  if ($nuevas -le 0) {
    Write-Log "conteo auto: sin fotos nuevas"
    return
  }
  Write-Log ("conteo auto: {0} foto(s) nueva(s)" -f $nuevas)
  try {
    $out = Invoke-Conteo -Since $last
    Set-LastConteoTime (Get-Date)
    Write-Log ("conteo auto OK -> {0}" -f $out)
  } catch {
    Write-Log "conteo auto fallo: $_" "ERR"
  }
}

function Get-InventarioCatalog {
  $fire = 1..12 | ForEach-Object { "Fluorite Fire $_" }
  $ice  = 1..12 | ForEach-Object { "Fluorite Ice $_" }
  $wind = 1..12 | ForEach-Object { "Fluorite Wind $_" }
  $water= 1..12 | ForEach-Object { "Fluorite Water $_" }
  return @(
    "ORO","MUC","BOUND MUC","DIAMANTES",
    "BLESS","SOUL","LIFE","CHAOS","CREATION",
    "SD SEED","COMBO HEART",
    "CONDOR","GARUDA","WING ENHANCE STONE",
    "HEAVENLY STEEL","ANGEL SIGNET","ROSSY SIGNET",
    "ANILLOS","AROS","COLLARES"
  ) + $fire + $ice + $wind + $water
}

function Get-InventarioXlsx { return (Join-Path $script:ConteoDir "inventario.xls") }
function Get-InventarioJson { return (Join-Path $script:ConteoDir "inventario.json") }
function Get-InventarioLibroJson { return (Join-Path $script:ConteoDir "libro.json") }

function Load-InventarioLibro {
  $f = Get-InventarioLibroJson
  $libro = [ordered]@{}
  if (-not (Test-Path $f)) { return $libro }
  try {
    $raw = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($p in $raw.PSObject.Properties) {
      $arr = @()
      foreach ($L in @($p.Value)) {
        $arr += $L
      }
      $libro[[string]$p.Name] = $arr
    }
  } catch {
    Write-Log "no pude leer libro.json: $_" "WARN"
  }
  return $libro
}

function Save-InventarioLibro($libro) {
  Ensure-Dirs
  $json = $libro | ConvertTo-Json -Depth 8
  Set-Content -Path (Get-InventarioLibroJson) -Value $json -Encoding UTF8
}

function Get-LecturaFecha($L) {
  if (-not $L) { return "" }
  try { if ($L.Fecha) { return [string]$L.Fecha } } catch {}
  try { if ($L.fecha) { return [string]$L.fecha } } catch {}
  return ""
}

function Parse-LecturaWhen([string]$f) {
  if (-not $f) { return $null }
  $dt = [datetime]::MinValue
  $fmts = @("yyyy-MM-dd HH:mm","yyyy-MM-dd HH:mm:ss","dd-MM-yyyy HH:mm","dd-MM-yyyy","yyyy-MM-dd")
  foreach ($fmt in $fmts) {
    if ([datetime]::TryParseExact($f, $fmt, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$dt)) {
      return $dt
    }
  }
  if ([datetime]::TryParse($f, [ref]$dt)) { return $dt }
  return $null
}

function Get-ItemSide($datos, [string]$item, [string]$side) {
  if (-not $datos) { return [int64]0 }
  $n = $null
  try { $n = $datos.$item } catch {}
  if (-not $n) {
    try { if ($datos[$item]) { $n = $datos[$item] } } catch {}
  }
  if (-not $n) { return [int64]0 }
  try {
    if ($side -eq "Bolsa") { return [int64]$n.Bolsa }
    if ($side -eq "Baul")  { return [int64]$n.Baul }
    $b = 0; $v = 0
    try { $b = [int64]$n.Bolsa } catch {}
    try { $v = [int64]$n.Baul } catch {}
    return [int64]($b + $v)
  } catch { return [int64]0 }
}

function Get-MucOf($L) {
  $datos = $null
  try { if ($L.Datos) { $datos = $L.Datos } } catch {}
  if ($datos) {
    $t = Get-ItemSide $datos "MUC" "Total"
    if ($t -gt 0) { return $t }
    $b = Get-ItemSide $datos "MUC" "Bolsa"
    if ($b -gt 0) { return $b }
  }
  try {
    if ($L.bolsa -and $L.bolsa.MUC) { return [int64]$L.bolsa.MUC }
    if ($L.bolsa -and $L.bolsa["MUC"]) { return [int64]$L.bolsa["MUC"] }
  } catch {}
  return [int64]0
}

function Get-SortedLecturas($arr) {
  $list = @()
  foreach ($L in @($arr)) {
    if (-not $L) { continue }
    $f = Get-LecturaFecha $L
    if (-not $f -or $f -match "^LECTURA") { continue }
    $when = Parse-LecturaWhen $f
    $list += [pscustomobject]@{ When = $when; Fecha = $f; L = $L }
  }
  return @($list | Sort-Object { if ($_.When) { $_.When } else { [datetime]::MinValue } }, Fecha)
}

function Test-LecturaBolsa($L) {
  $datos = $null
  try { $datos = $L.Datos } catch {}
  if (-not $datos) { return $false }
  foreach ($p in @($datos.PSObject.Properties)) {
    if ($p.Name -in @("ORO","MUC","BOUND MUC","DIAMANTES")) { continue }
    $t = 0
    try { $t = [int64]$p.Value.Bolsa + [int64]$p.Value.Baul } catch { $t = 0 }
    if ($t -gt 0) { return $true }
  }
  return $false
}

function Get-LecturasVisibles($arr) {
  $s = @(Get-SortedLecturas $arr)
  $vivas = @()
  foreach ($x in $s) {
    $m = [int64](Get-MucOf $x.L)
    $o = 0
    try { $o = [int64](Get-ItemSide $x.L.Datos "ORO" "Total") } catch {}
    if ($m -le 0 -and $o -le 0 -and -not (Test-LecturaBolsa $x.L)) { continue }
    $vivas += $x
  }
  $con = @($vivas | Where-Object { Test-LecturaBolsa $_.L })
  if ($con.Count -gt 0) { return $con }
  if ($vivas.Count -gt 0) { return $vivas }
  return $s
}

function Get-MucLecturas($arr) {
  $all = @(Get-LecturasVisibles $arr)
  $s = @()
  foreach ($x in $all) {
    if (-not $x.When) { continue }
    $m = [int64](Get-MucOf $x.L)
    if ($m -le 0) { continue }
    $s += [pscustomobject]@{ When = [datetime]$x.When; M = $m }
  }
  return @($s)
}

function Get-MucActual($arr) {
  $s = @(Get-MucLecturas $arr)
  if ($s.Count -gt 0) { return [int64]$s[-1].M }
  return [int64]0
}

function Get-MucRate($arr) {
  $r = @{ Hora = [double]0; Diario = [int64]0 }
  $s = @(Get-MucLecturas $arr)
  if ($s.Count -lt 2) { return $r }
  $hasta = $s.Count - 1
  if ([int64]$s[-1].M -le [int64]$s[-2].M) { $hasta = $s.Count - 2 }
  for ($i = $hasta; $i -ge 1; $i--) {
    $dm = [double]([int64]$s[$i].M - [int64]$s[$i-1].M)
    if ($dm -le 0) { continue }
    $hours = ([datetime]$s[$i].When - [datetime]$s[$i-1].When).TotalHours
    if ($hours -lt 0.02) { continue }
    $hora = $dm / $hours
    $r.Hora = [math]::Round($hora, 1)
    $r.Diario = [int64][math]::Round($hora * 24.0)
    return $r
  }
  return $r
}

function Merge-Libros($a, $b) {
  $out = [ordered]@{}
  $names = @()
  foreach ($k in @($a.Keys)) { if ($k -and $names -notcontains $k) { $names += $k } }
  foreach ($k in @($b.Keys)) { if ($k -and $names -notcontains $k) { $names += $k } }
  foreach ($nm in $names) {
    $seen = @{}
    $arr = @()
    foreach ($src in @($b[$nm], $a[$nm])) {
      foreach ($L in @($src)) {
        $f = Get-LecturaFecha $L
        if (-not $f) { continue }
        if ($seen.ContainsKey($f)) {
          $arr[[int]$seen[$f]] = $L
          continue
        }
        $seen[$f] = $arr.Count
        $arr += $L
      }
    }
    $sorted = @(Get-SortedLecturas $arr)
    $keep = @($sorted | ForEach-Object { $_.L })
    if ($keep.Count -gt 60) { $keep = $keep[($keep.Count-60)..($keep.Count-1)] }
    $out[$nm] = $keep
  }
  return $out
}

function Load-PeerLibro([string]$peer) {
  $libro = [ordered]@{}
  if (-not $peer) { return $libro }
  $f = $peer
  if (Test-Path $peer -PathType Container) {
    $f = Join-Path $peer "libro.json"
  }
  if (-not (Test-Path $f)) { return $libro }
  try {
    $raw = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($p in $raw.PSObject.Properties) {
      $arr = @()
      foreach ($L in @($p.Value)) { $arr += $L }
      $libro[[string]$p.Name] = $arr
    }
    Write-Log ("maestro peer leido {0} cuentas" -f $libro.Keys.Count)
  } catch {
    Write-Log "maestro peer fallo: $_" "WARN"
  }
  return $libro
}


function Get-ServerTag {
  $t = $env:COMPUTERNAME
  if (-not $t) { $t = "PC" }
  return (($t.Trim() -replace '[^A-Za-z0-9_-]', '_'))
}

function Invoke-GitHubGet([string]$repoPath) {
  $tok = Get-GitHubToken
  if (-not $tok) { return $null }
  $enc = [Uri]::EscapeDataString($repoPath)
  $api = "https://api.github.com/repos/jorgemazu/farmboss-inventario/contents/$enc"
  $hdr = Get-GitHubHeaders $tok
  try { return Invoke-RestMethod -Uri $api -Headers $hdr -Method Get } catch { return $null }
}

function Save-GitHubFileTo([string]$repoPath, [string]$dest) {
  $cur = Invoke-GitHubGet $repoPath
  if (-not $cur) { return $false }
  $b64 = ""
  try { $b64 = ([string]$cur.content) -replace '\s','' } catch { return $false }
  if (-not $b64) { return $false }
  try {
    $bytes = [Convert]::FromBase64String($b64)
    $dir = Split-Path $dest
    if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    [IO.File]::WriteAllBytes($dest, $bytes)
    return $true
  } catch { return $false }
}

function Merge-GitHubLibros($libro) {
  if (-not $libro) { $libro = [ordered]@{} }
  $tok = Get-GitHubToken
  if (-not $tok) { return $libro }
  $listing = Invoke-GitHubGet "servidores"
  if (-not $listing) { return $libro }
  $n = 0
  foreach ($d in @($listing)) {
    $tipo = ""
    try { $tipo = [string]$d.type } catch { continue }
    if ($tipo -ne "dir") { continue }
    $nm = [string]$d.name
    if (-not $nm) { continue }
    if ($nm -eq (Get-ServerTag)) { continue }
    $tmp = Join-Path $env:TEMP ("farmboss-libro-" + $nm + ".json")
    if (-not (Save-GitHubFileTo ("servidores/{0}/libro.json" -f $nm) $tmp)) { continue }
    $otro = Load-PeerLibro $tmp
    if ($otro.Keys.Count -gt 0) {
      $libro = Merge-Libros $libro $otro
      $n++
      Write-Log ("github libro {0}: {1} cuentas" -f $nm, $otro.Keys.Count)
    }
  }
  Write-Log ("github maestros unidos {0}" -f $n)
  return $libro
}

function Publish-ServidorGitHub([string]$xls) {
  $tok = Get-GitHubToken
  if (-not $tok) { return }
  $tag = Get-ServerTag
  $libro = Get-InventarioLibroJson
  if (Test-Path $libro) {
    [void](Publish-GitHubFile $libro ("servidores/{0}/libro.json" -f $tag) ("libro {0} {1}" -f $tag, (Get-Date -Format "yyyy-MM-dd HH:mm")))
  }
}

function Get-MaestroPeerPath { return "" }

function Get-MaestroGitUrl {
  return "https://github.com/jorgemazu/farmboss-inventario/blob/main/inventario.xls"
}

function Open-FotosGitLocal {
  $tok = Get-GitHubToken
  if (-not $tok) { return "falta github.token" }
  $root = Join-Path $script:Root "fotos-git"
  if (-not (Test-Path $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
  $dirs = @(Invoke-GitHubGet "fotos")
  if ($dirs.Count -eq 0) { return "git sin fotos" }
  $n = 0
  foreach ($d in $dirs) {
    $tipo = ""; $nm = ""
    try { $tipo = [string]$d.type; $nm = [string]$d.name } catch { continue }
    if (-not $nm) { continue }
    if ($tipo -eq "file") {
      $dest = Join-Path $root $nm
      if (Save-GitHubFileTo ("fotos/" + $nm) $dest) { $n++ }
      continue
    }
    if ($tipo -ne "dir") { continue }
    $files = @(Invoke-GitHubGet ("fotos/" + $nm))
    foreach ($f in $files) {
      $ft = ""; $fn = ""
      try { $ft = [string]$f.type; $fn = [string]$f.name } catch { continue }
      if ($ft -ne "file" -or -not $fn) { continue }
      $dest = Join-Path (Join-Path $root $nm) $fn
      if (Save-GitHubFileTo ("fotos/" + $nm + "/" + $fn) $dest) { $n++ }
    }
  }
  if ($n -le 0) { return "no baje fotos" }
  Start-Process explorer.exe $root
  return ("fotos git {0}" -f $n)
}

function Open-MaestroGitLocal {
  $tok = Get-GitHubToken
  if (-not $tok) { return "falta github.token" }
  Ensure-Dirs
  $dest = Join-Path $script:ConteoDir "inventario-git.xls"
  if (-not (Save-GitHubFileTo "inventario.xls" $dest)) { return "no baje el maestro" }
  try { Start-Process $dest } catch { Start-Process explorer.exe $script:ConteoDir }
  return "maestro bajado"
}

function Set-MaestroLink([string]$xls) {
  $u = Get-MaestroGitUrl
  try {
    if ($script:LnkMaestro) {
      $script:LnkMaestro.Text = $u
      $script:LnkMaestro.Links.Clear()
      [void]$script:LnkMaestro.Links.Add(0, $u.Length, $u)
    }
  } catch {}
  try {
    if ($lbl) { $lbl.Text = "maestro $u" }
  } catch {}
  Write-Log ("maestro link {0}" -f $u)
}

function Unir-MaestroAuto($libro) {
  if (-not $libro) { $libro = Load-InventarioLibro }
  Save-InventarioLibro $libro
  try { Publish-ServidorGitHub "" } catch { Write-Log "github servidor: $_" "WARN" }
  Write-Log ("libro guardado cuentas={0} sin excel" -f $libro.Keys.Count)
  return @{ libro = $libro; xls = $null }
}

function Get-CuentaNumero {
  $n = ""
  try { if ($script:TxtCuenta) { $n = [string]$script:TxtCuenta.Text } } catch { $n = "" }
  $n = $n.Trim()
  if ($n) { return $n }
  try {
    $cfg = Load-Cfg
    return ([string]$cfg.cuentaNumero).Trim()
  } catch { return "" }
}

function Get-AccesoCuenta {
  $n = Get-CuentaNumero
  if (-not $n) { return @{ ok = $false; error = "guarda el numero de cuenta"; todas = $false; nombres = @(); actualizar = $false; programa = "" } }
  $tmp = Join-Path $script:ConteoDir "cuentas.json"
  if (-not (Save-GitHubFileTo "cuentas.json" $tmp)) { return @{ ok = $false; error = "no baje cuentas.json"; todas = $false; nombres = @(); actualizar = $false; programa = "" } }
  $raw = Get-Content $tmp -Raw -Encoding UTF8 | ConvertFrom-Json
  $row = $null
  if ($raw.cuentas) {
    $row = @($raw.cuentas.PSObject.Properties | Where-Object { $_.Name -eq $n } | Select-Object -First 1)
  }
  if (-not $row -or $row.Count -eq 0) { return @{ ok = $false; error = "esa cuenta no existe"; todas = $false; nombres = @(); actualizar = $false; programa = "" } }
  $v = $row[0].Value
  $todas = $false
  $nombres = @()
  foreach ($i in @($v.instancias)) {
    $s = [string]$i
    if ($s -eq "*") { $todas = $true } elseif ($s) { $nombres += $s }
  }
  $act = $false
  try { $act = [bool]$v.actualizar } catch { $act = $false }
  return @{ ok = $true; error = ""; todas = $todas; nombres = $nombres; actualizar = $act; programa = [string]$raw.programa }
}

function Limit-LibroCuenta($libro) {
  $acc = Get-AccesoCuenta
  if (-not $acc.ok) { throw $acc.error }
  if ($acc.todas) { return $libro }
  $allow = @{}
  foreach ($n in @($acc.nombres)) { $allow[$n.ToLower()] = $true }
  $out = [ordered]@{}
  foreach ($k in @($libro.Keys)) {
    if ($allow.Contains([string]$k.ToLower())) { $out[$k] = $libro[$k] }
  }
  return $out
}

function Invoke-ActualizarPrograma {
  $nuevo = Join-Path $script:Root "FarmBoss.ps1.nuevo"
  if (-not (Save-GitHubFileTo "programa/FarmBoss.ps1" $nuevo)) { throw "no baje el programa nuevo" }
  $len = (Get-Item $nuevo).Length
  if ($len -lt 20000) { throw "el programa bajado esta incompleto" }
  $dest = Join-Path $script:Root "FarmBoss.ps1"
  Copy-Item -LiteralPath $nuevo -Destination $dest -Force
  Remove-Item $nuevo -Force -ErrorAction SilentlyContinue
  return "FarmBoss actualizado"
}

function Invoke-ListaMaestra {
  $libro = Load-InventarioLibro
  try { $libro = Merge-GitHubLibros $libro } catch { Write-Log "github merge: $_" "WARN" }
  $libro = Limit-LibroCuenta $libro
  $xls = Write-InventarioLibro $libro
  $dest = Join-Path $script:ConteoDir "inventario-maestro.xls"
  if ((Test-Path $xls) -and ($xls -ne $dest)) {
    Copy-Item -LiteralPath $xls -Destination $dest -Force
  }
  try { Start-Process $dest } catch { Start-Process explorer.exe $script:ConteoDir }
  Write-Log ("lista maestra {0} cuentas={1}" -f $dest, $libro.Keys.Count)
  return $dest
}

function Load-InventarioState {
  $f = Get-InventarioJson
  $items = Get-InventarioCatalog
  $empty = {
    param($label)
    $m = [ordered]@{}
    foreach ($it in $items) { $m[$it] = [ordered]@{ Bolsa = 0; Baul = 0; Total = 0 } }
    return [ordered]@{ Fecha = $label; Datos = $m }
  }
  if (Test-Path $f) {
    try {
      $raw = Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json
      $lect = @()
      foreach ($L in @($raw.Lecturas)) {
        $m = [ordered]@{}
        foreach ($it in $items) {
          $n = $L.Datos.$it
          if ($n) {
            $b = 0; $v = 0
            try { $b = [int64]$n.Bolsa } catch { $b = 0 }
            try { $v = [int64]$n.Baul } catch { $v = 0 }
            $m[$it] = [ordered]@{ Bolsa = $b; Baul = $v; Total = ($b + $v) }
          } else {
            $m[$it] = [ordered]@{ Bolsa = 0; Baul = 0; Total = 0 }
          }
        }
        $lect += [ordered]@{ Fecha = [string]$L.Fecha; Datos = $m }
      }
      return ,$lect
    } catch {
      Write-Log "no pude leer inventario.json: $_" "WARN"
    }
  }
  return @()
}

function Save-InventarioState($lecturas) {
  Ensure-Dirs
  $payload = [ordered]@{
    Actualizado = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    Lecturas = @($lecturas)
  }
  $json = $payload | ConvertTo-Json -Depth 6
  Set-Content -Path (Get-InventarioJson) -Value $json -Encoding UTF8
}


function New-InvLectura([string]$fecha, $bolsa, $baul, [string]$motor = "") {
  $m = New-InvDatos $bolsa $baul
  return [ordered]@{ Fecha = $fecha; Datos = $m; Motor = $motor }
}

function Add-InvLectura($bolsa, $baul, [string]$fecha) {
  Ensure-Dirs
  if (-not $fecha) { $fecha = Get-Date -Format "dd-MM-yyyy" }
  $lect = @(Load-InventarioState)
  $nueva = New-InvLectura $fecha $bolsa $baul
  $filled = @($lect | Where-Object { $_.Fecha -and ("$($_.Fecha)" -notmatch "^LECTURA") })
  $filled = @($filled + $nueva)
  if ($filled.Count -gt 60) { $filled = $filled[($filled.Count-60)..($filled.Count-1)] }
  Save-InventarioState $filled
  $xlsx = Write-InventarioXlsx $filled
  # csv de respaldo
  $csv = Join-Path $script:ConteoDir "inventario.csv"
  $items = Get-InventarioCatalog
  $lines = New-Object System.Collections.Generic.List[string]
  $hdr = @("#","ITEM")
  foreach ($L in $filled) {
    $f = if ($L.Fecha) { $L.Fecha } else { "LECTURA" }
    $hdr += @("$f BOLSA","$f BAUL","$f TOTAL")
  }
  $lines.Add(($hdr -join ";"))
  $n = 1
  foreach ($it in $items) {
    $row = @("$n", $it)
    foreach ($L in $filled) {
      $b = 0; $v = 0
      if ($L.Datos -and $L.Datos[$it]) { $b = [int64]$L.Datos[$it].Bolsa; $v = [int64]$L.Datos[$it].Baul }
      $row += @("$b","$v","$($b+$v)")
    }
    $lines.Add(($row -join ";"))
    $n++
  }
  $utf8 = New-Object System.Text.UTF8Encoding $true
  [IO.File]::WriteAllLines($csv, $lines, $utf8)
  Write-Log ("conteo escrito {0}" -f $xlsx)
  return $xlsx
}


function Get-SheetName([string]$n) {
  $s = ("$n" -replace '[\\/*?:\[\]]', '_').Trim()
  if ($s.Length -gt 31) { $s = $s.Substring(0,31) }
  if (-not $s) { $s = "Instancia" }
  return $s
}

function Write-InventarioLibro($libro) {
  Ensure-Dirs
  $items = Get-InventarioCatalog
  $nl = "`r`n"
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('<?xml version="1.0" encoding="UTF-8"?>' + $nl)
  [void]$sb.Append('<?mso-application progid="Excel.Sheet"?>' + $nl)
  [void]$sb.Append('<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' + $nl)
  [void]$sb.Append('<Styles>')
  [void]$sb.Append('<Style ss:ID="hdr"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1F4E79" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d1"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#2E75B6" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d2"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#548235" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d3"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#C65911" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="item"><Font ss:Bold="1"/><Interior ss:Color="#D6DCE4" ss:Pattern="Solid"/></Style>')
  [void]$sb.Append('<Style ss:ID="tot"><Font ss:Bold="1"/><Interior ss:Color="#FFF2CC" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/><NumberFormat ss:Format="#,##0"/></Style>')
  [void]$sb.Append('<Style ss:ID="num"><Alignment ss:Horizontal="Center"/><NumberFormat ss:Format="#,##0"/></Style>')
  [void]$sb.Append('<Style ss:ID="kpi"><Font ss:Bold="1" ss:Size="12" ss:Color="#FFFFFF"/><Interior ss:Color="#C45911" ss:Pattern="Solid"/></Style>')
  [void]$sb.Append('<Style ss:ID="kpv"><Font ss:Bold="1" ss:Size="12"/><Interior ss:Color="#FCE4D6" ss:Pattern="Solid"/><NumberFormat ss:Format="#,##0"/></Style>')
  [void]$sb.Append('<Style ss:ID="kph"><Font ss:Bold="1" ss:Size="12"/><Interior ss:Color="#FCE4D6" ss:Pattern="Solid"/><NumberFormat ss:Format="#,##0.0"/></Style>')
  [void]$sb.Append('</Styles>' + $nl)
  $gen = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $mot = "desconocido"
  $py = ""
  if ($script:ConteoMeta) {
    if ($script:ConteoMeta.generado) { $gen = [string]$script:ConteoMeta.generado }
    if ($script:ConteoMeta.motor) { $mot = [string]$script:ConteoMeta.motor }
    if ($script:ConteoMeta.python) { $py = [string]$script:ConteoMeta.python }
  }

  # RESUMEN: cuentas de este conteo primero. Las de otros servidores se quedan.
  # El mismo nombre es una sola fila: la lectura nueva pisa la vieja.
  $selRes = @(Get-CuentasSeleccionadas)
  $resNames = @()
  foreach ($nm in @($selRes)) {
    if ($nm -and $libro.Contains($nm) -and $resNames -notcontains $nm) { $resNames += $nm }
  }
  foreach ($nm in @($libro.Keys)) {
    if ($nm -and $resNames -notcontains $nm) { $resNames += $nm }
  }
  $sumAct = [int64]0
  $sumHora = [double]0
  $sumDia = [int64]0
  $filas = @()
  foreach ($nm in $resNames) {
    if (-not $libro.Contains($nm)) { continue }
    $lect = @($libro[$nm])
    $act = Get-MucActual $lect
    $rate = Get-MucRate $lect
    $hora = [double]$rate.Hora
    $dia = [int64]$rate.Diario
    $sumAct += $act
    $sumHora += $hora
    $sumDia += $dia
    if ($act -eq 0 -and $hora -eq 0 -and $dia -eq 0) { continue }
    $filas += [pscustomobject]@{ Nombre = $nm; Actual = $act; Hora = $hora; Diario = $dia }
  }
  if ($filas.Count -gt 0) {
  $inv = [Globalization.CultureInfo]::InvariantCulture
  $sumHoraTxt = [string]::Format($inv, "{0:0.0}", $sumHora)
  [void]$sb.Append('<Worksheet ss:Name="RESUMEN"><Table>')
  [void]$sb.Append('<Column ss:Width="160"/><Column ss:Width="120"/><Column ss:Width="120"/><Column ss:Width="120"/>')
  [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">TOTAL</Data></Cell>')
  if ($sumAct -ne 0) { [void]$sb.Append("<Cell ss:Index=`"2`" ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$sumAct</Data></Cell>") }
  [void]$sb.Append("<Cell ss:Index=`"3`" ss:StyleID=`"kph`"><Data ss:Type=`"Number`">$sumHoraTxt</Data></Cell>")
  if ($sumDia -ne 0) { [void]$sb.Append("<Cell ss:Index=`"4`" ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$sumDia</Data></Cell>") }
  [void]$sb.Append("</Row>" + $nl)
  [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">Personaje</Data></Cell>')
  [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">MUC actual</Data></Cell>')
  [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">MUC/hora</Data></Cell>')
  [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">MUC diario</Data></Cell></Row>' + $nl)
  foreach ($f in $filas) {
    $esc = ($f.Nombre -replace '&','&' -replace '<',' ')
    $horaTxt = [string]::Format($inv, "{0:0.0}", [double]$f.Hora)
    [void]$sb.Append("<Row><Cell ss:StyleID=`"item`"><Data ss:Type=`"String`">$esc</Data></Cell>")
    if ($f.Actual -ne 0) { [void]$sb.Append("<Cell ss:Index=`"2`" ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$($f.Actual)</Data></Cell>") }
    [void]$sb.Append("<Cell ss:Index=`"3`" ss:StyleID=`"kph`"><Data ss:Type=`"Number`">$horaTxt</Data></Cell>")
    if ($f.Diario -ne 0) { [void]$sb.Append("<Cell ss:Index=`"4`" ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$($f.Diario)</Data></Cell>") }
    [void]$sb.Append("</Row>" + $nl)
  }
  [void]$sb.Append('</Table></Worksheet>' + $nl)
  }

  [void]$sb.Append('<Worksheet ss:Name="META"><Table>')
  [void]$sb.Append('<Column ss:Width="160"/><Column ss:Width="420"/>')
  [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">campo</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">valor</Data></Cell></Row>')
  [void]$sb.Append(('<Row><Cell><Data ss:Type="String">generado</Data></Cell><Cell><Data ss:Type="String">{0}</Data></Cell></Row>' -f $gen))
  [void]$sb.Append(('<Row><Cell><Data ss:Type="String">motor</Data></Cell><Cell><Data ss:Type="String">{0}</Data></Cell></Row>' -f $mot))
  [void]$sb.Append(('<Row><Cell><Data ss:Type="String">python</Data></Cell><Cell><Data ss:Type="String">{0}</Data></Cell></Row>' -f ($py -replace '&','y')))
  [void]$sb.Append(('<Row><Cell><Data ss:Type="String">farmboss</Data></Cell><Cell><Data ss:Type="String">{0}</Data></Cell></Row>' -f $script:Version))
  $err = ""
  if ($script:ConteoMeta -and $script:ConteoMeta.error) { $err = [string]$script:ConteoMeta.error }
  $err = ($err -replace "&","y" -replace "<"," " -replace ">"," ")
  if ($err.Length -gt 300) { $err = $err.Substring(0,300) }
  if ($err) {
    [void]$sb.Append(('<Row><Cell><Data ss:Type="String">error</Data></Cell><Cell><Data ss:Type="String">{0}</Data></Cell></Row>' -f $err))
  }
  if ($script:ConteoMeta -and $script:ConteoMeta.cuentas) {
    foreach ($cn in @($script:ConteoMeta.cuentas.Keys)) {
      $cv = [string]$script:ConteoMeta.cuentas[$cn]
      if (-not $cv) { continue }
      $esc = ($cn -replace '&','y')
      [void]$sb.Append(("<Row><Cell><Data ss:Type=`"String`">cuenta {0}</Data></Cell><Cell><Data ss:Type=`"String`">{1}</Data></Cell></Row>" -f $esc,$cv))
    }
  }
  [void]$sb.Append('</Table></Worksheet>' + $nl)

  $stylesCycle = @("d1","d2","d3")
  foreach ($name in $libro.Keys) {
    $sorted = @(Get-LecturasVisibles $libro[$name])
    if ($sorted.Count -eq 0) { continue }
    $pack = New-Object System.Collections.Generic.List[object]
    foreach ($it in $items) {
      $vals = New-Object System.Collections.Generic.List[object]
      $any = $false
      foreach ($row in $sorted) {
        $datos = $null
        try { $datos = $row.L.Datos } catch {}
        $b = [int64](Get-ItemSide $datos $it "Bolsa")
        $v = [int64](Get-ItemSide $datos $it "Baul")
        $t = [int64]($b + $v)
        if ($b -ne 0 -or $v -ne 0) { $any = $true }
        $vals.Add(@($b, $v, $t))
      }
      if ($any) { $pack.Add([pscustomobject]@{ Item = $it; Vals = @($vals.ToArray()) }) }
    }
    if ($pack.Count -eq 0) { continue }
    $keep = New-Object System.Collections.Generic.List[int]
    for ($ri = 0; $ri -lt $sorted.Count; $ri++) {
      $hit = $false
      foreach ($p in $pack) {
        $vv = @($p.Vals[$ri])
        if ([int64]$vv[0] -ne 0 -or [int64]$vv[1] -ne 0) { $hit = $true; break }
      }
      if ($hit) { $keep.Add($ri) }
    }
    if ($keep.Count -eq 0) { continue }
    $sheet = Get-SheetName $name
    $act = Get-MucActual $libro[$name]
    $rate = Get-MucRate $libro[$name]
    $hora = [double]$rate.Hora
    $dia = [int64]$rate.Diario
    $horaTxt = [string]::Format([Globalization.CultureInfo]::InvariantCulture, "{0:0.0}", $hora)
    [void]$sb.Append(("<Worksheet ss:Name=`"{0}`"><Table>" -f $sheet) + $nl)
    [void]$sb.Append('<Column ss:Width="28"/><Column ss:Width="150"/>')
    1..(3 * $keep.Count) | ForEach-Object { [void]$sb.Append('<Column ss:Width="64"/>') }
    [void]$sb.Append($nl)
    [void]$sb.Append("<Row><Cell ss:StyleID=`"kpi`"><Data ss:Type=`"String`">MUC actual</Data></Cell>")
    if ($act -ne 0) { [void]$sb.Append("<Cell ss:Index=`"2`" ss:StyleID=`"kpv`"><Data ss:Type=`"Number`">$act</Data></Cell>") }
    [void]$sb.Append("<Cell ss:Index=`"3`" ss:StyleID=`"kpi`"><Data ss:Type=`"String`">MUC/hora</Data></Cell>")
    [void]$sb.Append("<Cell ss:Index=`"4`" ss:StyleID=`"kph`"><Data ss:Type=`"Number`">$horaTxt</Data></Cell>")
    [void]$sb.Append("<Cell ss:Index=`"5`" ss:StyleID=`"kpi`"><Data ss:Type=`"String`">MUC diario</Data></Cell>")
    if ($dia -ne 0) { [void]$sb.Append("<Cell ss:Index=`"6`" ss:StyleID=`"kpv`"><Data ss:Type=`"Number`">$dia</Data></Cell>") }
    [void]$sb.Append("</Row>" + $nl)
    [void]$sb.Append("<Row><Cell ss:StyleID=`"item`" ss:MergeAcross=`"1`"><Data ss:Type=`"String`"># ITEM</Data></Cell>")
    $si = 0
    foreach ($ri in $keep) {
      $st = $stylesCycle[$si % 3]
      $lab = [string]$sorted[$ri].Fecha
      [void]$sb.Append("<Cell ss:StyleID=`"$st`" ss:MergeAcross=`"2`"><Data ss:Type=`"String`">$lab</Data></Cell>")
      $si++
    }
    [void]$sb.Append("</Row>" + $nl)
    [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">#</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">ITEM</Data></Cell>')
    $si = 0
    foreach ($ri in $keep) {
      $st = $stylesCycle[$si % 3]
      foreach ($h in @("BOLSA","BAUL","TOTAL")) {
        [void]$sb.Append("<Cell ss:StyleID=`"$st`"><Data ss:Type=`"String`">$h</Data></Cell>")
      }
      $si++
    }
    [void]$sb.Append("</Row>" + $nl)
    $n = 1
    foreach ($p in $pack) {
      $escIt = ($p.Item -replace '&','&amp;')
      [void]$sb.Append("<Row><Cell><Data ss:Type=`"Number`">$n</Data></Cell><Cell ss:StyleID=`"item`"><Data ss:Type=`"String`">$escIt</Data></Cell>")
      $ki = 0
      foreach ($ri in $keep) {
        $vv = @($p.Vals[$ri])
        $b = [int64]$vv[0]
        $v = [int64]$vv[1]
        $t = [int64]$vv[2]
        $base = 3 + ($ki * 3)
        if ($b -ne 0) { [void]$sb.Append("<Cell ss:Index=`"$base`" ss:StyleID=`"num`"><Data ss:Type=`"Number`">$b</Data></Cell>") }
        if ($v -ne 0) { [void]$sb.Append("<Cell ss:Index=`"$($base+1)`" ss:StyleID=`"num`"><Data ss:Type=`"Number`">$v</Data></Cell>") }
        if ($t -ne 0) { [void]$sb.Append("<Cell ss:Index=`"$($base+2)`" ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$t</Data></Cell>") }
        $ki++
      }
      [void]$sb.Append("</Row>" + $nl)
      $n++
    }
    [void]$sb.Append('</Table></Worksheet>' + $nl)
  }
  [void]$sb.Append('</Workbook>')
  $out = Get-InventarioXlsx
  $utf8 = New-Object System.Text.UTF8Encoding $true
  [IO.File]::WriteAllText($out, $sb.ToString(), $utf8)
  $maestro = Join-Path $script:ConteoDir "inventario-maestro.xls"
  [IO.File]::Copy($out, $maestro, $true)
  return $out
}

function Write-InventarioXlsx($lecturas) {
  Ensure-Dirs
  $items = Get-InventarioCatalog
  while ($lecturas.Count -lt 3) {
    $lecturas = @($lecturas) + @(
      [ordered]@{ Fecha = ""; Datos = $null }
    )
  }
  $L = @($lecturas)
  $nl = "`r`n"
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('<?xml version="1.0" encoding="UTF-8"?>' + $nl)
  [void]$sb.Append('<?mso-application progid="Excel.Sheet"?>' + $nl)
  [void]$sb.Append('<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' + $nl)
  [void]$sb.Append('<Styles>')
  [void]$sb.Append('<Style ss:ID="hdr"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1F4E79" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d1"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#2E75B6" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d2"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#548235" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="d3"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#C65911" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="item"><Font ss:Bold="1"/><Interior ss:Color="#D6DCE4" ss:Pattern="Solid"/></Style>')
  [void]$sb.Append('<Style ss:ID="tot"><Font ss:Bold="1"/><Interior ss:Color="#FFF2CC" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/><NumberFormat ss:Format="#,##0"/></Style>')
  [void]$sb.Append('<Style ss:ID="num"><Alignment ss:Horizontal="Center"/><NumberFormat ss:Format="#,##0"/></Style>')
  [void]$sb.Append('</Styles>' + $nl)
  [void]$sb.Append('<Worksheet ss:Name="Inventario"><Table>' + $nl)
  [void]$sb.Append('<Column ss:Width="30"/><Column ss:Width="160"/>')
  1..9 | ForEach-Object { [void]$sb.Append('<Column ss:Width="70"/>') }
  [void]$sb.Append($nl)
  $f1 = if ($L[0].Fecha) { $L[0].Fecha } else { "LECTURA 1 (mas antigua)" }
  $f2 = if ($L[1].Fecha) { $L[1].Fecha } else { "LECTURA 2" }
  $f3 = if ($L[2].Fecha) { $L[2].Fecha } else { "LECTURA 3 (mas nueva)" }
  [void]$sb.Append("<Row><Cell ss:StyleID=`"hdr`" ss:MergeAcross=`"1`"><Data ss:Type=`"String`">MU IMMORTAL</Data></Cell>")
  [void]$sb.Append("<Cell ss:StyleID=`"d1`" ss:MergeAcross=`"2`"><Data ss:Type=`"String`">$f1</Data></Cell>")
  [void]$sb.Append("<Cell ss:StyleID=`"d2`" ss:MergeAcross=`"2`"><Data ss:Type=`"String`">$f2</Data></Cell>")
  [void]$sb.Append("<Cell ss:StyleID=`"d3`" ss:MergeAcross=`"2`"><Data ss:Type=`"String`">$f3</Data></Cell></Row>" + $nl)
  [void]$sb.Append('<Row>')
  [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">#</Data></Cell>')
  [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">ITEM</Data></Cell>')
  foreach ($st in @("d1","d2","d3")) {
    foreach ($h in @("BOLSA","BAUL","TOTAL")) {
      [void]$sb.Append("<Cell ss:StyleID=`"$st`"><Data ss:Type=`"String`">$h</Data></Cell>")
    }
  }
  [void]$sb.Append('</Row>' + $nl)
  $n = 1
  foreach ($it in $items) {
    [void]$sb.Append("<Row><Cell ss:StyleID=`"item`"><Data ss:Type=`"Number`">$n</Data></Cell>")
    [void]$sb.Append("<Cell ss:StyleID=`"item`"><Data ss:Type=`"String`">$it</Data></Cell>")
    foreach ($idx in 0..2) {
      $d = $null
      if ($L[$idx].Datos) { $d = $L[$idx].Datos[$it] }
      $b = 0; $v = 0
      if ($d) { $b = [int64]$d.Bolsa; $v = [int64]$d.Baul }
      $t = $b + $v
      [void]$sb.Append("<Cell ss:StyleID=`"num`"><Data ss:Type=`"Number`">$b</Data></Cell>")
      [void]$sb.Append("<Cell ss:StyleID=`"num`"><Data ss:Type=`"Number`">$v</Data></Cell>")
      [void]$sb.Append("<Cell ss:StyleID=`"tot`"><Data ss:Type=`"Number`">$t</Data></Cell>")
    }
    [void]$sb.Append("</Row>" + $nl)
    $n++
  }
  [void]$sb.Append('</Table>')
  [void]$sb.Append('<WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel"><FreezePanes/><FrozenNoSplit/><SplitHorizontal>2</SplitHorizontal><TopRowBottomPane>2</TopRowBottomPane><SplitVertical>2</SplitVertical><LeftColumnRightPane>2</LeftColumnRightPane><ActivePane>0</ActivePane></WorksheetOptions>')
  [void]$sb.Append('</Worksheet></Workbook>')
  $utf8 = New-Object System.Text.UTF8Encoding $true
  $xml = Join-Path $script:ConteoDir "inventario.xml"
  [IO.File]::WriteAllText($xml, $sb.ToString(), $utf8)
  # no escribir .xlsx falso: Excel no abre SpreadsheetML con extension xlsx
  return $xml
}

function Norm-InvKey([string]$k) {
  if (-not $k) { return "" }
  $u = $k.Trim().ToUpper()
  $u = $u -replace "_"," "
  if ($u -eq "CONDOR SPARK" -or $u -eq "CONDOR'S SPARK" -or $u -eq "CONDORS SPARK") { return "CONDOR" }
  if ($u -match "FLUORITE\s+FIRE\s+(\d+)") { return "Fluorite Fire $($Matches[1])" }
  if ($u -match "FLUORITE\s+ICE\s+(\d+)") { return "Fluorite Ice $($Matches[1])" }
  if ($u -match "FLUORITE\s+WIND\s+(\d+)") { return "Fluorite Wind $($Matches[1])" }
  if ($u -match "FLUORITE\s+WATER\s+(\d+)") { return "Fluorite Water $($Matches[1])" }
  $map = @{
    "ORO"="ORO"; "MUC"="MUC"; "BOUND MUC"="BOUND MUC"; "BOUNDMUC"="BOUND MUC"; "DIAMANTES"="DIAMANTES"
    "BLESS"="BLESS"; "SOUL"="SOUL"; "LIFE"="LIFE"; "CHAOS"="CHAOS"; "CREATION"="CREATION"
    "SD SEED"="SD SEED"; "SD"="SD SEED"; "COMBO HEART"="COMBO HEART"; "COMBO"="COMBO HEART"
    "CONDOR"="CONDOR"; "GARUDA"="GARUDA"; "WING ENHANCE STONE"="WING ENHANCE STONE"; "WING ENHANCE"="WING ENHANCE STONE"
    "HEAVENLY STEEL"="HEAVENLY STEEL"; "ANGEL SIGNET"="ANGEL SIGNET"; "ROSSY SIGNET"="ROSSY SIGNET"
    "ANILLOS"="ANILLOS"; "AROS"="AROS"; "COLLARES"="COLLARES"
  }
  if ($map.ContainsKey($u)) { return [string]$map[$u] }
  return $k
}

function New-InvDatos($bolsa, $baul) {
  $items = Get-InventarioCatalog
  $nb = @{}
  if ($bolsa) { foreach ($k in @($bolsa.Keys)) { $nk = Norm-InvKey $k; if ($nk) { $nb[$nk] = [int64]$bolsa[$k] } } }
  $nv = @{}
  if ($baul)  { foreach ($k in @($baul.Keys))  { $nk = Norm-InvKey $k; if ($nk) { $nv[$nk] = [int64]$baul[$k] } } }
  $m = [ordered]@{}
  foreach ($it in $items) {
    $b = 0; $v = 0
    if ($nb.ContainsKey($it)) { $b = [int64]$nb[$it] }
    if ($nv.ContainsKey($it)) { $v = [int64]$nv[$it] }
    $m[$it] = [ordered]@{ Bolsa = $b; Baul = $v; Total = ($b + $v) }
  }
  return $m
}

function Write-InventarioCsv($lecturas) {
  Ensure-Dirs
  $items = Get-InventarioCatalog
  $L = @($lecturas)
  $headers = @("#","ITEM")
  for ($n=1; $n -le 3; $n++) {
    $headers += "L${n}_FECHA","L${n}_BOLSA","L${n}_BAUL","L${n}_TOTAL"
  }
  $lines = New-Object System.Collections.Generic.List[string]
  $lines.Add(($headers -join ";"))
  $i = 1
  foreach ($it in $items) {
    $vals = @("$i", $it)
    for ($n=0; $n -lt 3; $n++) {
      if ($n -lt $L.Count -and $L[$n] -and $L[$n].Fecha) {
        $d = $L[$n].Datos.$it
        $b = 0; $v = 0
        if ($d) { $b = [int64]$d.Bolsa; $v = [int64]$d.Baul }
        $vals += @([string]$L[$n].Fecha, "$b", "$v", ($b+$v))
      } else {
        $vals += @("", "", "", "")
      }
    }
    $lines.Add(($vals -join ";"))
    $i++
  }
  $csv = Join-Path $script:ConteoDir "inventario.csv"
  $utf8 = New-Object System.Text.UTF8Encoding $true
  [IO.File]::WriteAllLines($csv, $lines, $utf8)
  return $csv
}



function Get-LanIPs {
  $ips = @()
  try {
    Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object {
      $_.IPAddress -notmatch '^127\.' -and $_.IPAddress -notmatch '^169\.254\.'
    } | ForEach-Object { $ips += $_.IPAddress }
  } catch {}
  if ($ips.Count -eq 0) {
    try {
      $ips = @([Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) | Where-Object { $_.AddressFamily -eq "InterNetwork" } | ForEach-Object { $_.IPAddressToString } | Where-Object { $_ -notmatch '^127\.' })
    } catch {}
  }
  return $ips
}

function Get-RemoteToken {
  $f = Join-Path $script:Root "remote.token"
  if (Test-Path $f) {
    $t = (Get-Content $f -Raw -Encoding UTF8).Trim()
    if ($t) { return $t }
  }
  $t = -join ((1..8) | ForEach-Object { "{0:x}" -f (Get-Random -Max 16) })
  try { Set-Content $f $t -Encoding ASCII -NoNewline } catch {}
  return $t
}

function Get-CuentasSeleccionadas {
  $sel = @()
  try {
    foreach ($row in @($grid.Rows)) {
      if ($row.IsNewRow) { continue }
      $on = $false
      try { $on = [bool]$row.Cells["contar"].Value } catch { $on = $false }
      if ($on) {
        $nm = [string]$row.Cells["nombre"].Value
        if ($nm) { $sel += $nm }
      }
    }
  } catch {}
  if ($sel.Count -eq 0) {
    try {
      foreach ($row in @($grid.SelectedRows)) {
        $nm = [string]$row.Cells["nombre"].Value
        if ($nm) { $sel += $nm }
      }
    } catch {}
  }
  if ($sel.Count -eq 0 -and $Cuentas) {
    $sel = @($Cuentas.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  }
  if ($sel.Count -eq 0) {
    try {
      $cfg = Get-Content $script:CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
      foreach ($key in @("contarByName","cuentasConteo")) {
        $obj = $null
        try { $obj = $cfg.$key } catch { $obj = $null }
        if (-not $obj) { continue }
        foreach ($p in $obj.PSObject.Properties) {
          if (Cfg-Bool $p.Value) { $sel += $p.Name }
        }
      }
    } catch {}
  }
  if ($sel.Count -eq 0 -and (Test-Path $script:ConteoSelPath)) {
    try {
      $sel = @(Get-Content $script:ConteoSelPath -Encoding UTF8 | Where-Object { $_.Trim() -ne "" -and $_ -notmatch "^#" } | ForEach-Object { $_.Trim() })
    } catch {}
  }
  return @($sel | Where-Object { $_ } | Select-Object -Unique)
}


function Cfg-Bool($v) {
  if ($v -eq $true) { return $true }
  $s = "$v"
  return ($s -eq "True" -or $s -eq "true" -or $s -eq "1")
}

function Name-MatchesCuenta([string]$a, [string]$b) {
  if (-not $a -or -not $b) { return $false }
  $x = $a.Trim().ToLower(); $y = $b.Trim().ToLower()
  if ($x -eq $y) { return $true }
  if ($x -like ("*{0}*" -f $y) -or $y -like ("*{0}*" -f $x)) { return $true }
  return $false
}

function Cfg-CuentaMarcada([string]$name) {
  if (-not $name) { return $false }
  try {
    $cfg = Load-Cfg
    foreach ($key in @("cuentasConteo","conteoByName")) {
      $obj = $null
      try { $obj = $cfg.$key } catch { $obj = $null }
      if (-not $obj) { continue }
      foreach ($p in $obj.PSObject.Properties) {
        if (Name-MatchesCuenta $name ([string]$p.Name)) {
          if (Cfg-Bool $p.Value) { return $true }
        }
      }
    }
  } catch {}
  return $false
}

function Refresh-CuentaBoxes {
  if (-not $grid) { return }
  try { $grid.EndEdit() } catch {}
  foreach ($row in @($grid.Rows)) {
    if ($row.IsNewRow) { continue }
    $nm = [string]$row.Cells["nombre"].Value
    try { $row.Cells["contar"].Value = [bool](Cfg-ContarByName $nm) } catch {}
  }
}

function Resolve-CuentaVentanas([string]$name) {
  $list = @(Get-List2)
  $exact = @($list | Where-Object { $_.name -eq $name })
  if ($exact.Count -gt 0) { return $exact }
  return @($list | Where-Object { $_.name -like ("*{0}*" -f $name) })
}

function Start-CuentaRemota([string]$name) {
  if (-not $name) { return "falta cuenta" }
  $hits = @(Resolve-CuentaVentanas $name)
  if ($hits.Count -eq 0) { return "no hay ventana $name" }
  $ldc = Join-Path $script:Ld "ldconsole.exe"
  $out = @()
  foreach ($it in $hits) {
    if (-not $it.alive) {
      Write-Log ("remote launch idx {0} {1}" -f $it.idx, $it.name)
      & $ldc launch --index $it.idx 2>$null | Out-Null
      $out += ("lanza {0}" -f $it.name)
    } else {
      Write-Log ("remote boot idx {0} {1}" -f $it.idx, $it.name)
      Start-BootJob2 $it.idx $it.hwnd
      $out += ("boot {0}" -f $it.name)
    }
  }
  return ($out -join "; ")
}

function Drain-RemoteQ {
  if (-not $script:RemoteQ) { return }
  $item = $null
  $useTry = $false
  try { $useTry = [bool]$script:RemoteQ.PSObject.Methods['TryDequeue'] } catch { $useTry = $false }
  while ($true) {
    $item = $null
    $ok = $false
    try {
      if ($useTry) { $ok = $script:RemoteQ.TryDequeue([ref]$item) }
      elseif ($script:RemoteQ.Count -gt 0) { $item = $script:RemoteQ.Dequeue(); $ok = $true }
    } catch { break }
    if (-not $ok) { break }
    try {
      $op = [string]$item.op
      if ($op -eq "boot") {
        $r = Start-CuentaRemota $item.cuenta
        Write-Log ("remote boot {0}: {1}" -f $item.cuenta, $r)
      } elseif ($op -eq "contar") {
        $me = $PSCommandPath
        if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
        $arg = @("-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ConteoOnly")
        if ($item.cuentas) { $arg += @("-Cuentas", [string]$item.cuentas) }
        Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList $arg | Out-Null
        Write-Log ("remote contar {0}" -f $item.cuentas)
      } elseif ($op -eq "start") {
        $script:Running = $true
        Write-Log "remote motor ON"
      } elseif ($op -eq "stop") {
        $script:Running = $false
        Write-Log "remote motor OFF"
      }
    } catch { Write-Log "remote cmd: $_" "ERR" }
  }
}

function Start-RemoteServer {
  if ($script:RemoteRun) { return }
  $script:RemoteRun = $true
  $port = [int]$script:RemotePort
  $tok = Get-RemoteToken
  try {
    $lsn = New-Object Net.Sockets.TcpListener ([Net.IPAddress]::Any, $port)
    $lsn.Start()
    $script:RemoteLsn = $lsn
    Write-Log ("remote ON puerto {0} token {1}" -f $port, $tok)
  } catch {
    Write-Log ("remote no arranco: {0}" -f $_.Exception.Message) "ERR"
    $script:RemoteRun = $false
    return
  }
  [Threading.ThreadPool]::QueueUserWorkItem({
    param($state)
    $lsn = $state[0]
    while ($script:RemoteRun) {
      try {
        if (-not $lsn.Pending()) { Start-Sleep -Milliseconds 250; continue }
        $cli = $lsn.AcceptTcpClient()
        $st = $cli.GetStream()
        $buf = New-Object byte[] 4096
        $n = $st.Read($buf, 0, $buf.Length)
        $req = [Text.Encoding]::ASCII.GetString($buf, 0, [Math]::Max(0,$n))
        $line = (($req -split "`n")[0]).Trim()
        $path = "/"
        if ($line -match 'GET\s+(\S+)') { $path = $Matches[1] }
        $u = $path
        $qs = @{}
        if ($u.Contains("?")) {
          $pair = $u.Split("?",2)
          $u = $pair[0]
          foreach ($p in $pair[1].Split("&")) {
            $kv = $p.Split("=",2)
            if ($kv.Count -eq 2) { $qs[$kv[0]] = [Uri]::UnescapeDataString($kv[1]) }
          }
        }
        $need = Get-RemoteToken
        $got = ""
        if ($qs.ContainsKey("t")) { $got = [string]$qs["t"] }
        $ok = ($got -eq $need -and $need)
        $code = "200 OK"
        $body = "ok"
        if (-not $ok -and $u -ne "/") { $code = "401 Unauthorized"; $body = "token" }
        elseif ($u -eq "/" -or $u -eq "/status") {
          $body = ("FarmBoss {0} running={1}" -f $script:Version, $script:Running)
        }
        elseif ($u -eq "/boot") {
          $c = ""
          if ($qs.ContainsKey("cuenta")) { $c = $qs["cuenta"] }
          elseif ($qs.ContainsKey("name")) { $c = $qs["name"] }
          $o = @{ op = "boot"; cuenta = $c }
          $script:RemoteQ.Enqueue($o)
          $body = "boot $c"
        }
        elseif ($u -eq "/contar") {
          $c = ""
          if ($qs.ContainsKey("cuentas")) { $c = $qs["cuentas"] }
          elseif ($qs.ContainsKey("cuenta")) { $c = $qs["cuenta"] }
          $o = @{ op = "contar"; cuentas = $c }
          $script:RemoteQ.Enqueue($o)
          $body = "contar $c"
        }
        elseif ($u -eq "/start") { $script:RemoteQ.Enqueue(@{ op = "start" }); $body = "start" }
        elseif ($u -eq "/stop")  { $script:RemoteQ.Enqueue(@{ op = "stop" });  $body = "stop" }
        else { $code = "404 Not Found"; $body = "no" }
        $resp = "HTTP/1.1 $code`r`nContent-Type: text/plain; charset=utf-8`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n$body"
        $bytes = [Text.Encoding]::UTF8.GetBytes($resp)
        $st.Write($bytes, 0, $bytes.Length)
        $cli.Close()
      } catch { Start-Sleep -Milliseconds 200 }
    }
  }.GetNewClosure(), @($script:RemoteLsn)) | Out-Null
}

function Stop-RemoteServer {
  $script:RemoteRun = $false
  try { if ($script:RemoteLsn) { $script:RemoteLsn.Stop() } } catch {}
}

function Get-ConteoTargets {
  $root = Get-FotosRoot
  $map = [ordered]@{}
  if ($root -and (Test-Path $root)) {
    foreach ($d in @(Get-ChildItem $root -Directory -ErrorAction SilentlyContinue)) {
      $ss = Join-Path $d.FullName "Pictures\Screenshots"
      if (-not (Test-Path $ss)) { $ss = Join-Path $d.FullName "Pictures" }
      if (-not (Test-Path $ss)) { continue }
      $n = @(Get-ChildItem $ss -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' }).Count
      if ($n -gt 0) { $map[$d.Name] = $ss }
    }
  }
  foreach ($it in @(Get-List2)) {
    $dir = Find-InstanceShotDir $root $it.name
    if ($dir -and (Test-Path $dir)) { $map[$it.name] = $dir }
  }
  return $map
}

function Read-FolderCurrencies([string]$dir, [datetime]$Since) {
  $res = @{ ORO = 0; MUC = 0; "BOUND MUC" = 0; DIAMANTES = 0 }
  if (-not $dir -or -not (Test-Path $dir)) { return $res }
  $all = @(Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' } | Sort-Object LastWriteTime -Descending)
  if ($Since -gt [datetime]::MinValue) { $all = @($all | Where-Object { $_.LastWriteTime -gt $Since }) }
  foreach ($img in @($all | Select-Object -First 12)) {
    $cur = Read-Currencies $img.FullName
    if ($cur.Oro)       { $res["ORO"] = [int64]$cur.Oro }
    if ($cur.MUC)       { $res["MUC"] = [int64]$cur.MUC }
    if ($cur.BoundMUC)  { $res["BOUND MUC"] = [int64]$cur.BoundMUC }
    if ($cur.Diamantes) { $res["DIAMANTES"] = [int64]$cur.Diamantes }
    if ($res["ORO"] -or $res["MUC"] -or $res["DIAMANTES"]) { break }
  }
  return $res
}


function Invoke-PythonInventario([string]$root) { return $null }

function Get-VmsRoot {
  $p = ""
  try { $p = $txtVms.Text.Trim() } catch { $p = "" }
  if (-not $p) { $p = "C:\LDPlayer\LDPlayer9\vms" }
  return $p
}

function Read-TextAny([string]$f) {
  $bytes = [IO.File]::ReadAllBytes($f)
  if ($bytes.Length -ge 2 -and $bytes[0] -eq 255 -and $bytes[1] -eq 254) {
    return [Text.Encoding]::Unicode.GetString($bytes)
  }
  if ($bytes.Length -ge 2 -and $bytes[0] -eq 254 -and $bytes[1] -eq 255) {
    return [Text.Encoding]::BigEndianUnicode.GetString($bytes)
  }
  return [Text.Encoding]::UTF8.GetString($bytes)
}

function Get-PicturePathsFromText([string]$raw) {
  $list = New-Object System.Collections.Generic.List[string]
  if (-not $raw) { return $list }
  foreach ($m in [regex]::Matches($raw, '<SharedFolder\b[^>]*>')) {
    $tag = $m.Value
    if ($tag -notmatch 'name="Pictures"') { continue }
    if ($tag -match 'hostPath="([^"]+)"') { $list.Add($Matches[1]) }
  }
  foreach ($m in [regex]::Matches($raw, '"(?:statusSettings\.sharedPictures|sharedPictures)"\s*:\s*"([^"]*)"')) {
    $v = $m.Groups[1].Value -replace '\\\\','\' -replace '\\/','/'
    if ($v) { $list.Add($v) }
  }
  return $list
}

function Resolve-ShotDir([string]$p) {
  if (-not $p) { return $null }
  $p = $p.Trim().Trim('"').TrimEnd('\','/')
  $cands = @(
    (Join-Path $p "Screenshots"),
    (Join-Path $p "Pictures\Screenshots"),
    $p,
    (Join-Path $p "Pictures")
  )
  foreach ($c in $cands) {
    if (-not (Test-Path -LiteralPath $c)) { continue }
    $n = @(Get-ChildItem -LiteralPath $c -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' }).Count
    if ($n -gt 0) { return $c }
  }
  foreach ($c in $cands) {
    if (Test-Path -LiteralPath $c) { return $c }
  }
  return $null
}

function Get-InstancePictureRaw([int]$idx) {
  $vms = Get-VmsRoot
  foreach ($f in @(
    (Join-Path $vms "leidian$idx\leidian.vbox"),
    (Join-Path $vms "config\leidian$idx.config")
  )) {
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $raw = ""
    try { $raw = Read-TextAny $f } catch { $raw = "" }
    foreach ($p in (Get-PicturePathsFromText $raw)) { return $p }
  }
  return ""
}

function Get-InstanceBoundShotDir([int]$idx) {
  $vms = Get-VmsRoot
  $raws = @()
  foreach ($f in @(
    (Join-Path $vms "leidian$idx\leidian.vbox"),
    (Join-Path $vms "config\leidian$idx.config")
  )) {
    if (Test-Path -LiteralPath $f) {
      try { $raws += (Read-TextAny $f) } catch {}
    }
  }
  foreach ($raw in $raws) {
    foreach ($p in (Get-PicturePathsFromText $raw)) {
      $d = Resolve-ShotDir $p
      if ($d) { return $d }
    }
  }
  return $null
}

function Get-InstanceFotoDirs([string]$root) {
  $out = @()
  $list = @()
  try { $list = @(Get-List2) } catch { $list = @() }
  $seen = @{}
  $boundOf = @{}
  $useCount = @{}
  $script:FotoRutas = @()
  foreach ($it in $list) {
    $b = $null
    try { $b = Get-InstanceBoundShotDir ([int]$it.idx) } catch { $b = $null }
    if ($b) {
      $boundOf["$($it.idx)"] = $b
      $k = $b.ToLower()
      if (-not $useCount.ContainsKey($k)) { $useCount[$k] = 0 }
      $useCount[$k] = [int]$useCount[$k] + 1
    }
  }
  foreach ($it in $list) {
    $d = $null
    $key = "$($it.idx)"
    if ($boundOf.ContainsKey($key)) {
      $b = $boundOf[$key]
      if ([int]$useCount[$b.ToLower()] -eq 1) {
        $d = $b
        Write-Log ("fotos {0} <- {1}" -f $it.name, $d)
        $script:FotoRutas += ("{0} -> {1}" -f $it.name, $d)
      } else {
        Write-Log ("{0} comparte la carpeta de fotos, no se usa esa ruta" -f $it.name) "WARN"
        $script:FotoRutas += ("{0} comparte {1}" -f $it.name, $b)
      }
    } else {
      $raw = ""
      try { $raw = Get-InstancePictureRaw ([int]$it.idx) } catch { $raw = "" }
      if ($raw) { $script:FotoRutas += ("{0} ruta no existe: {1}" -f $it.name, $raw) }
      else { $script:FotoRutas += ("{0} sin ruta en leidian{1}" -f $it.name, $it.idx) }
    }
    if (-not $d -and $root) { $d = Find-InstanceShotDir $root $it.name }
    if ($d) {
      $out += [pscustomobject]@{ name = $it.name; dir = $d }
      $seen[$it.name.ToLower()] = $true
    }
  }
  if ($root -and (Test-Path $root)) {
    Get-ChildItem $root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
      $nm = $_.Name
      if ($seen.ContainsKey($nm.ToLower())) { return }
      if ($nm -match '^(Pictures|Screenshots|backup|cache)$') { return }
      $ss = Join-Path $_.FullName "Pictures\Screenshots"
      if (-not (Test-Path $ss)) { $ss = Join-Path $_.FullName "Pictures" }
      if (-not (Test-Path $ss)) { $ss = $_.FullName }
      $n = @(Get-ChildItem $ss -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' }).Count
      if ($n -gt 0) { $out += [pscustomobject]@{ name = $nm; dir = $ss } }
    }
  }
  return $out
}

function Read-FolderCurrencies([string]$dir, [datetime]$Since) {
  $res = [ordered]@{ Oro = ""; Diamantes = ""; MUC = ""; BoundMUC = "" }
  if (-not (Test-Path $dir)) { return $res }
  $all = @(Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' } | Sort-Object LastWriteTime -Descending)
  if ($Since -gt [datetime]::MinValue) { $all = @($all | Where-Object { $_.LastWriteTime -gt $Since }) }
  foreach ($img in ($all | Select-Object -First 12)) {
    try {
      $cur = Read-Currencies $img.FullName
      if ($cur.Oro -or $cur.MUC -or $cur.Diamantes -or $cur.BoundMUC) { return $cur }
    } catch {}
  }
  return $res
}



function Test-PythonOk([string]$exe) {
  if (-not $exe -or -not (Test-Path $exe)) { return $false }
  if ($exe -match "WindowsApps") { return $false }
  try {
    $probe = & $exe -c "import PIL,numpy; print('OK')" 2>&1 | Out-String
    if ($probe -match "OK") { return $true }
    if ($script:ConteoMeta -is [System.Collections.IDictionary]) {
      $snip = $probe.Trim()
      if ($snip.Length -gt 180) { $snip = $snip.Substring(0,180) }
      $script:ConteoMeta.error = ("python malo {0}: {1}" -f $exe, $snip)
    }
  } catch {
    if ($script:ConteoMeta -is [System.Collections.IDictionary]) {
      $script:ConteoMeta.error = ("python malo {0}: {1}" -f $exe, $_)
    }
  }
  return $false
}

function Get-PythonExe {
  $cands = @(
    "$env:LocalAppData\Python\bin\python.exe",
    (Join-Path $script:Root "python\python.exe"),
    "$env:LocalAppData\Programs\Python\Python314\python.exe",
    "$env:LocalAppData\Programs\Python\Python313\python.exe",
    "$env:LocalAppData\Programs\Python\Python312\python.exe",
    "$env:LocalAppData\Programs\Python\Python311\python.exe",
    "C:\Python314\python.exe",
    "C:\Python312\python.exe",
    "C:\Python311\python.exe",
    "$env:LocalAppData\Python\pythoncore-3.14-64\python.exe"
  )
  foreach ($c in $cands) {
    if (Test-PythonOk $c) { return $c }
  }
  foreach ($n in @("py","python")) {
    $cmd = Get-Command $n -ErrorAction SilentlyContinue
    if (-not $cmd) { continue }
    $src = [string]$cmd.Source
    if (Test-PythonOk $src) { return $src }
  }
  return $null
}


function Ensure-ConteoProgress {
  if ($script:ProgForm -and -not $script:ProgForm.IsDisposed) {
    try { $script:ProgForm.Show(); $script:ProgForm.BringToFront() } catch {}
    return
  }
  $f = New-Object System.Windows.Forms.Form
  $f.Text = "FarmBoss - Conteo"
  $f.Size = New-Object System.Drawing.Size(280, 200)
  $f.MinimumSize = New-Object System.Drawing.Size(260, 180)
  $f.StartPosition = "CenterScreen"
  $f.MinimizeBox = $true
  $f.MaximizeBox = $false
  $lbl = New-Object System.Windows.Forms.Label
  $lbl.Location = New-Object System.Drawing.Point(8, 6)
  $lbl.Size = New-Object System.Drawing.Size(248, 18)
  $lbl.Text = "iniciando..."
  $bar = New-Object System.Windows.Forms.ProgressBar
  $bar.Location = New-Object System.Drawing.Point(8, 26)
  $bar.Size = New-Object System.Drawing.Size(248, 14)
  $bar.Minimum = 0
  $bar.Maximum = 100
  $box = New-Object System.Windows.Forms.TextBox
  $box.Location = New-Object System.Drawing.Point(8, 44)
  $box.Size = New-Object System.Drawing.Size(248, 110)
  $box.Multiline = $true
  $box.ScrollBars = "Vertical"
  $box.ReadOnly = $true
  $box.Font = New-Object System.Drawing.Font("Consolas", 8)
  $f.Controls.AddRange(@($lbl, $bar, $box))
  $script:ProgForm = $f
  $script:ProgBar = $bar
  $script:ProgLbl = $lbl
  $script:ProgLog = $box
  $f.Add_FormClosing({
    param($s, $e)
    if ($script:ConteoBusy) { $e.Cancel = $true }
  })
  $f.Show()
}

function Update-ConteoProgress([int]$pct, [string]$msg) {
  try { Ensure-ConteoProgress } catch {}
  try {
    if ($script:ProgBar -and $pct -ge 0) { $script:ProgBar.Value = [Math]::Min(100, [Math]::Max(0, $pct)) }
    if ($msg) {
      if ($script:ProgLbl) { $script:ProgLbl.Text = $msg }
      if ($script:ProgLog) {
        $script:ProgLog.AppendText(("{0} {1}{2}" -f (Get-Date -Format "HH:mm:ss"), $msg, [Environment]::NewLine))
      }
      Write-Log $msg
    }
  } catch {}
  try { [System.Windows.Forms.Application]::DoEvents() } catch {}
}

function Try-ConteoPyFolder([string]$dir, [string]$region = "auto") {
  $bolsa = @{}
  $baul = @{}
  $pyexe = Get-PythonExe
  if ($script:ConteoMeta -is [System.Collections.IDictionary]) {
    if ($pyexe) { $script:ConteoMeta.python = [string]$pyexe }
    else { $script:ConteoMeta.python = "no encontrado" }
  }
  if (-not $pyexe) {
    Write-Log "python no esta en PATH. Instala 3.12 y pip install pillow numpy" "WARN"
    return @{ ok = $false; bolsa = $bolsa; baul = $baul; err = "python no encontrado" }
  }
  $cands = @(
    (Join-Path $script:Root "conteo.py"),
    (Join-Path $script:ConteoDir "conteo.py")
  ) | Where-Object { Test-Path $_ }
  $scriptPy = $cands | Sort-Object { (Get-Item $_).LastWriteTime } -Descending | Select-Object -First 1
  if (-not (Test-Path $scriptPy)) {
    Write-Log "falta conteo.py en C:\\keepalive\\conteo" "WARN"
    return @{ ok = $false; bolsa = $bolsa; baul = $baul; err = "falta conteo.py" }
  }
  try {
    Write-Log ("python {0}" -f $pyexe)
    Write-Log ("script {0}" -f $scriptPy)
    Write-Log ("python {0}" -f $pyexe)
    Write-Log ("script {0}" -f $scriptPy)
    try { Write-Host ("  py {0}" -f $scriptPy) } catch {}
    $out = & $pyexe $scriptPy --folder $dir --region $region --max-fotos 8 --json 2>&1 | Out-String -Width 200000
    $jtxt = $null
    $side = Join-Path (Split-Path -Parent $scriptPy) "last_py.json"
    if (Test-Path $side) {
      try { $jtxt = [IO.File]::ReadAllText($side) } catch { $jtxt = $null }
    }
    if (-not $jtxt) {
      $m = [regex]::Match($out, 'JSON_START\s*(\{[\s\S]*\})\s*JSON_END')
      if ($m.Success) { $jtxt = $m.Groups[1].Value }
    }
    if (-not $jtxt) {
      $i1 = $out.LastIndexOf('{')
      $i0 = $out.IndexOf('{"')
      if ($i0 -lt 0) { $i0 = $out.IndexOf('{') }
      if ($i0 -ge 0 -and $out.LastIndexOf('}') -gt $i0) {
        $jtxt = $out.Substring($i0, $out.LastIndexOf('}') - $i0 + 1)
      }
    }
    if (-not $jtxt) {
      $snip = $out
      if ($snip.Length -gt 240) { $snip = $snip.Substring(0, 240) }
      if ($script:ConteoMeta -is [System.Collections.IDictionary]) { $script:ConteoMeta.snip = $snip }
      Write-Log ("conteo.py sin JSON: {0}" -f $snip) "WARN"
      try { Write-Host "  sin JSON" -ForegroundColor Red } catch {}
      if ($script:ConteoMeta -is [System.Collections.IDictionary]) { $script:ConteoMeta.error = $snip }
    }
    if ($jtxt) {
      $j = $jtxt | ConvertFrom-Json
      if ($j.mochila) {
        foreach ($p in $j.mochila.PSObject.Properties) { $bolsa[[string]$p.Name] = [int64]$p.Value }
      }
      if ($j.bodega) {
        foreach ($p in $j.bodega.PSObject.Properties) { $baul[[string]$p.Name] = [int64]$p.Value }
      }
      $cur = $null
      if ($j.currencies) { $cur = $j.currencies }
      elseif ($j.monedas) { $cur = $j.monedas }
      if ($cur) {
        foreach ($p in $cur.PSObject.Properties) {
          $nk = ([string]$p.Name).ToUpper()
          if ($nk -eq "GOLD" -or $nk -eq "ORO") { $nk = "ORO" }
          if ($nk -eq "BOUNDMUC" -or $nk -eq "BOUND_MUC") { $nk = "BOUND MUC" }
          if ($nk -eq "DIAMOND" -or $nk -eq "GEMS") { $nk = "DIAMANTES" }
          $bolsa[$nk] = [int64]$p.Value
        }
      }
      foreach ($pair in @(
        @{ a = "oro"; b = "ORO" },
        @{ a = "muc"; b = "MUC" },
        @{ a = "boundmuc"; b = "BOUND MUC" },
        @{ a = "diamantes"; b = "DIAMANTES" }
      )) {
        try {
          $v = $j.($pair.a)
          if ($null -ne $v) { $bolsa[$pair.b] = [int64]$v }
        } catch {}
      }
      Write-Log ("conteo.py ok {0}" -f $dir)
      return @{ ok = $true; bolsa = $bolsa; baul = $baul }
    }
  } catch {
    Write-Log "conteo.py fallo: $_" "WARN"
  }
  Write-Log ("conteo.py sin JSON  py={0} script={1}" -f $pyexe, $scriptPy) "WARN"
  return @{ ok = $false; bolsa = $bolsa; baul = $baul; err = "conteo.py sin JSON" }
}


function Get-IconMap {
  return [ordered]@{
    "bless" = "BLESS"; "soul" = "SOUL"; "life" = "LIFE"; "chaos" = "CHAOS"; "creation" = "CREATION"
    "sd_seed" = "SD SEED"; "sd" = "SD SEED"; "combo_heart" = "COMBO HEART"
    "condor" = "CONDOR"; "garuda" = "GARUDA"; "wing_enhance" = "WING ENHANCE STONE"
    "heavenly_steel" = "HEAVENLY STEEL"; "angel_signet" = "ANGEL SIGNET"; "rossy_signet" = "ROSSY SIGNET"
    "anillos" = "ANILLOS"; "aros" = "AROS"; "collares" = "COLLARES"
    "fluorite_fire" = "Fluorite Fire 1"; "fluorite_ice" = "Fluorite Ice 1"
    "fluorite_wind" = "Fluorite Wind 1"; "fluorite_water" = "Fluorite Water 1"
  }
}

function Load-TemplateBmps([string]$dir, $map) {
  $list = @()
  if (-not (Test-Path $dir)) { return $list }
  Add-Type -AssemblyName System.Drawing
  Get-ChildItem $dir -Filter *.png -ErrorAction SilentlyContinue | ForEach-Object {
    $raw = $_.BaseName.ToLower()
    $key = $null
    foreach ($st in @($map.Keys)) {
      if ($raw -eq $st -or $raw.StartsWith($st + "_")) { $key = $st; break }
    }
    if (-not $key) { return }
    try {
      $src = [Drawing.Bitmap]::FromFile($_.FullName)
      $tiny = New-Object Drawing.Bitmap 16,16
      $g = [Drawing.Graphics]::FromImage($tiny)
      $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
      $g.DrawImage($src, 0, 0, 16, 16)
      $g.Dispose(); $src.Dispose()
      $list += [pscustomobject]@{ name = [string]$map[$key]; bmp = $tiny }
    } catch {}
  }
  return $list
}

function Get-Gray16([Drawing.Bitmap]$bmp, [int]$sx, [int]$sy, [int]$sw, [int]$sh) {
  $out = New-Object 'int[]' 256
  $i = 0
  for ($y = 0; $y -lt 16; $y++) {
    $yy = [int]($sy + ($y + 0.5) * $sh / 16.0)
    if ($yy -lt 0) { $yy = 0 }; if ($yy -ge $bmp.Height) { $yy = $bmp.Height - 1 }
    for ($x = 0; $x -lt 16; $x++) {
      $xx = [int]($sx + ($x + 0.5) * $sw / 16.0)
      if ($xx -lt 0) { $xx = 0 }; if ($xx -ge $bmp.Width) { $xx = $bmp.Width - 1 }
      $c = $bmp.GetPixel($xx, $yy)
      $out[$i] = [int](0.3 * $c.R + 0.59 * $c.G + 0.11 * $c.B)
      $i++
    }
  }
  return $out
}

function Get-TplGray16([Drawing.Bitmap]$tiny) {
  $out = New-Object 'int[]' 256
  $i = 0
  for ($y = 0; $y -lt 16; $y++) {
    for ($x = 0; $x -lt 16; $x++) {
      $c = $tiny.GetPixel($x, $y)
      $out[$i] = [int](0.3 * $c.R + 0.59 * $c.G + 0.11 * $c.B)
      $i++
    }
  }
  return $out
}

function Diff-Gray([int[]]$a, [int[]]$b) {
  $s = 0
  for ($i = 0; $i -lt 256; $i++) { $s += [Math]::Abs($a[$i] - $b[$i]) }
  return $s / 256.0
}

function Read-CellQty([Drawing.Bitmap]$bmp, [int]$x, [int]$y, [int]$cw) {
  $x0 = [Math]::Max(0, $x + [int]($cw * 0.42))
  $y0 = [Math]::Max(0, $y)
  $x1 = [Math]::Min($bmp.Width - 1, $x + $cw - 1)
  $y1 = [Math]::Min($bmp.Height - 1, $y + [int]($cw * 0.42))
  if ($x1 -le $x0 -or $y1 -le $y0) { return 1 }
  $w = $x1 - $x0 + 1
  $col = New-Object 'int[]' $w
  $yellow = 0
  for ($xx = $x0; $xx -le $x1; $xx++) {
    $n = 0
    for ($yy = $y0; $yy -le $y1; $yy++) {
      $c = $bmp.GetPixel($xx, $yy)
      if ($c.R -gt 170 -and $c.G -gt 130 -and $c.B -lt 130 -and $c.R -gt $c.B + 40) { $n++; $yellow++ }
    }
    $col[$xx - $x0] = $n
  }
  if ($yellow -lt 6) { return 1 }
  $runs = @()
  $in = $false; $a = 0
  for ($i = 0; $i -lt $w; $i++) {
    if ($col[$i] -ge 2) {
      if (-not $in) { $in = $true; $a = $i }
    } else {
      if ($in) { $runs += ,@{ a = $a; b = ($i - 1) }; $in = $false }
    }
  }
  if ($in) { $runs += ,@{ a = $a; b = ($w - 1) } }
  $runs = @($runs | Where-Object { ($_.b - $_.a) -ge 1 })
  if ($runs.Count -eq 0) { return 1 }
  return @{ yellow = $yellow; runs = $runs.Count }
}

function Qty-ForItem([string]$item, $probe) {
  if (-not $probe) { return 1 }
  $jewel = $item -match 'BLESS|SOUL|LIFE|CHAOS|CREATION|COMBO|FLUORITE|SD SEED'
  if ($jewel -and $probe.runs -ge 2 -and $probe.runs -le 4) { return [Math]::Min(999, [int]("9" * $probe.runs)) }
  return 1
}

function Read-DualPanelIcons([string]$path, $tpls) {
  $bag = @{}
  $vault = @{}
  if (-not (Test-Path $path) -or $tpls.Count -lt 1) { return @{ bolsa = $bag; baul = $vault } }
  Add-Type -AssemblyName System.Drawing
  $bmp = $null
  try {
    $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
    $src = New-Object Drawing.Bitmap $fs
    $bmp = New-Object Drawing.Bitmap $src
    $src.Dispose(); $fs.Close()
    $w = $bmp.Width; $h = $bmp.Height
    if ($w -lt 900 -or $h -lt 400) { return @{ bolsa = $bag; baul = $vault } }
    $tplGray = @()
    foreach ($t in $tpls) { $tplGray += [pscustomobject]@{ name = $t.name; g = Get-TplGray16 $t.bmp } }
    $panels = @(
      @{ dest = "baul";  x0 = [int]($w*0.34); y0 = [int]($h*0.14); x1 = [int]($w*0.70); y1 = [int]($h*0.88) }
      @{ dest = "bolsa"; x0 = [int]($w*0.70); y0 = [int]($h*0.12); x1 = [int]($w*0.985); y1 = [int]($h*0.88) }
    )
    foreach ($p in $panels) {
      $pw = $p.x1 - $p.x0
      $ph = $p.y1 - $p.y0
      $cols = 8
      $cw = [int]($pw / $cols)
      if ($cw -lt 20) { continue }
      $rows = [Math]::Max(4, [int]($ph / $cw))
      $acc = @{}
      for ($r = 0; $r -lt $rows; $r++) {
        for ($c = 0; $c -lt $cols; $c++) {
          $sx = $p.x0 + $c * $cw + 4
          $sy = $p.y0 + $r * $cw + 4
          $sw = $cw - 8; $sh = $cw - 8
          if ($sx -lt 0 -or $sy -lt 0 -or ($sx+$sw) -ge $w -or ($sy+$sh) -ge $h) { continue }
          # skip empty dark cells
          $gcell = Get-Gray16 $bmp $sx $sy $sw $sh
          $mean = 0; foreach ($v in $gcell) { $mean += $v }; $mean = $mean / 256.0
          if ($mean -lt 18) { continue }
          $best = $null; $bestD = 999; $second = 999
          foreach ($t in $tplGray) {
            $d = Diff-Gray $gcell $t.g
            if ($d -lt $bestD) { $second = $bestD; $bestD = $d; $best = $t.name }
            elseif ($d -lt $second) { $second = $d }
          }
          $lim = 42
          if ($best -match 'ANILLOS|AROS|COLLARES|WING|CONDOR|GARUDA|SIGNET|STEEL') { $lim = 38 }
          if ($best -match 'FLUORITE|BLESS|SOUL|CHAOS|LIFE|CREATION|COMBO|SEED') { $lim = 44 }
          if ($bestD -gt $lim) { continue }
          if ($best -match 'ANILLOS|AROS|COLLARES|WING|CONDOR|GARUDA' -and ($second - $bestD) -lt 6) { continue }
          $probe = Read-CellQty $bmp $sx $sy $cw
          $q = Qty-ForItem $best $probe
          if (-not $acc.ContainsKey($best)) { $acc[$best] = 0 }
          $acc[$best] = [int64]$acc[$best] + [int64]$q
        }
      }
      if ($p.dest -eq "baul") { $vault = $acc } else { $bag = $acc }
    }
  } catch {
    Write-Log ("grid {0}: {1}" -f [IO.Path]::GetFileName($path), $_) "WARN"
  } finally {
    if ($bmp) { $bmp.Dispose() }
  }
  return @{ bolsa = $bag; baul = $vault }
}

function Read-FolderIcons([string]$dir, [datetime]$Since) {
  $bolsa = @{}
  $baul = @{}
  $iconDir = Join-Path $script:ConteoDir "iconos"
  $map = Get-IconMap
  $tpls = Load-TemplateBmps $iconDir $map
  if ($tpls.Count -lt 1) {
    Write-Log "no hay plantillas en $iconDir" "WARN"
    return @{ bolsa = $bolsa; baul = $baul }
  }
  $all = @(Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' })
  if ($Since -gt [datetime]::MinValue) { $all = @($all | Where-Object { $_.LastWriteTime -gt $Since }) }
  $all = @($all | Sort-Object { $s = Parse-ShotStamp $_.Name; if ($s) { $s } else { $_.LastWriteTime } } | Select-Object -Last 8)
  Write-Log ("iconos {0} plantillas, fotos {1} en {2}" -f $tpls.Count, $all.Count, $dir)
  $seenBag = @{}
  $seenVault = @{}
  foreach ($img in $all) {
    $got = Read-DualPanelIcons $img.FullName $tpls
    $sigB = ($got.bolsa.GetEnumerator() | Sort-Object Name | ForEach-Object { "{0}:{1}" -f $_.Key,$_.Value }) -join "|"
    $sigV = ($got.baul.GetEnumerator() | Sort-Object Name | ForEach-Object { "{0}:{1}" -f $_.Key,$_.Value }) -join "|"
    if ($sigB -and -not $seenBag.ContainsKey($sigB)) {
      $seenBag[$sigB] = $true
      foreach ($k in $got.bolsa.Keys) {
        if (-not $bolsa.ContainsKey($k)) { $bolsa[$k] = 0 }
        $bolsa[$k] = [int64]$bolsa[$k] + [int64]$got.bolsa[$k]
      }
    } else { Write-Log ("bolsa repetida {0}" -f $img.Name) }
    if ($sigV -and -not $seenVault.ContainsKey($sigV)) {
      $seenVault[$sigV] = $true
      foreach ($k in $got.baul.Keys) {
        if (-not $baul.ContainsKey($k)) { $baul[$k] = 0 }
        $baul[$k] = [int64]$baul[$k] + [int64]$got.baul[$k]
      }
    } else { Write-Log ("baul repetido {0}" -f $img.Name) }
  }
  foreach ($t in $tpls) { try { $t.bmp.Dispose() } catch {} }
  return @{ bolsa = $bolsa; baul = $baul }
}

function Read-FolderOcrItems([string]$dir, [datetime]$Since) {
  $bolsa = @{}
  $baul  = @{}
  if (-not $dir -or -not (Test-Path $dir)) { return @{ bolsa = $bolsa; baul = $baul } }
  $items = @(Get-InventarioCatalog)
  $all = @(Get-ChildItem $dir -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' })
  if ($Since -gt [datetime]::MinValue) {
    $all = @($all | Where-Object { (Get-FileShotTime $_) -gt $Since })
  }
  $all = @($all | Sort-Object { Get-FileShotTime $_ })
  $seenBaul = @()
  $seenBolsa = @()
  foreach ($img in $all) {
    $hBaul = Get-CropHash $img.FullName "baul"
    $hBolsa = Get-CropHash $img.FullName "bolsa"
    $doBaul = -not (Test-SeenHash $seenBaul $hBaul)
    $doBolsa = -not (Test-SeenHash $seenBolsa $hBolsa)
    if ($hBaul -and $doBaul) { $seenBaul += $hBaul }
    if ($hBolsa -and $doBolsa) { $seenBolsa += $hBolsa }
    if (-not $doBaul -and -not $doBolsa) {
      Write-Log ("pagina repetida {0} - no sumo" -f $img.Name)
      continue
    }
    Write-Log ("foto {0} baul={1} bolsa={2}" -f $img.Name, $(if ($doBaul) { "nueva" } else { "igual" }), $(if ($doBolsa) { "nueva" } else { "igual" }))
    $txt = Get-WinOcr $img.FullName
    if (-not $txt) { continue }
    $norm = ($txt.ToUpper() -replace '[^A-Z0-9 ]',' ')
    foreach ($it in $items) {
      if ($it -in @("ORO","MUC","BOUND MUC","DIAMANTES")) { continue }
      $needle = $it.ToUpper()
      $idx = $norm.IndexOf($needle)
      if ($idx -lt 0) { continue }
      $tail = $norm.Substring($idx + $needle.Length)
      if ($tail -match '(\d{1,7})') {
        $q = [int64]$Matches[1]
        if ($doBaul)  { $baul[$it]  = [int64]$q }
        if ($doBolsa) { $bolsa[$it] = [int64]$q }
      }
    }
  }
  return @{ bolsa = $bolsa; baul = $baul }
}

function Write-InventarioInstancias($instancias, [string]$fecha) {
  Ensure-Dirs
  $items = Get-InventarioCatalog
  $nl = "`r`n"
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append('<?xml version="1.0" encoding="UTF-8"?>' + $nl)
  [void]$sb.Append('<?mso-application progid="Excel.Sheet"?>' + $nl)
  [void]$sb.Append('<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' + $nl)
  [void]$sb.Append('<Styles>')
  [void]$sb.Append('<Style ss:ID="hdr"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1F4E79" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('<Style ss:ID="num"><Alignment ss:Horizontal="Center"/></Style>')
  [void]$sb.Append('</Styles>')
  [void]$sb.Append('<Worksheet ss:Name="Instancias"><Table>')
  [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">Instancia</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">Fecha</Data></Cell></Row>')
  foreach ($name in @($instancias.Keys)) {
    $esc = ($name -replace '&','&amp;')
    [void]$sb.Append("<Row><Cell><Data ss:Type=`"String`">$esc</Data></Cell><Cell><Data ss:Type=`"String`">$fecha</Data></Cell></Row>")
  }
  [void]$sb.Append('</Table></Worksheet>')
  foreach ($name in @($instancias.Keys)) {
    $sheet = ($name -replace '[\\/:*?\[\]]','_')
    if ($sheet.Length -gt 31) { $sheet = $sheet.Substring(0,31) }
    $sheet = ($sheet -replace '&','&amp;')
    [void]$sb.Append("<Worksheet ss:Name=`"$sheet`"><Table>")
    [void]$sb.Append('<Column ss:Width="40"/><Column ss:Width="160"/><Column ss:Width="90"/><Column ss:Width="90"/><Column ss:Width="90"/>')
    [void]$sb.Append('<Row><Cell ss:StyleID="hdr"><Data ss:Type="String">#</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">ITEM</Data></Cell>')
    [void]$sb.Append('<Cell ss:StyleID="hdr"><Data ss:Type="String">BOLSA</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">BAUL</Data></Cell><Cell ss:StyleID="hdr"><Data ss:Type="String">TOTAL</Data></Cell></Row>')
    $L = $instancias[$name].lecturas[0]
    $n = 1
    foreach ($it in $items) {
      $b=0;$v=0
      try { if ($L.bolsa.ContainsKey($it)) { $b=[int64]$L.bolsa[$it] } } catch {}
      try { if ($L.baul.ContainsKey($it))  { $v=[int64]$L.baul[$it] } } catch {}
      if ($b -eq 0 -and $v -eq 0) { continue }
      $escIt = ($it -replace '&','&amp;')
      [void]$sb.Append("<Row><Cell ss:StyleID=`"num`"><Data ss:Type=`"Number`">$n</Data></Cell><Cell><Data ss:Type=`"String`">$escIt</Data></Cell>")
      if ($b -ne 0) { [void]$sb.Append("<Cell ss:Index=`"3`" ss:StyleID=`"num`"><Data ss:Type=`"Number`">$b</Data></Cell>") }
      if ($v -ne 0) { [void]$sb.Append("<Cell ss:Index=`"4`" ss:StyleID=`"num`"><Data ss:Type=`"Number`">$v</Data></Cell>") }
      if (($b + $v) -ne 0) { [void]$sb.Append("<Cell ss:Index=`"5`" ss:StyleID=`"num`"><Data ss:Type=`"Number`">$($b+$v)</Data></Cell>") }
      [void]$sb.Append("</Row>")
      $n++
    }
    [void]$sb.Append('</Table></Worksheet>')
  }
  [void]$sb.Append('</Workbook>')
  $xls = Join-Path $script:ConteoDir "inventario.xls"
  $xlsxFake = Join-Path $script:ConteoDir "inventario.xlsx"
  $utf8 = New-Object System.Text.UTF8Encoding $true
  [IO.File]::WriteAllText($xls, $sb.ToString(), $utf8)
  # no escribir .xlsx falso: Excel lo rechaza
  Write-Log ("excel instancias -> {0}" -f $xls)
  return $xls
}


function Get-GitHubToken {
  $f = Join-Path $script:Root "github.token"
  if (-not (Test-Path $f)) { return $null }
  $t = (Get-Content $f -Raw -Encoding UTF8).Trim()
  if (-not $t) { return $null }
  return $t
}

function Get-GitHubHeaders([string]$tok) {
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
  return @{
    Authorization = "Bearer $tok"
    Accept        = "application/vnd.github+json"
    "User-Agent"  = "FarmBoss"
  }
}

function Publish-GitHubFile([string]$local, [string]$repoPath, [string]$msg) {
  if (-not $local -or -not (Test-Path $local)) { return $false }
  $tok = Get-GitHubToken
  if (-not $tok) {
    Write-Log "github: falta C:\\keepalive\\github.token" "WARN"
    return $false
  }
  $len = (Get-Item $local).Length
  if ($len -gt 20MB) {
    Write-Log ("github skip grande {0} ({1} bytes)" -f $repoPath, $len) "WARN"
    return $false
  }
  $owner = "jorgemazu"
  $repo  = "farmboss-inventario"
  $encPath = ($repoPath -replace ' ', '%20')
  $api = "https://api.github.com/repos/$owner/$repo/contents/$encPath"
  $hdr = Get-GitHubHeaders $tok
  $sha = $null
  try {
    $cur = Invoke-RestMethod -Uri $api -Headers $hdr -Method Get
    if ($cur.sha) { $sha = [string]$cur.sha }
  } catch {}
  $bytes = [IO.File]::ReadAllBytes($local)
  $b64 = [Convert]::ToBase64String($bytes)
  $bodyObj = @{ message = $msg; content = $b64 }
  if ($sha) { $bodyObj.sha = $sha }
  $json = $bodyObj | ConvertTo-Json -Compress
  try {
    $r = Invoke-RestMethod -Uri $api -Headers $hdr -Method Put -Body $json -ContentType "application/json"
    Write-Log ("github OK {0}" -f $repoPath)
    return $true
  } catch {
    Write-Log ("github fallo {0}: {1}" -f $repoPath, $_.Exception.Message) "ERR"
    return $false
  }
}

function Get-FotosParaGit([string]$dir, [int]$maxN = 6) {
  $out = @()
  if (-not $dir -or -not (Test-Path $dir)) { return $out }
  $lim = (Get-Date).AddHours(-8)
  $all = @(Get-ChildItem $dir -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Extension -match '\.(png|jpg|jpeg|bmp|webp)$' } |
    Sort-Object LastWriteTime -Descending)
  $rec = @($all | Where-Object { $_.LastWriteTime -ge $lim })
  if ($rec.Count -eq 0) { $rec = $all }
  return @($rec | Select-Object -First $maxN)
}

function Publish-FotosGitHub($dirs) {
  $tok = Get-GitHubToken
  if (-not $tok) {
    Write-Log "fotos git: falta C:\\keepalive\\github.token" "WARN"
    return
  }
  $nOk = 0
  $nSkip = 0
  foreach ($d in @($dirs)) {
    $name = [string]$d.name
    $folder = Safe-FolderName $name
    if (-not $folder) { $folder = "cuenta" }
    $files = @(Get-FotosParaGit $d.dir 6)
    if ($files.Count -eq 0) {
      Write-Log ("fotos git {0}: sin imagenes" -f $name) "WARN"
      continue
    }
    foreach ($f in $files) {
      $repoPath = "fotos/{0}/{1}" -f $folder, $f.Name
      $msg = ("foto {0} {1}" -f $name, (Get-Date -Format "yyyy-MM-dd HH:mm"))
      if (Publish-GitHubFile $f.FullName $repoPath $msg) { $nOk++ } else { $nSkip++ }
    }
  }
  Write-Log ("fotos git listo ok={0} fallo={1}" -f $nOk, $nSkip)
}

function Publish-InventarioGitHub([string]$xls) {
  if (-not $xls -or -not (Test-Path $xls)) { return }
  $tok = Get-GitHubToken
  if (-not $tok) {
    Write-Log "github: falta C:\keepalive\github.token (PAT con repo)" "WARN"
    return
  }
  $owner = "jorgemazu"
  $repo  = "farmboss-inventario"
  $path  = "inventario.xls"
  $api   = "https://api.github.com/repos/$owner/$repo/contents/$path"
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
  $hdr = @{
    Authorization = "Bearer $tok"
    Accept        = "application/vnd.github+json"
    "User-Agent"  = "FarmBoss"
  }
  $sha = $null
  try {
    $cur = Invoke-RestMethod -Uri $api -Headers $hdr -Method Get
    if ($cur.sha) { $sha = [string]$cur.sha }
  } catch {}
  $bytes = [IO.File]::ReadAllBytes($xls)
  $b64 = [Convert]::ToBase64String($bytes)
  $bodyObj = @{
    message = ("inventario {0}" -f (Get-Date -Format "yyyy-MM-dd HH:mm"))
    content = $b64
  }
  if ($sha) { $bodyObj.sha = $sha }
  $json = $bodyObj | ConvertTo-Json -Compress
  try {
    $r = Invoke-RestMethod -Uri $api -Headers $hdr -Method Put -Body $json -ContentType "application/json"
    Write-Log ("github OK -> {0}" -f $r.content.html_url)
  } catch {
    Write-Log ("github fallo: {0}" -f $_.Exception.Message) "ERR"
  }
}

function Invoke-Conteo {
  param([datetime]$Since = [datetime]::MinValue)
  Ensure-Dirs
  $script:ConteoWhen = Get-Date
  $script:ConteoMeta = @{}
  $script:ConteoMeta = [ordered]@{ generado = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); motor = 'pendiente'; python = ([string](Get-PythonExe)); cuentas = [ordered]@{} }
  if (-not $script:ConteoMeta.python) { $script:ConteoMeta.python = 'no encontrado' }
  $root = $null
  try { $root = Get-FotosRoot } catch { $root = $null }
  $fecha = Get-Date -Format "yyyy-MM-dd HH:mm"  # se pisa por instancia con fecha del Screenshot_
  $instancias = [ordered]@{}
  $dirs = @(Get-InstanceFotoDirs $root)
  $selC = @(Get-CuentasSeleccionadas)
  if ($selC.Count -eq 0) { throw "marca al menos una cuenta" }
  $wantBolsa = $false
  $wantBaul = $false
  try {
    $cfgSides = Load-Cfg
    $wantBolsa = [bool]$cfgSides.conteoBolsa
    $wantBaul = [bool]$cfgSides.conteoBaul
  } catch {}
  if (-not $ConteoOnly) {
    try { if ($script:ChkBolsa) { $wantBolsa = [bool]$script:ChkBolsa.Checked } } catch {}
    try { if ($script:ChkBaul) { $wantBaul = [bool]$script:ChkBaul.Checked } } catch {}
  }
  if (-not $wantBolsa -and -not $wantBaul) { throw "marca Bolsa y/o Baul" }
  $region = "auto"
  if ($wantBolsa -and -not $wantBaul) { $region = "mochila" }
  elseif ($wantBaul -and -not $wantBolsa) { $region = "bodega" }
  $script:ConteoMeta.bolsa = $wantBolsa
  $script:ConteoMeta.baul = $wantBaul
  $dirs = @($dirs | Where-Object {
    $nm = $_.name
    $hit = $false
    foreach ($s in $selC) { if ($nm -eq $s -or $nm -like ("*{0}*" -f $s)) { $hit = $true } }
    $hit
  })
  Write-Log ("conteo filtro: {0} region {1}" -f ($selC -join ","), $region)
  if ($dirs.Count -eq 0) {
    $extra = @($script:FotoRutas | Where-Object {
      $line = "$_"
      $hit = $false
      foreach ($s in $selC) { if ($line -like ("*{0}*" -f $s)) { $hit = $true } }
      $hit
    })
    $msg = "ninguna cuenta seleccionada tiene fotos"
    if ($extra.Count -gt 0) { $msg = $msg + "`n" + ($extra -join "`n") }
    throw $msg
  }
  $lim72 = (Get-Date).AddHours(-72)
  $kept = @()
  foreach ($d0 in $dirs) {
    $st = Get-FolderShotStamp $d0.dir
    if ($st -and $st -ge $lim72) {
      $kept += $d0
    } else {
      Write-Log ("conteo skip {0} sin actividad 72h" -f $d0.name)
    }
  }
  $dirs = $kept
  if ($dirs.Count -eq 0) { throw "ninguna cuenta con fotos de las ultimas 72h" }
  $nDir = $dirs.Count
  $iDir = 0
  foreach ($d in $dirs) {
    $iDir++
    $pct = [int](100 * ($iDir-1) / [Math]::Max(1,$nDir))
    $msg = "[{0}/{1}] {2}%  {3}" -f $iDir, $nDir, $pct, $d.name
    Write-Log $msg
    try { Write-Host $msg -ForegroundColor Yellow } catch {}
    # hora del conteo, no de la foto: si no, GitHub pisa la lectura 09:46 vieja
    $fechaInst = Get-Date -Format "yyyy-MM-dd HH:mm"
    $bolsa = @{}
    $baul = @{}
    $pyHit = Try-ConteoPyFolder $d.dir $region
    $motor = "python conteo.py"
    if ($pyHit.ok) {
      if ($script:ConteoMeta -is [System.Collections.IDictionary]) { $script:ConteoMeta.cuentas[$d.name] = $motor; $script:ConteoMeta.motor = "python conteo.py" }

      foreach ($k in $pyHit.bolsa.Keys) {
        $nk = Norm-InvKey ([string]$k)
        if (-not $nk) { $nk = [string]$k }
        $isCur = $nk -in @("ORO","MUC","BOUND MUC","DIAMANTES")
        $pv = [int64]$pyHit.bolsa[$k]
        if ($isCur) {
          $minOk = if ($nk -eq "ORO") { 10000 } else { 100 }
          if ($pv -ge $minOk) { $bolsa[$nk] = $pv }
        } else {
          $bolsa[$nk] = $pv
        }
      }
      foreach ($k in $pyHit.baul.Keys)  { $baul[(Norm-InvKey ([string]$k))]  = [int64]$pyHit.baul[$k] }
      if (-not $wantBolsa) {
        $keepCur = @{}
        foreach ($ck in @($bolsa.Keys)) {
          if ($ck -in @("ORO","MUC","BOUND MUC","DIAMANTES")) { $keepCur[$ck] = $bolsa[$ck] }
        }
        $bolsa = $keepCur
      }
      if (-not $wantBaul) { $baul = @{} }
      $tieneBolsa = $false
      foreach ($bk in @($bolsa.Keys)) {
        if ($bk -notin @("ORO","MUC","BOUND MUC","DIAMANTES") -and [int64]$bolsa[$bk] -gt 0) { $tieneBolsa = $true }
      }
      foreach ($uk in @($baul.Keys)) {
        if ($uk -and [int64]$baul[$uk] -gt 0) { $tieneBolsa = $true }
      }
      $tieneMonedas = $false
      foreach ($ck in @("ORO","MUC","BOUND MUC","DIAMANTES")) {
        if ($bolsa.ContainsKey($ck) -and [int64]$bolsa[$ck] -gt 0) { $tieneMonedas = $true }
      }
      if (-not $tieneBolsa -and -not $tieneMonedas) {
        Write-Log ("conteo {0}: bolsa cerrada, no se guarda" -f $d.name) "WARN"
        try { Write-Host ("  bolsa cerrada, no se guarda {0}" -f $d.name) -ForegroundColor Yellow } catch {}
        continue
      }
    } else {
      $motor = "python fallo"
      $err = [string]$pyHit.err
      if (-not $err) { $err = "conteo.py no respondio" }
      Write-Log ("conteo {0}: {1}" -f $d.name, $err) "ERR"
      if ($script:ConteoMeta -is [System.Collections.IDictionary]) {
        $script:ConteoMeta.cuentas[$d.name] = $err
        $script:ConteoMeta.error = $err
      }
      $bolsa = @{}
      $baul = @{}
      Write-Log ("conteo {0} omitido (sin plan B)" -f $d.name) "ERR"
      continue
    }
    $instancias[$d.name] = [ordered]@{
      lecturas = @(@{ fecha = $fechaInst; bolsa = $bolsa; baul = $baul; motor = $motor })
    }
    Write-Log ("foto {0} fecha {1}" -f $d.name, $fechaInst)
    $pct2 = [int](100 * $iDir / [Math]::Max(1,$nDir))
    Write-Log ("conteo {0} fotos en {1}  ({2}%)" -f $d.name, $d.dir, $pct2)
    try { Write-Host ("  listo {0}  {1}%" -f $d.name, $pct2) -ForegroundColor Green } catch {}
  }
  if ($instancias.Count -eq 0) { throw "python no conto ninguna cuenta (sin plan B)" }
  $jsonPath = Join-Path $script:ConteoDir "ultimo.json"
  $payload = [ordered]@{ fecha = $fecha; instancias = $instancias }
  ($payload | ConvertTo-Json -Depth 8) | Set-Content $jsonPath -Encoding UTF8

  $libro = Load-InventarioLibro
  foreach ($nm in @($instancias.Keys)) {
    $L0 = $instancias[$nm].lecturas[0]
    $mot0 = ""
    try { $mot0 = [string]$L0.motor } catch { $mot0 = "" }
    $nueva = New-InvLectura $L0.fecha $L0.bolsa $L0.baul $mot0
    $prev = @()
    if ($libro.Contains($nm)) { $prev = @($libro[$nm]) }
    $filled = @()
    $replaced = $false
    foreach ($oldL in @($prev | Where-Object { $_.Fecha -and ("$($_.Fecha)" -notmatch "^LECTURA") })) {
      if ((Get-LecturaFecha $oldL) -eq $L0.fecha) {
        $filled += $nueva
        $replaced = $true
      } else {
        $filled += $oldL
      }
    }
    if (-not $replaced) { $filled += $nueva }
    if ($filled.Count -gt 60) { $filled = $filled[($filled.Count-60)..($filled.Count-1)] }
    $libro[$nm] = $filled
  }
  $uni = Unir-MaestroAuto $libro
  $libro = $uni.libro
  foreach ($name in $instancias.Keys) {
    $csv = Join-Path $script:ConteoDir ("inventario_{0}.csv" -f ($name -replace '[\\/:*?""<>|]','_'))
    $L = $instancias[$name].lecturas[0]
    $lines = @("#;ITEM;BOLSA;BAUL;TOTAL")
    $n=1
    foreach ($it in (Get-InventarioCatalog)) {
      $b=0;$v=0
      if ($L.bolsa.ContainsKey($it)) { $b=[int64]$L.bolsa[$it] }
      if ($L.baul.ContainsKey($it))  { $v=[int64]$L.baul[$it] }
      $lines += ("{0};{1};{2};{3};{4}" -f $n,$it,$b,$v,($b+$v))
      $n++
    }
    $utf8 = New-Object System.Text.UTF8Encoding $true
    [IO.File]::WriteAllLines($csv, $lines, $utf8)
  }
  $doFotos = $false
  try { if ($script:ChkGitFotos) { $doFotos = [bool]$script:ChkGitFotos.Checked } } catch {}
  if (-not $doFotos) {
    try {
      $cfgF = Get-Content $script:CfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($cfgF.githubFotos -eq $true) { $doFotos = $true }
    } catch {}
  }
  if ($doFotos) {
    try {
      $fotoDirs = @()
      foreach ($nm in @($instancias.Keys)) {
        $hit = $dirs | Where-Object { $_.name -eq $nm } | Select-Object -First 1
        if ($hit) { $fotoDirs += $hit }
      }
      if ($fotoDirs.Count -eq 0) { $fotoDirs = @($dirs) }
      Publish-FotosGitHub $fotoDirs
    } catch { Write-Log "fotos git: $_" "ERR" }
  }
  return $jsonPath
}


function Get-RemoteToken {
  $p = Join-Path $script:Root "remote.token"
  if (Test-Path $p) {
    try { $t = (Get-Content $p -Raw).Trim(); if ($t) { return $t } } catch {}
  }
  $t = -join ((1..8 | ForEach-Object { '{0:x}' -f (Get-Random -Max 16) }))
  Set-Content $p $t -Encoding ASCII
  return $t
}

function Get-LanIPv4 {
  try {
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop | Where-Object {
      $_.IPAddress -notmatch '^127\.' -and $_.PrefixOrigin -ne 'WellKnown'
    } | Select-Object -ExpandProperty IPAddress)
    if ($ips) { return $ips[0] }
  } catch {}
  try {
    $ips = @(Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -and $_.IPAddress } | ForEach-Object { $_.IPAddress } | Where-Object { $_ -notmatch ':' -and $_ -notmatch '^127\.' })
    if ($ips) { return $ips[0] }
  } catch {}
  return "127.0.0.1"
}

function Get-CuentasMarcadas {
  $out = @()
  try {
    if ($clCuentas -and $clCuentas.Items.Count -gt 0) {
      foreach ($it in @($clCuentas.CheckedItems)) { $out += [string]$it }
      return $out
    }
  } catch {}
  $f = Join-Path $script:Root "conteo-sel.txt"
  if (Test-Path $f) {
    $out = @(Get-Content $f -Encoding UTF8 | Where-Object { $_.Trim() -ne "" } | ForEach-Object { $_.Trim() })
  }
  return $out
}

function Save-CuentasMarcadas {
  $f = Join-Path $script:Root "conteo-sel.txt"
  $names = @(Get-CuentasMarcadas)
  if ($names.Count -eq 0) { if (Test-Path $f) { Remove-Item $f -Force -ErrorAction SilentlyContinue }; return }
  $names | Set-Content $f -Encoding UTF8
}

function Test-NombreCuenta([string]$nombre, $sel) {
  if (-not $sel -or $sel.Count -eq 0) { return $true }
  $n = $nombre.ToLower()
  foreach ($s in @($sel)) {
    $k = ([string]$s).ToLower().Trim()
    if (-not $k) { continue }
    if ($n -eq $k -or $n -like "*$k*" -or $k -like "*$n*") { return $true }
  }
  return $false
}

function Refresh-ConteoChecks {
  Refresh-CuentaBoxes
}

function Resolve-CuentaIdx([string]$name) {
  $name = ([string]$name).Trim()
  if (-not $name) { return $null }
  $all = @(Get-List2)
  $n = $name.ToLower()
  $hit = $all | Where-Object { ([string]$_.name).ToLower() -eq $n } | Select-Object -First 1
  if (-not $hit) { $hit = $all | Where-Object { ([string]$_.name).ToLower() -like "*$n*" } | Select-Object -First 1 }
  $idxTry = 0
  if (-not $hit -and [int]::TryParse($name, [ref]$idxTry)) {
    $hit = $all | Where-Object { $_.idx -eq $idxTry } | Select-Object -First 1
  }
  return $hit
}

function Start-CuentaRemota([string]$name) {
  $hit = Resolve-CuentaIdx $name
  if (-not $hit) { Write-Log ("remoto: no existe {0}" -f $name) "ERR"; return "no existe $name" }
  $idx = [int]$hit.idx
  if (-not $hit.alive) {
    $exe = Join-Path $script:Ld "ldconsole.exe"
    Write-Log ("remoto launch idx {0} {1}" -f $idx, $hit.name)
    & $exe launch --index $idx 2>$null | Out-Null
    return ("lanzada idx {0} {1} - boot al detectar PID" -f $idx, $hit.name)
  }
  Start-BootJob2 $idx $hit.hwnd
  return ("boot idx {0} {1}" -f $idx, $hit.name)
}

function Process-RemoteInbox {
  $f = Join-Path $script:Root "remote-inbox.txt"
  if (-not (Test-Path $f)) { return }
  $lines = @()
  try {
    $lines = @(Get-Content $f -Encoding UTF8 -ErrorAction Stop)
    Remove-Item $f -Force -ErrorAction SilentlyContinue
  } catch { return }
  foreach ($ln in $lines) {
    $ln = $ln.Trim()
    if (-not $ln) { continue }
    $p = $ln.Split("|", 2)
    $op = $p[0].ToLower()
    $arg = ""
    if ($p.Count -gt 1) { $arg = $p[1] }
    if ($op -eq "boot") {
      $msg = Start-CuentaRemota $arg
      Write-Log ("remoto boot: {0}" -f $msg)
      try { $lbl.Text = $msg } catch {}
    } elseif ($op -eq "conteo") {
      if ($arg) { $arg.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Set-Content (Join-Path $script:Root "conteo-sel.txt") -Encoding UTF8 }
      $me = $PSCommandPath
      if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
      Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
        "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ConteoOnly"
      )
      Write-Log ("remoto conteo: {0}" -f $arg)
      try { $lbl.Text = "Conteo remoto" } catch {}
    }
  }
}

function Start-RemoteListen {
  if ($script:RemoteJob -and ($script:RemoteJob.State -eq "Running")) { return }
  $tok = Get-RemoteToken
  $port = 17890
  $inbox = Join-Path $script:Root "remote-inbox.txt"
  $ip = Get-LanIPv4
  $script:RemoteUrl = "http://{0}:{1}/?t={2}" -f $ip, $port, $tok
  $script:RemoteJob = Start-Job -Name "FarmBossRemote" -ScriptBlock {
    param($port, $tok, $inbox)
    $tcp = $null
    try {
      $tcp = New-Object System.Net.Sockets.TcpListener ([System.Net.IPAddress]::Any), $port
      $tcp.Start()
    } catch { return }
    function Send-Http($s, $code, $html) {
      $body = [Text.Encoding]::UTF8.GetBytes($html)
      $hdr = "HTTP/1.1 $code OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($body.Length)`r`nConnection: close`r`n`r`n"
      $hb = [Text.Encoding]::ASCII.GetBytes($hdr)
      $s.Write($hb, 0, $hb.Length)
      $s.Write($body, 0, $body.Length)
    }
    while ($true) {
      try {
        if (-not $tcp.Pending()) { Start-Sleep -Milliseconds 250; continue }
        $cli = $tcp.AcceptTcpClient()
        $cli.ReceiveTimeout = 4000
        $st = $cli.GetStream()
        $buf = New-Object byte[] 4096
        $n = $st.Read($buf, 0, $buf.Length)
        $req = [Text.Encoding]::ASCII.GetString($buf, 0, [Math]::Max(0,$n))
        $line = (($req -split "`n")[0]).Trim()
        $path = "/"
        if ($line -match 'GET\s+(\S+)') { $path = $Matches[1] }
        $q = ""
        if ($path.Contains("?")) { $q = $path.Substring($path.IndexOf("?")+1); $path = $path.Substring(0, $path.IndexOf("?")) }
        $qs = @{}
        foreach ($pair in $q.Split("&")) {
          if (-not $pair) { continue }
          $kv = $pair.Split("=", 2)
          $k = [Uri]::UnescapeDataString($kv[0])
          $v = ""
          if ($kv.Count -gt 1) { $v = [Uri]::UnescapeDataString($kv[1]) }
          $qs[$k] = $v
        }
        $okTok = ($qs["t"] -eq $tok)
        if (-not $okTok) {
          Send-Http $st "403" "<html><body>token malo</body></html>"
          $cli.Close(); continue
        }
        if ($path -eq "/boot") {
          $nm = $qs["name"]
          Add-Content $inbox ("boot|{0}" -f $nm) -Encoding UTF8
          Send-Http $st "200" ("<html><body>boot {0}</body></html>" -f $nm)
        } elseif ($path -eq "/conteo") {
          $nm = $qs["name"]
          Add-Content $inbox ("conteo|{0}" -f $nm) -Encoding UTF8
          Send-Http $st "200" ("<html><body>conteo {0}</body></html>" -f $nm)
        } else {
          $html = @"
<html><head><meta name=viewport content='width=device-width'><title>FarmBoss</title>
<style>body{font-family:sans-serif;background:#111;color:#eee;padding:16px}a,button{display:block;margin:8px 0;padding:12px;background:#2E75B6;color:#fff;text-decoration:none;border:0;border-radius:8px;width:100%;text-align:left;font-size:16px}</style>
</head><body>
<h3>FarmBoss remoto</h3>
<p>Usa los botones. El token ya va en el link.</p>
<p><b>Activar</b> abre/bootea esa ventana. <b>Contar</b> solo las que marques en FarmBoss o name=Golosa,Danger</p>
<a href="/boot?name=Golosa&t=$tok">Activar Golosa</a>
<a href="/boot?name=Danger&t=$tok">Activar Danger</a>
<a href="/boot?name=Luisgot&t=$tok">Activar Luisgot</a>
<a href="/boot?name=BF&t=$tok">Activar BF</a>
<a href="/boot?name=CCM&t=$tok">Activar CCM</a>
<a href="/conteo?name=Golosa&t=$tok">Contar solo Golosa</a>
<a href="/conteo?name=Danger&t=$tok">Contar solo Danger</a>
<a href="/conteo?name=Luisgot&t=$tok">Contar solo Luisgot</a>
<a href="/conteo?name=BF&t=$tok">Contar solo BF</a>
<a href="/conteo?name=CCM&t=$tok">Contar solo CCM</a>
</body></html>
"@
          Send-Http $st "200" $html
        }
        $cli.Close()
      } catch { Start-Sleep -Milliseconds 200 }
    }
  } -ArgumentList $port, $tok, $inbox
  Write-Log ("remoto ON {0}" -f $script:RemoteUrl)
}

# ---------------- UI ----------------
if ($ListaMaestra) {
  try { $Host.UI.RawUI.WindowTitle = "FarmBoss LISTA MAESTRA" } catch {}
  Write-Host "LISTA MAESTRA - no cierres hasta LISTO" -ForegroundColor Cyan
  try {
    $out = Invoke-ListaMaestra
    Write-Host ""
    Write-Host ("LISTO  {0}" -f $out) -ForegroundColor Green
  } catch {
    Write-Host $_ -ForegroundColor Red
  }
  Write-Host "Enter para cerrar"
  [void](Read-Host)
  return
}

if ($Actualizar) {
  try { $Host.UI.RawUI.WindowTitle = "FarmBoss ACTUALIZAR" } catch {}
  try {
    Invoke-ActualizarPrograma | Out-Null
    $me = Join-Path $script:Root "FarmBoss.ps1"
    $cmd = "Start-Sleep -Seconds 2; Start-Process -FilePath powershell.exe -ArgumentList '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File','$me'"
    Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList @("-NoProfile","-WindowStyle","Hidden","-Command", $cmd)
  } catch {
    Write-Host $_ -ForegroundColor Red
    Write-Host "Enter para cerrar"
    [void](Read-Host)
  }
  return
}

$form               = New-Object System.Windows.Forms.Form
$form.Text          = "FarmBoss  v$($script:Version)  -  LDPlayer + Socks + Angel S"
$form.Size          = New-Object System.Drawing.Size(860, 920)
$form.StartPosition = "CenterScreen"
$form.Font          = New-Object System.Drawing.Font("Segoe UI", 9)

$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(12, 12)
$grid.Size     = New-Object System.Drawing.Size(820, 200)
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.SelectionMode = "FullRowSelect"
$grid.MultiSelect = $true
$grid.AutoSizeColumnsMode = "Fill"
$grid.RowHeadersVisible = $false
[void]$grid.Columns.Add("idx", "Idx")
[void]$grid.Columns.Add("nombre", "Nombre")
[void]$grid.Columns.Add("estado", "Estado")
[void]$grid.Columns.Add("fallos", "Fallos")
[void]$grid.Columns.Add("pid", "PID")
$cAuto = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$cAuto.Name = "auto"; $cAuto.HeaderText = "Auto-inicio"
[void]$grid.Columns.Add($cAuto)
$cCnt = New-Object System.Windows.Forms.DataGridViewCheckBoxColumn
$cCnt.Name = "contar"; $cCnt.HeaderText = "Contar"
[void]$grid.Columns.Add($cCnt)
[void]$grid.Columns.Add("orden", "Orden")
$grid.Columns["idx"].FillWeight = 6
$grid.Columns["nombre"].FillWeight = 22
$grid.Columns["estado"].FillWeight = 10
$grid.Columns["fallos"].FillWeight = 7
$grid.Columns["pid"].FillWeight = 8
$grid.Columns["auto"].FillWeight = 12
$grid.Columns["contar"].FillWeight = 8
$grid.Columns["orden"].FillWeight = 7
$grid.Columns["orden"].DefaultCellStyle.NullValue = ""

$grid.add_CurrentCellDirtyStateChanged({
  try {
    if ($grid.IsCurrentCellDirty) { [void]$grid.CommitEdit([Windows.Forms.DataGridViewDataErrorContexts]::Commit) }
  } catch {}
})
$grid.add_CellValueChanged({
  param($s,$e)
  try {
    if ($e.RowIndex -lt 0) { return }
    $col = $grid.Columns[$e.ColumnIndex].Name
    if ($col -eq "auto" -or $col -eq "contar" -or $col -eq "orden") { Save-Cfg }
  } catch {}
})

$grid.Columns["idx"].ReadOnly = $true
$grid.Columns["nombre"].ReadOnly = $true
$grid.Columns["estado"].ReadOnly = $true
$grid.Columns["fallos"].ReadOnly = $true
$grid.Columns["pid"].ReadOnly = $true
# orden queda en blanco si el usuario no pone numero
try {
  $prop = $grid.GetType().GetProperty("DoubleBuffered", [Reflection.BindingFlags] "Instance,NonPublic")
  if ($prop) { $prop.SetValue($grid, $true, $null) }
} catch {}
$form.Controls.Add($grid)

function Add-Time($text, $x, $y, $min, $max, $val, $wLbl=118, $wNud=52) {
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $text
  $l.Location = New-Object System.Drawing.Point($x, ($y + 3))
  $l.Size = New-Object System.Drawing.Size($wLbl, 18)
  $form.Controls.Add($l)
  $n = New-Object System.Windows.Forms.NumericUpDown
  $n.Location = New-Object System.Drawing.Point(($x + $wLbl), $y)
  $n.Size = New-Object System.Drawing.Size($wNud, 22)
  $n.Minimum = $min; $n.Maximum = $max; $n.Value = $val
  $form.Controls.Add($n)
  return $n
}

$nudLaunch    = Add-Time "1 Entre Instancias"  12  218 5 300 15 118 48
$nudReady     = Add-Time "2 Abrir SOCK"        196 218 0 120 15 110 48
$nudSockOpen  = Add-Time "3 Error SOCK"        372 218 0 60   5 100 48
$nudSockGap   = Add-Time "4 SOCK ON"           536 218 0 30   1 100 48

$nudSockOn    = Add-Time "5 HOME"              12  244 0 60   8  70 48
$nudHome      = Add-Time "6 Abrir Angel"       150 244 0 30   2 100 48
$nudAngelOpen = Add-Time "7 Boton azul"        316 244 0 180 60 100 48
$nudAngelTap  = Add-Time "8 Marciano"          484 244 0 60   5  90 48

$nudPlayGap   = Add-Time "9 Play bot"          12  270 0 30   2  90 48
$nudMin       = Add-Time "10 Minimizar"        168 270 0 180 10 100 48

$lbl = New-Object System.Windows.Forms.Label
$lbl.Location = New-Object System.Drawing.Point(12, 678)
$lbl.Size = New-Object System.Drawing.Size(820, 20)
$lbl.Text = "Motor: detenido"
$form.Controls.Add($lbl)

$lamp = New-Object System.Windows.Forms.Label
$lamp.Location = New-Object System.Drawing.Point(620, 268)
$lamp.Size = New-Object System.Drawing.Size(212, 28)
$lamp.TextAlign = [Drawing.ContentAlignment]::MiddleCenter
$lamp.Font = New-Object System.Drawing.Font("Segoe UI", 10, [Drawing.FontStyle]::Bold)
$lamp.Text = "DETENIDO"
$lamp.BackColor = [Drawing.Color]::IndianRed
$lamp.ForeColor = [Drawing.Color]::White

$lblVer = New-Object System.Windows.Forms.Label
$lblVer.Text = "v$($script:Version)"
$lblVer.Location = New-Object System.Drawing.Point(780, 8)
$lblVer.Size = New-Object System.Drawing.Size(52, 18)
$lblVer.TextAlign = [Drawing.ContentAlignment]::MiddleRight
$lblVer.ForeColor = [Drawing.Color]::DimGray
$lblVer.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$form.Controls.Add($lblVer)

function Set-MonitorLamp {
  if ($script:Running) {
    $lamp.Text = "MONITOREANDO"
    $lamp.BackColor = [Drawing.Color]::Lime
    $lamp.ForeColor = [Drawing.Color]::Black
  } else {
    $lamp.Text = "DETENIDO"
    $lamp.BackColor = [Drawing.Color]::IndianRed
    $lamp.ForeColor = [Drawing.Color]::White
  }
}

function Set-CountLine([string]$text) {
  if (-not $script:TxtLog) { return }
  $tb = $script:TxtLog
  $lines = @($tb.Lines)
  if ($lines.Count -gt 0 -and $lines[$lines.Count - 1] -like ">> *") {
    $lines[$lines.Count - 1] = $text
    $tb.Lines = $lines
  } else {
    $tb.AppendText($text + [Environment]::NewLine)
  }
  $tb.SelectionStart = $tb.Text.Length
  $tb.ScrollToCaret()
}

function Add-Btn($text, $x, $y, $w, $click, $parent) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.Location = New-Object System.Drawing.Point($x, $y)
  $b.Size = New-Object System.Drawing.Size($w, 28)
  $b.Add_Click($click)
  if (-not $parent) { $parent = $form }
  $parent.Controls.Add($b)
  return $b
}

function Add-Help($x, $y, $title, $text) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = "?"
  $b.Location = New-Object System.Drawing.Point($x, $y)
  $b.Size = New-Object System.Drawing.Size(22, 30)
  $b.Add_Click({
    [void][System.Windows.Forms.MessageBox]::Show($text, $title, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
  }.GetNewClosure())
  $form.Controls.Add($b)
}

$grpMotor = New-Object System.Windows.Forms.GroupBox
$grpMotor.Text = "Motor"
$grpMotor.Location = New-Object System.Drawing.Point(12, 300)
$grpMotor.Size = New-Object System.Drawing.Size(836, 96)
$form.Controls.Add($grpMotor)
$lamp.Location = New-Object System.Drawing.Point(470, 20)
$lamp.Size = New-Object System.Drawing.Size(200, 28)
$grpMotor.Controls.Add($lamp)

[void](Add-Btn "Actualizar" 10 20 100 { Fill-Grid -ReloadAuto; Refresh-ConteoChecks; $lbl.Text = "Lista ok" } $grpMotor)
[void](Add-Btn "Iniciar Motor" 116 20 120 {
  Save-Cfg
  if ($script:Running) { $lbl.Text = "Ya corre"; return }
  Start-Multiplayer
  Start-Sleep 2
  $script:LastPid = @{}
  $script:LastLaunch = [datetime]"2000-01-01"
  Queue-AutoStartsOnce
  $script:Running = $true
  $lbl.Text = "Motor: ON"
  $lbl.ForeColor = [Drawing.Color]::DarkGreen
  Set-MonitorLamp
  Write-Log "motor ON"
  Fill-Grid
} $grpMotor)
[void](Add-Btn "Detener Motor" 242 20 120 {
  $script:Running = $false
  $lbl.Text = "Motor: detenido"
  $lbl.ForeColor = [Drawing.Color]::DarkRed
  Set-MonitorLamp
  Write-Log "motor OFF"
} $grpMotor)
[void](Add-Btn "Ayuda" 680 20 80 {
  $msg = "Actualizar: vuelve a listar las ventanas.`r`nActualizar FarmBoss: baja el programa, cierra esta ventana y la vuelve a abrir. El motor parte solo.`r`nIniciar Motor: prende el auto-inicio.`r`nDetener Motor: lo apaga hasta que se cierre el programa.`r`nInicio Windows: abre FarmBoss al prender el servidor.`r`nGuardar: guarda los tiempos y las rutas.`r`nBoot ahora: arranca la ventana seleccionada.`r`nContar: cuenta las cuentas marcadas.`r`nSacar fotos y contar: saca la foto y despues cuenta.`r`nAbrir fotos Git y Bajar maestro usan la clave guardada, no piden login."
  [void][System.Windows.Forms.MessageBox]::Show($msg, "Ayuda", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
} $grpMotor)
[void](Add-Btn "Inicio Windows" 10 54 130 {
  Save-Cfg
  $startup = [Environment]::GetFolderPath("Startup")
  $lnk = Join-Path $startup "FarmBoss.lnk"
  $w = New-Object -ComObject WScript.Shell
  $s = $w.CreateShortcut($lnk)
  $vbs = "C:\keepalive\FarmBoss.vbs"
  $bat = "C:\keepalive\farm-start.bat"
  if (Test-Path $vbs) {
    $s.TargetPath = "wscript.exe"
    $s.Arguments  = "`"$vbs`" -AutoStart"
  } elseif (Test-Path $bat) {
    $s.TargetPath = $bat
    $s.Arguments  = "-AutoStart"
  } else {
    $s.TargetPath = "powershell.exe"
    $s.Arguments  = "-NoLogo -STA -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"C:\keepalive\FarmBoss.ps1`" -AutoStart"
  }
  $s.WorkingDirectory = "C:\keepalive"
  $s.WindowStyle = 7
  $s.Save()
  $lbl.Text = "Inicio Windows: ON"
  $lbl.ForeColor = [Drawing.Color]::DarkGreen
  Write-Log "acceso Inicio creado $lnk"
} $grpMotor)
[void](Add-Btn "Quitar Inicio" 146 54 110 {
  $lnk = Join-Path ([Environment]::GetFolderPath("Startup")) "FarmBoss.lnk"
  if (Test-Path $lnk) { Remove-Item $lnk -Force; $lbl.Text = "Quitado de Inicio"; Write-Log "acceso Inicio eliminado" }
  else { $lbl.Text = "No habia acceso" }
} $grpMotor)
[void](Add-Btn "Guardar" 262 54 80 {
  Save-Cfg
  $lbl.Text = "Guardado farm-settings.json"
  Write-Log "config guardada"
} $grpMotor)
[void](Add-Btn "Boot ahora" 348 54 100 {
  if ($grid.CurrentRow) {
    $idx = [int]$grid.CurrentRow.Cells["idx"].Value
    $it = Get-List2 | Where-Object { $_.idx -eq $idx } | Select-Object -First 1
    if ($it -and $it.alive) { Start-BootJob2 $idx $it.hwnd; $lbl.Text = "Boot idx $idx" }
    else { $lbl.Text = "Esa ventana esta cerrada" }
  }
} $grpMotor)
[void](Add-Btn "Abrir logs" 454 54 100 {
  Ensure-Dirs
  Start-Process explorer.exe $script:LogDir
} $grpMotor)

$grpRemoto = New-Object System.Windows.Forms.GroupBox
$grpRemoto.Text = "Remoto"
$grpRemoto.Location = New-Object System.Drawing.Point(12, 402)
$grpRemoto.Size = New-Object System.Drawing.Size(150, 96)
$form.Controls.Add($grpRemoto)
[void](Add-Btn "Remoto" 12 36 120 {
  Start-RemoteListen
  $u = $script:RemoteUrl
  try { Set-Clipboard $u } catch {}
  [Windows.Forms.MessageBox]::Show("Abre esto en el celular (misma red):`r`n$u`r`n`r`nEl link ya lleva el token. FarmBoss tiene que quedar abierto.", "FarmBoss remoto")
  $lbl.Text = "Remoto ON"
} $grpRemoto)

$grpContar = New-Object System.Windows.Forms.GroupBox
$grpContar.Text = "Contar"
$grpContar.Location = New-Object System.Drawing.Point(170, 402)
$grpContar.Size = New-Object System.Drawing.Size(678, 132)
$form.Controls.Add($grpContar)
[void](Add-Btn "Contar" 10 22 80 {
  Save-Cfg
  $selNow = @(Get-CuentasSeleccionadas)
  if ($selNow.Count -eq 0) { $lbl.Text = "marca al menos una cuenta"; return }
  $doB = $false; $doU = $false
  try { if ($script:ChkBolsa) { $doB = [bool]$script:ChkBolsa.Checked } } catch {}
  try { if ($script:ChkBaul) { $doU = [bool]$script:ChkBaul.Checked } } catch {}
  if (-not $doB -and -not $doU) { $lbl.Text = "marca Bolsa y/o Baul"; return }
  Save-ConteoSel $selNow
  $lbl.Text = "Conteo en otra ventana"
  $me = $PSCommandPath
  if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
  Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ConteoOnly"
  )
  Write-Log ("conteo lanzado {0} bolsa={1} baul={2}" -f ($selNow -join ","), $doB, $doU)
} $grpContar)
[void](Add-Btn "Sacar fotos y contar" 96 22 160 {
  Save-Cfg
  $selNow = @(Get-CuentasSeleccionadas)
  if ($selNow.Count -eq 0) { $lbl.Text = "marca al menos una cuenta"; return }
  $lbl.Text = "Fotos en otra ventana"
  Start-FotosProceso
  Write-Log ("fotos lanzadas {0}" -f ($selNow -join ","))
} $grpContar)

$script:ChkBolsa = New-Object System.Windows.Forms.CheckBox
$script:ChkBolsa.Text = "Bolsa"
$script:ChkBolsa.Location = New-Object System.Drawing.Point(264, 24)
$script:ChkBolsa.Size = New-Object System.Drawing.Size(62, 24)
$script:ChkBolsa.Checked = $false
$grpContar.Controls.Add($script:ChkBolsa)

$script:ChkBaul = New-Object System.Windows.Forms.CheckBox
$script:ChkBaul.Text = "Baul"
$script:ChkBaul.Location = New-Object System.Drawing.Point(328, 24)
$script:ChkBaul.Size = New-Object System.Drawing.Size(58, 24)
$script:ChkBaul.Checked = $false
$grpContar.Controls.Add($script:ChkBaul)

$script:ChkGitFotos = New-Object System.Windows.Forms.CheckBox
$script:ChkGitFotos.Text = "Fotos Git"
$script:ChkGitFotos.Location = New-Object System.Drawing.Point(390, 24)
$script:ChkGitFotos.Size = New-Object System.Drawing.Size(90, 24)
$script:ChkGitFotos.Checked = $false
$grpContar.Controls.Add($script:ChkGitFotos)

[void](Add-Btn "Hacer lista maestra" 10 90 170 {
  Save-Cfg
  $lbl.Text = "Lista maestra en otra ventana"
  $me = $PSCommandPath
  if (-not $me) { $me = Join-Path $script:Root "FarmBoss.ps1" }
  Start-Process -FilePath "powershell.exe" -WindowStyle Normal -ArgumentList @(
    "-NoProfile","-ExecutionPolicy","Bypass","-STA","-File", $me, "-ListaMaestra"
  )
  Write-Log "lista maestra lanzada"
} $grpContar)
[void](Add-Btn "Actualizar FarmBoss" 190 90 180 {
  $lbl.Text = "Actualizando FarmBoss"
  try {
    $msg = Invoke-ActualizarPrograma
    Write-Log $msg
    $me = Join-Path $script:Root "FarmBoss.ps1"
    $cmd = "Start-Sleep -Seconds 2; Start-Process -FilePath powershell.exe -ArgumentList '-NoProfile','-STA','-ExecutionPolicy','Bypass','-File','$me'"
    Start-Process -FilePath "powershell.exe" -WindowStyle Hidden -ArgumentList @("-NoProfile","-WindowStyle","Hidden","-Command", $cmd)
    $form.Close()
  } catch {
    $lbl.Text = "$_"
    $lbl.ForeColor = [Drawing.Color]::DarkRed
    Write-Log "actualizar: $_" "ERROR"
  }
} $grpContar)
[void](Add-Btn "Abrir fotos Git" 10 56 120 {
  $lbl.Text = "bajando fotos git"
  $r = Open-FotosGitLocal
  $lbl.Text = $r
  Write-Log $r
} $grpContar)
[void](Add-Btn "Bajar maestro" 136 56 110 {
  $lbl.Text = "bajando maestro"
  $r = Open-MaestroGitLocal
  $lbl.Text = $r
  Write-Log $r
} $grpContar)

function Fill-MacroCombo {
  if (-not $script:CboMacro) { return }
  $names = @()
  foreach ($row in @($grid.Rows)) {
    if ($row.IsNewRow) { continue }
    $nm = [string]$row.Cells["nombre"].Value
    if ($nm) { $names += $nm }
  }
  $cur = [string]$script:CboMacro.Text
  $have = @($script:CboMacro.Items | ForEach-Object { "$_" })
  if (($names -join "|") -eq ($have -join "|")) { return }
  $script:CboMacro.BeginUpdate()
  $script:CboMacro.Items.Clear()
  foreach ($n in $names) { [void]$script:CboMacro.Items.Add($n) }
  $script:CboMacro.EndUpdate()
  if ($cur -and ($names -contains $cur)) { $script:CboMacro.Text = $cur }
}

$lblMacro = New-Object System.Windows.Forms.Label
$lblMacro.Text = "Instancia"
$lblMacro.Location = New-Object System.Drawing.Point(254, 60)
$lblMacro.Size = New-Object System.Drawing.Size(62, 20)
$grpContar.Controls.Add($lblMacro)
$script:CboMacro = New-Object System.Windows.Forms.ComboBox
$script:CboMacro.Location = New-Object System.Drawing.Point(318, 56)
$script:CboMacro.Size = New-Object System.Drawing.Size(200, 24)
$script:CboMacro.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$grpContar.Controls.Add($script:CboMacro)
[void](Add-Btn "Test Macro" 526 56 110 {
  $nm = ""
  try { $nm = [string]$script:CboMacro.Text } catch { $nm = "" }
  $nm = $nm.Trim()
  if (-not $nm) { $lbl.Text = "elige una instancia"; return }
  $lbl.Text = "Macro $nm"
  Start-MacroProceso $nm
  Write-Log ("macro manual {0}" -f $nm)
} $grpContar)

$grpBak = New-Object System.Windows.Forms.GroupBox
$grpBak.Text = "Backup"
$grpBak.Location = New-Object System.Drawing.Point(12, 540)
$grpBak.Size = New-Object System.Drawing.Size(836, 124)
$form.Controls.Add($grpBak)

$lblXz = New-Object System.Windows.Forms.Label
$lblXz.Text = "XuanZhi9"
$lblXz.Location = New-Object System.Drawing.Point(10, 26)
$lblXz.Size = New-Object System.Drawing.Size(70, 20)
$grpBak.Controls.Add($lblXz)
$txtXz = New-Object System.Windows.Forms.TextBox
$txtXz.Location = New-Object System.Drawing.Point(84, 22)
$txtXz.Size = New-Object System.Drawing.Size(430, 24)
$txtXz.Text = "C:\Users\jorge\OneDrive\Documentos\XuanZhi9"
$grpBak.Controls.Add($txtXz)
[void](Add-Btn "Backup ahora" 522 20 110 {
  Save-Cfg
  Start-XzBackup -Force
  $lbl.Text = "Backup XuanZhi9 en curso"
} $grpBak)
[void](Add-Btn "Ver backups" 638 20 110 {
  Ensure-Dirs
  Start-Process explorer.exe $script:BakDir
} $grpBak)

$lblVms = New-Object System.Windows.Forms.Label
$lblVms.Text = "VMS"
$lblVms.Location = New-Object System.Drawing.Point(10, 56)
$lblVms.Size = New-Object System.Drawing.Size(70, 20)
$grpBak.Controls.Add($lblVms)
$txtVms = New-Object System.Windows.Forms.TextBox
$txtVms.Location = New-Object System.Drawing.Point(84, 52)
$txtVms.Size = New-Object System.Drawing.Size(430, 24)
$txtVms.Text = "C:\LDPlayer\LDPlayer9\vms"
$grpBak.Controls.Add($txtVms)
[void](Add-Btn "Backup VMS" 522 50 110 {
  Save-Cfg
  Start-VmsBackup
  $lbl.Text = "Backup VMS en curso"
} $grpBak)
[void](Add-Btn "Ver backup VMS" 638 50 140 {
  Ensure-Dirs
  Start-Process explorer.exe $script:BakDir
} $grpBak)

$script:TxtLog = New-Object System.Windows.Forms.TextBox
$script:TxtLog.Location = New-Object System.Drawing.Point(12, 704)
$script:TxtLog.Size = New-Object System.Drawing.Size(820, 150)
$script:TxtLog.Multiline = $true
$script:TxtLog.ScrollBars = "Vertical"
$script:TxtLog.ReadOnly = $true
$script:TxtLog.Font = New-Object System.Drawing.Font("Consolas", 8)
$form.Controls.Add($script:TxtLog)

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1000
$timer.Add_Tick({
  try { Drain-RemoteQ } catch {}
  Sweep-BootJobs
  try { Sweep-PendingActivar } catch {}
  try { Poll-RemoteCmd } catch {}
  try { Check-XzDaily } catch {}
  $script:ScanLeft--
  if ($script:ScanLeft -le 0) {
    $script:ScanLeft = 4
    Fill-Grid
    if ($script:Running) { Tick-Engine }
  }
  if (-not $script:Running) { return }
})
$timer.Start()

$form.Add_Shown({
  $script:LoadingCfg = $true
  Ensure-Dirs
  $cfg = Load-Cfg
  try { if ($script:TxtCuenta -and $cfg.cuentaNumero) { $script:TxtCuenta.Text = [string]$cfg.cuentaNumero } } catch {}
  $script:FotosPath = ""
  if ($cfg.fotosPath) { $script:FotosPath = [string]$cfg.fotosPath }
  if ($cfg.ldPath) { $script:Ld = $cfg.ldPath }
  function Set-Nud($nud, $v) {
    if ($null -eq $v) { return }
    try {
      $n = [decimal]$v
      if ($n -lt $nud.Minimum) { $n = $nud.Minimum }
      if ($n -gt $nud.Maximum) { $n = $nud.Maximum }
      $nud.Value = $n
    } catch {}
  }
  try {
  Set-Nud $nudLaunch    $cfg.delayBetweenSec
  Set-Nud $nudMin       $cfg.minimizeAfterSec
  Set-Nud $nudReady     $cfg.afterAndroidSec
  Set-Nud $nudSockOpen  $cfg.afterSockOpenSec
  $gap = $cfg.sockTapGapSec
  if ($null -eq $gap -and $cfg.sockTapGapMs) {
    $gap = [math]::Max(1, [int]([double]$cfg.sockTapGapMs / 1000))
  }
  Set-Nud $nudSockGap   $gap
  Set-Nud $nudSockOn    $cfg.afterSockOnSec
  Set-Nud $nudHome      $cfg.afterHomeSec
  Set-Nud $nudAngelOpen $cfg.afterAngelLaunchSec
  Set-Nud $nudAngelTap  $cfg.afterAngelTapSec
  Set-Nud $nudPlayGap   $cfg.martianToPlaySec
  } catch { Write-Log "nuds: $_" "WARN" }
  try { Fill-Grid -ReloadAuto } catch { Write-Log "lista ldplayer: $_" "WARN" }
  if ($cfg.xuanzhiPath) { $txtXz.Text = [string]$cfg.xuanzhiPath }
  if ($cfg.vmsPath) { $txtVms.Text = [string]$cfg.vmsPath }
  Write-Log ("FarmBoss {0} abierto" -f $script:Version)
  try { Refresh-CuentaBoxes } catch {}
  try {
    $cfg2 = Load-Cfg
    if ($script:ChkBolsa) { $script:ChkBolsa.Checked = [bool]$cfg2.conteoBolsa }
    if ($script:ChkBaul) { $script:ChkBaul.Checked = [bool]$cfg2.conteoBaul }
    if ($script:ChkGitFotos) { $script:ChkGitFotos.Checked = [bool]$cfg2.githubFotos }
  } catch {}
  $script:LoadingCfg = $false

  try { Start-XzBackup } catch { Write-Log "backup: $_" "WARN" }
  Save-Cfg
  Start-Multiplayer
  Start-Sleep 2
  $script:LastPid = @{}
  $script:LastLaunch = [datetime]"2000-01-01"
  Queue-AutoStartsOnce
  $script:Running = $true
  $lbl.Text = "Motor: ON"
  $lbl.ForeColor = [Drawing.Color]::DarkGreen
  Set-MonitorLamp
  Write-Log "motor ON al abrir"
})
$form.Add_FormClosing({
  try { Save-Cfg } catch {}
  try { Stop-RemoteServer } catch {}
  $timer.Stop()
  $script:Running = $false
  Get-Job | Where-Object { $_.State -ne "Running" } | Remove-Job -Force -ErrorAction SilentlyContinue
})

if ($MacroOnly) {
  try { $Host.UI.RawUI.WindowTitle = "FarmBoss MACRO" } catch {}
  $nm = ""
  if ($Cuentas) { $nm = (($Cuentas.Split(",") | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -First 1)) }
  Write-Host ("MACRO {0}" -f $nm) -ForegroundColor Cyan
  Write-Host "cabeza, pausa, abajo, inventario, foto, cabeza, play" -ForegroundColor Cyan
  try {
    if (-not $nm) { throw "elige una instancia" }
    $ok = Invoke-FotoUna $nm
    Write-Host ""
    if ($ok) { Write-Host "LISTO" -ForegroundColor Green }
    else { Write-Host "no salio la foto" -ForegroundColor Yellow }
  } catch {
    Write-Host $_ -ForegroundColor Red
  }
  Write-Host "Enter para cerrar"
  [void](Read-Host)
  return
}

if ($FotosOnly) {
  try { $Host.UI.RawUI.WindowTitle = "FarmBoss FOTOS" } catch {}
  Write-Host "FOTOS - pausa, bolsa, foto, play. Luego cuenta las que salieron." -ForegroundColor Cyan
  try {
    $r = Invoke-FotosAuto
    $ok = @($r.ok | Where-Object { $_ })
    $fallo = @($r.fallo | Where-Object { $_ })
    Write-Host ""
    if ($ok.Count -gt 0) {
      Write-Host ("conteo: {0}" -f ($ok -join ", ")) -ForegroundColor Green
      Start-ConteoProceso ($ok -join ",")
    } else {
      Write-Host "ninguna foto nueva, no hay conteo" -ForegroundColor Yellow
    }
    if ($fallo.Count -gt 0) {
      Write-Host ("sin foto: {0}" -f ($fallo -join ", ")) -ForegroundColor Yellow
    }
    Write-Host "LISTO" -ForegroundColor Green
  } catch {
    Write-Host $_ -ForegroundColor Red
  }
  Write-Host "Enter para cerrar"
  [void](Read-Host)
  return
}

if ($ConteoOnly) {
  try { $Host.UI.RawUI.WindowTitle = "FarmBoss CONTEO" } catch {}
  try {
    $ui = $Host.UI.RawUI
    $buf = $ui.BufferSize
    if ($buf.Width -lt 70) { $buf.Width = 70 }
    if ($buf.Height -lt 80) { $buf.Height = 80 }
    $ui.BufferSize = $buf
    $ws = $ui.WindowSize
    $ws.Width = 70
    $ws.Height = 16
    $ui.WindowSize = $ws
  } catch {}
  Write-Host "CONTEO - no cierres hasta LISTO" -ForegroundColor Cyan
  try {
    $out = Invoke-Conteo
    Write-Host ""
    Write-Host ("LISTO  {0}" -f $out) -ForegroundColor Green
  } catch {
    Write-Host $_ -ForegroundColor Red
  }
  Write-Host "Enter para cerrar"
  [void](Read-Host)
  return
}

try {
  Refresh-ConteoChecks
} catch {}
try {
  $form.StartPosition = [Windows.Forms.FormStartPosition]::CenterScreen
  $form.ShowInTaskbar = $true
  [void]$form.ShowDialog()
} catch {
  $err = "FarmBoss error: $_"
  Write-Host $err -ForegroundColor Red
  try {
    $crash = Join-Path $script:Root "logs\farm-crash.txt"
    New-Item -ItemType Directory -Path (Split-Path $crash) -Force | Out-Null
    Add-Content $crash ("{0} {1}" -f (Get-Date), $err) -Encoding UTF8
  } catch {}
  try { [Windows.Forms.MessageBox]::Show($err, "FarmBoss 1.3.56") } catch {}
  Write-Host "Enter para cerrar"
  try { [void](Read-Host) } catch { Start-Sleep 8 }
}
